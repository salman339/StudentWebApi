﻿using BusinessEntities.Exceptions;
using BusinessEntities.FeeStructure;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using DataAccessLayer.Services;
using Common;
using BusinessEntities.Others;
using BusinessEntities.Users.Bookers;
using Hangfire;
using System.Data;
using System.IO;
using ClosedXML.Excel;
using BusinessServices.Others;
using BusinessEntities.LeaveSetup;
using BusinessEntities.ArrangementType;

namespace BusinessServices.FeeStructures
{
    public partial class FeeStructureService
    {
        #region Public Method 
        public async Task<FeeStructureModel> SaveFeeStructure(FeeStructureModel feeStructureModel)
        {
            try
            {

                var tenantId = await _tenantService.GetCurrentTenantId();

                var feetitleName = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(p => p.FeeTitle
                == feeStructureModel.FeeTitle);

                if (feetitleName != null)
                    throw new BusinessException(Common.ErrorMessages.FeeStructures.FeeStructuresNameExists);

                FeeStructure feeStructure = null;
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {

                    feeStructure = MapFeeStructureModelToFeeStructures(null, feeStructureModel);
                    feeStructure.TenantId = tenantId;
                    _unitOfWork.FeeStructureRepository.Insert(feeStructure);

                    await _unitOfWork.SaveChangesAsync();

                    AuditTrail auditTrailbart = new AuditTrail()
                    {
                        CreatedBy = feeStructure.CreatedBy,
                        CreatedOn = DateTime.UtcNow,
                        ObjectArea = Common.Constants.AuditTrailAreas.FeeStructure,
                        ObjectId = feeStructure.Id.ToString(),
                        ObjectType = Common.Constants.AuditTrailAreas.FeeStructure,
                        PropertyName = Common.Constants.AuditTrailAreas.FeeStructureAdded.ToString(),
                        PropertyNewValue = Common.Constants.AuditTrailAreas.FeeStructureCreated.ToString(),
                        PropertyOldValue = "",
                        TenantId = tenantId
                    };
                    _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                }


                feeStructure.User = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(p => p.Id == feeStructure.CreatedBy);
                var results = MapFeeStructureToFeeStructureModel(feeStructure);
                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<FeeStructureModel> UpdateFeeStructure(FeeStructureModel feeStructureModel)
        {
            try
            {

                var feeName = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(p => p.FeeTitle == feeStructureModel.FeeTitle && p.Id != feeStructureModel.Id);
                if (feeName != null)
                    throw new BusinessException(Common.ErrorMessages.FeeStructures.FeeStructuresNameExists);

                var fee = await _unitOfWork.FeeStructureRepository.FindByIdAsync(feeStructureModel.Id);

                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    double LocalAuthorityChargeOld = 0;
                    if (fee.LocalAuthorityCharge > 0)
                        LocalAuthorityChargeOld = Convert.ToDouble(fee.LocalAuthorityCharge);
                    var oldObj = new FeeStructureModel
                    {
                        FeeTitle = fee.FeeTitle,
                        Fee = Convert.ToDouble(fee.Fee),
                        LocalAuthorityCharge = LocalAuthorityChargeOld,
                        WeekendString = fee.Weekend == true ? "Selected" : "UnSelected",
                        DailyString = fee.Daily == true ? "Selected" : "UnSelected",
                        NAString = fee.NA == true ? "Selected" : "UnSelected",
                        UpdatedBy = fee.UpdatedBy,
                        TenantId = fee.TenantId,
                    };

                    fee = MapFeeStructureModelToFeeStructures(fee, feeStructureModel);
                    double LocalAuthorityCharge = 0;
                    if (fee.LocalAuthorityCharge > 0)
                        LocalAuthorityCharge = Convert.ToDouble(fee.LocalAuthorityCharge);
                    var newObj = new FeeStructureModel
                    {
                        FeeTitle = fee.FeeTitle,
                        Fee = Convert.ToDouble(fee.Fee),
                        LocalAuthorityCharge = LocalAuthorityCharge,
                        WeekendString = fee.Weekend == true ? "Selected" : "UnSelected",
                        DailyString = fee.Daily == true ? "Selected" : "UnSelected",
                        NAString = fee.NA == true ? "Selected" : "UnSelected",
                        UpdatedBy = fee.UpdatedBy,
                        TenantId = fee.TenantId,
                    };

                    _auditService.AuditTrailHandler<FeeStructureModel>(Common.Constants.AuditTrailObjectPropertySettings.FeeStructure,
                  oldObj, newObj, Common.Constants.AuditTrailAreas.FeeStructure,
                 Common.Constants.AuditTrailAreas.FeeStructure.ToString(), fee.Id.ToString(), _unitOfWork);

                    await _unitOfWork.SaveChangesAsync();

                    scope.Complete();



                }
                fee.User1 = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(p => p.Id == fee.UpdatedBy);
                feeStructureModel = MapFeeStructureToFeeStructureModel(fee);

                return feeStructureModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<PagedResults<FeeStructureModel>> GetAllFeeStructures(QueryParameter queryParameter, FeeStructureSearchModel searchModel)
        {

            int totalRecords = 0;
            string filter = string.Empty;

            SortExpression[] sortExpressions = new SortExpression[1];
            sortExpressions[0] = new SortExpression("CreatedOn", System.ComponentModel.ListSortDirection.Descending);


            if (!string.IsNullOrWhiteSpace(searchModel.WildCard))
                filter = "FeeTitle.ToUpper().Contains(\"" + searchModel.WildCard.ToUpper().Trim() + "\")";

            var fee = await _unitOfWork.FeeStructureRepository.FindAllAsync(ref totalRecords, filter, queryParameter.IncludePaths,
                  queryParameter.PageNumber, queryParameter.PageSize,
                  sortExpressions, null, queryParameter.IsDistinctRecords, null);
            var result = MapFeeStructureToFeeStructureModels(fee);
            foreach (var item in result)
            {
                var createdByUser = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(p => p.Id == item.CreatedById);
                item.CreatedByUser = createdByUser.FirstName + " " + createdByUser.LastName;
            }
            return new PagedResults<FeeStructureModel>(queryParameter, result, totalRecords);

        }

        public async Task<FeeStructureModel> GetFeeStructure(int Id)
        {
            var fee = await _unitOfWork.FeeStructureRepository.FindByIdAsync(Id);
            return MapFeeStructureToFeeStructureModel(fee);

        }

        public async Task<bool> DeleteFeeStructure(int Id, Guid UserId)
        {
            // not yet complete add ref
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                try
                {
                    var serviceUserFinanceFeeStructure = await _unitOfWork.ServiceUserFinanceFeeStructure.GetFirstOrDefaultAsync(a => a.FeeStructureId == Id);
                    if (serviceUserFinanceFeeStructure != null)
                    {
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.FeeStructureCannotDelete);
                    }
                    var holidayDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.GetFirstOrDefaultAsync(a => a.FeeStructureId == Id);
                    if (holidayDetail != null)
                    {
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.FeeStructureCannotDeleteUsedInTemporaryCarer);
                    }
                    var feeStructure = await _unitOfWork.SLcFeeStractureRepository.GetFirstOrDefaultAsync(a => a.FeeStracture == Id);
                    if (feeStructure != null)
                    {
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.CannotDeleteFeeStructureUseInSlcFeeStrtuctre);
                    }
                    var fee = await _unitOfWork.FeeStructureRepository.FindByIdAsync(Id);
                    //---------------------- Audit Trail  ------------------------// 	
                    AuditTrail auditTrail = new AuditTrail()
                    {
                        CreatedBy = UserId,
                        CreatedOn = DateTime.UtcNow,
                        ObjectArea = Common.Constants.AuditTrailAreas.FeeStructure,
                        ObjectId = UserId.ToString(),
                        ObjectType = Common.Constants.Users.BetterTogetherAdministrator,
                        PropertyName = Common.Constants.AuditTrailAreas.FeeStructureDeleted.ToString(),
                        PropertyNewValue = "",
                        PropertyOldValue = fee.FeeTitle,
                        TenantId = await _tenantService.GetCurrentTenantId()
                    };
                    _auditService.CreateAuditTrail(auditTrail, this._unitOfWork);
                    _unitOfWork.FeeStructureRepository.Delete(Id);
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                    return true;
                }
                catch (Exception ex)
                {
                    throw ex;

                }
            }
        }

        public async Task<Boolean> ValidateFeeStructureName(int id, string val)
        {

            Boolean result = false;
            if (id > 0)
            {
                var _attribute = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(x => x.FeeTitle == val.Trim() && x.Id != id);
                if (_attribute == null)
                {
                    result = false;
                }
                else
                    result = true;
            }
            else
            {
                var _attribute = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(x => x.FeeTitle == val.Trim());
                if (_attribute == null)
                {
                    result = false;
                }
                else
                    result = true;
            }

            return result;
        }
        public async Task<List<FeeStructureLookupModel>> GetAllFeeStructureLookup(string type)
        {
            if (type == "DailyNA")
            {
                var incident = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Daily == true || x.NA == true);
                var incidentData = MapFeeStructureToFeeStructureLookupModel(incident.OrderBy(x => x.FeeTitle).ToList());
                return incidentData;
            }
            else if (type == "Daily")
            {
                var incident = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Daily == true);
                var incidentData = MapFeeStructureToFeeStructureLookupModel(incident.OrderBy(x => x.FeeTitle).ToList());
                return incidentData;
            }
            else if (type == "Weekly")
            {
                var incident = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Weekend == true);
                var incidentData = MapFeeStructureToFeeStructureLookupModel(incident.OrderBy(x => x.FeeTitle).ToList());
                return incidentData;
            }
            else // here type is serviceuser id
            {
                try
                {
                    var serviceUser = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id.ToString() == type);
                    if (serviceUser.PwsStatusId == null)
                        throw new BusinessException(Common.ErrorMessages.SericeUser.AddPwsStatus);
                    var pwsStatus = await _unitOfWork.PwsStatusRepository.GetFirstOrDefaultAsync(x => x.Id == serviceUser.PwsStatusId);
                    if (pwsStatus.Name == Common.Constants.PWSStatus.Respite)
                    {
                        var incident = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Daily == true);
                        var incidentData = MapFeeStructureToFeeStructureLookupModel(incident.OrderBy(x => x.FeeTitle).ToList());
                        return incidentData;
                    }
                    else
                    {
                        var incident = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Weekend == true);
                        var incidentData = MapFeeStructureToFeeStructureLookupModel(incident.OrderBy(x => x.FeeTitle).ToList());
                        return incidentData;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;

                }
            }
        }
        private List<FeeStructureLookupModel> MapFeeStructureToFeeStructureLookupModel(List<FeeStructure> input)
        {
            var incidentServicesData = new List<FeeStructureLookupModel>();
            foreach (var i in input)
            {
                var obj = new FeeStructureLookupModel();
                obj.Id = i.Id;
                obj.Name = i.FeeTitle;
                incidentServicesData.Add(obj);
            }
            return incidentServicesData;
        }
        public async Task<List<FeeStructureModel>> GetFeeStructureById(string id)
        {
            string[] feeStructureIds = id.Split(',');
            var result = new List<FeeStructureModel>();
            foreach (var item in feeStructureIds)
            {
                int feeStructureid = Convert.ToInt32(item);
                var feeStructure = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(x => x.Id == feeStructureid);
                var mappingResult = MapFeeStructureToFeeStructureModels(feeStructure);
                result.Add(mappingResult);
            }
            return result;
        }
        private FeeStructureModel MapFeeStructureToFeeStructureModels(FeeStructure feeStructure)
        {
            var obj = new FeeStructureModel();
            obj.Id = feeStructure.Id;
            obj.FeeTitle = feeStructure.FeeTitle;
            obj.Fee = Convert.ToDouble(feeStructure.Fee);
            if (feeStructure.LocalAuthorityCharge > 0)
                obj.LocalAuthorityCharge = Convert.ToDouble(feeStructure.LocalAuthorityCharge);
            obj.Daily = feeStructure.Daily;
            obj.Weekend = feeStructure.Weekend;
            obj.NA = feeStructure.NA;
            return obj;
        }
        #endregion


        #region Finance Service User


        public async Task<Boolean> UpdateServiceUserFinanceUtility()
        {

            try
            {
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    var serviceUsersList = await _unitOfWork.ServiceUserRepository.FindAllAsync(x => x.FeeStructureId > 0 && x.AppStatusValId == 2);
                    foreach (var item in serviceUsersList)
                    {

                        FeeStractureService(item, item.TenantId);
                    }
                    await _unitOfWork.SaveChangesAsync();


                    scope.Complete();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }


        public async Task<ServiceUserFinanceViewModel> UpdateServiceUserFinance(ServiceUserFinanceViewModel serviceUserModel)
        {

            try
            {

                int fee = 0;
                var tenantId = await _tenantService.GetCurrentTenantId();
                // await FeeStractureHangFireService();
                //var serviceUser = await _unitOfWork.ServiceUserRepository.FindByIdAsync(serviceUserModel.ServiceUserId);
                var arrangementlist = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.ServiceUserId.ToString() == serviceUserModel.ServiceUserId);

                var checkArrangement = arrangementlist.Where(x => x.IsVacant != true && (x.IsArchive == false || x.IsArchive == null)).FirstOrDefault();
                if (checkArrangement == null)
                {
                    throw new BusinessException(Common.ErrorMessages.SericeUser.FeeStructurecannotAddInPWS);
                }
                var carerId = checkArrangement.CarerId;
                var carerCheck = await _unitOfWork.CarerListViewRepository.GetFirstOrDefaultAsync(x => x.Id == carerId);
                if (carerCheck != null)
                {
                    if (carerCheck.AppStatus == Common.Constants.UserStatus.Deleted)
                    {
                        throw new BusinessException(Common.ErrorMessages.SericeUser.FeeStructurecannotAddInPWSCarerInActive);
                    }
                }
                var serviceUser = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(a => a.Id.ToString() == serviceUserModel.ServiceUserId);
                //  var pwsUserMap = await _unitOfWork.ServiceUserFinanceFeeStructure.GetFirstOrDefaultAsync(x => x.ServiceUserId.ToString() == serviceUserModel.ServiceUserId);

                if (serviceUser.FeeStructureId > 0)
                    fee = 1;
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    ServiceUserFinanceViewModel oldFinanceobj = new ServiceUserFinanceViewModel();
                    if (oldFinanceobj.FeeStructureTitle == null || oldFinanceobj.FeeStructureTitle == "")
                    {
                        oldFinanceobj.FeeStructureTitle = "";
                    }

                    var deletedServiceUserFinnaceFeeStructures = new List<ServiceUserFinanceFeeStructure>();

                    var serviceuserfinancefeestructureResult = await _unitOfWork.ServiceUserFinanceFeeStructure.FindAllAsync(a => a.ServiceUserId.ToString() == serviceUserModel.ServiceUserId);
                    serviceuserfinancefeestructureResult.ToList();

                    string[] feeStructureIds = serviceUserModel.FeeStructureId.Split(',');
                    foreach (var item in serviceuserfinancefeestructureResult)
                    {
                        var resultoffeestructure = feeStructureIds.Where(x => x == item.FeeStructureId.ToString());
                        var feeStructure = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(a => a.Id == item.FeeStructureId);
                        if (resultoffeestructure.Count() == 0)
                        {
                            deletedServiceUserFinnaceFeeStructures.Add(item);
                            AuditTrail auditTrailbart = new AuditTrail()
                            {
                                CreatedBy = serviceUserModel.UpdatedById.Value,
                                CreatedOn = DateTime.UtcNow,
                                ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                ObjectId = serviceUserModel.ServiceUserId.ToString(),
                                ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport,
                                PropertyName = Common.Constants.AuditTrailAreas.FeeStructureDeleted.ToString(),
                                PropertyNewValue = "",
                                PropertyOldValue = feeStructure.FeeTitle,
                                TenantId = tenantId
                            };
                            _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                        }
                    }

                    ////Delete service user finance fee structure
                    if (deletedServiceUserFinnaceFeeStructures.Count > 0)
                        _unitOfWork.ServiceUserFinanceFeeStructure.DeleteObjects(deletedServiceUserFinnaceFeeStructures);

                    foreach (var item in feeStructureIds)
                    {
                        ServiceUserFinanceFeeStructure serviceUserFinanceFeeStructure = null;
                        int feestrucreid = Convert.ToInt32(item);
                        var result = serviceuserfinancefeestructureResult.FirstOrDefault(p => p.FeeStructureId == feestrucreid);
                        if (result == null)
                        {
                            var feeStructure = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(a => a.Id == feestrucreid);
                            serviceUserFinanceFeeStructure = MapServiceUserFinanceViewModelToServiceUserFinanceFeeStructure(null, serviceUserModel);
                            serviceUserFinanceFeeStructure.TenantId = tenantId;
                            serviceUserFinanceFeeStructure.FeeStructureId = Convert.ToInt32(item);
                            _unitOfWork.ServiceUserFinanceFeeStructure.Insert(serviceUserFinanceFeeStructure);

                            //history
                            AuditTrail auditTrailbart = new AuditTrail()
                            {
                                CreatedBy = serviceUserModel.UpdatedById.Value,
                                CreatedOn = DateTime.UtcNow,
                                ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                ObjectId = serviceUserModel.ServiceUserId.ToString(),
                                ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport,
                                PropertyName = Common.Constants.AuditTrailAreas.FeeStructure.ToString(),
                                PropertyNewValue = feeStructure.FeeTitle,
                                PropertyOldValue = "",
                                //PropertyOldValue = oldFinanceobj.FeeStructureTitle,
                                TenantId = tenantId
                            };
                            _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                        }
                    }

                    if (fee == 0)
                        FeeStractureService(serviceUser, serviceUser.TenantId);
                    serviceUser.FeeStructureId = 1;
                    await _unitOfWork.SaveChangesAsync();


                    scope.Complete();
                }
                //  FeeStractureHangFireService();
                //serviceUser.User1 = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(p => p.Id == serviceUser.UpdatedBy);
                //serviceUserModel = MapFeeStructureToFeeStructureModel(serviceUser);

                return serviceUserModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<ServiceUserFinanceViewModel>> GetServiceUserFinance(string Id)
        {
            List<ServiceUserFinanceViewModel> ServiceUserFinanceViewModelList = new List<ServiceUserFinanceViewModel>();
            var serviceUserFinanceFeeStructure = await _unitOfWork.ServiceUserFinanceFeeStructure.FindAllAsync(p => p.ServiceUserId.ToString() == Id);
            foreach (var item in serviceUserFinanceFeeStructure)
            {
                var mappingResult = MapServiceUserFinanceFeeStructureToServiceUserFinanceViewModel(item);
                ServiceUserFinanceViewModelList.Add(mappingResult);
            }
            return ServiceUserFinanceViewModelList;
        }
        public async Task<bool> RoomExistOrNot(string UserId)
        {
            var arrangement = await _unitOfWork.ArrangementRepository.GetFirstOrDefaultAsync(x => x.ServiceUserId.ToString() == UserId && x.IsArchive == false);
            var status = false;
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                if (arrangement != null)
                {
                    status = true;
                }
                else
                {
                    status = false;
                }
            }
            return status;
        }
        #endregion

        #region Finance Carer 
        public async Task<List<MonthViewModel>> GetMonthList()
        {
            try
            {
                var months = await _unitOfWork.MonthRepository.FindAllAsync();
                return MapMonthToMonthViewModel(months);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<YearViewModel>> GetYearList()
        {
            try
            {
                var months = await _unitOfWork.YearRepository.FindAllAsync();
                return MapYearToYearViewModel(months);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public async Task<PagedResults<CarerFeeStructureModel>> GetAllCarerFinanceList(QueryParameter queryParameter, CarerFinanceSearchModel searchModel)
        {
            int totalRecords = 0;
            IList<CarerFeeStructureModel> CarerFeeStructureModel = new List<CarerFeeStructureModel>();
            var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == searchModel.FinancePeriodId);
            if (financePeriod == null)
                throw new BusinessException(Common.ErrorMessages.FeeStructures.FinancePeriodNotExists);
            try
            {
                var dateFilter = string.Empty;
                var queryBuilder = new StringBuilder();
                var needAndFilter = false;
                if (searchModel != null)
                {
                    if (!string.IsNullOrWhiteSpace(searchModel.WildCard))
                    {
                        needAndFilter = true;
                    }
                }
                if (needAndFilter)
                {
                    queryBuilder.AppendLine(" And TenantId = " + await _tenantService.GetCurrentTenantId());
                    queryBuilder.AppendLine(" CarerId  = \'" + searchModel.CarerId + "\' )");
                    queryBuilder.AppendLine(" And TDate  >= \'" + financePeriod.StartDate + "\' ");
                    queryBuilder.AppendLine(" And TDate  <= \'" + financePeriod.EndDate + "\' ");
                }
                else
                {
                    queryBuilder.AppendLine(" CarerId  = \'" + searchModel.CarerId + "\' ");
                    queryBuilder.AppendLine(" And TDate  >= \'" + financePeriod.StartDate + "\' ");
                    queryBuilder.AppendLine(" And TDate  <= \'" + financePeriod.EndDate + "\' ");
                }
                var sqlwhereQury = queryBuilder.ToString();
                var totalRecordResultQuery = string.Format("select count(*) as totalRecords from SLCFinanceListView {0} {1}", string.IsNullOrWhiteSpace(sqlwhereQury) ? string.Empty : "Where", sqlwhereQury);
                var totalRecordsResult = await _unitOfWork.ExecuteSqlCommandSqlServer(totalRecordResultQuery);
                totalRecords = int.Parse(totalRecordsResult.Rows[0]["totalRecords"].ToString());

                if (totalRecords > 0)
                {
                    var listQuery = string.Format("Select * from SLCFinanceListView {0} {1} Order by Amount asc  OFFSET {2} ROWS FETCH NEXT {3} ROWS ONLY ",
                                 string.IsNullOrWhiteSpace(sqlwhereQury) ? string.Empty : "Where", sqlwhereQury, ((int)queryParameter.PageNumber - 1) * ((int)queryParameter.PageSize),
                           (int)queryParameter.PageSize);

                    var FeeCarerListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                    CarerFeeStructureModel = MapCarerFeeStructureViewModels(FeeCarerListData);
                    CarerFeeStructureModel = CarerFeeStructureModel.OrderByDescending(x => x.TotalAmount == 0 && x.IsShortDays == true).ToList();
                    //start To check for if period close then open period for recent/last close period
                    var slcFeeStructureOpenPeriodcheck = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(p => p.CarerId.ToString() == searchModel.CarerId && p.IsMonthClose == true && p.ReOpenPeriod != false);
                    var topPeriodCheck = slcFeeStructureOpenPeriodcheck.OrderByDescending(x => x.Tdate).FirstOrDefault();
                    if (topPeriodCheck != null)
                    {
                        if (topPeriodCheck.Tdate >= financePeriod.StartDate && topPeriodCheck.Tdate <= financePeriod.EndDate)
                            CarerFeeStructureModel[0].IsPeriodOpen = true;
                        else
                            CarerFeeStructureModel[0].IsPeriodOpen = false;
                    }
                    //end

                    var slcFeeTotal = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(p => p.CarerId.ToString() == searchModel.CarerId && p.Tdate >= financePeriod.StartDate && p.Tdate <= financePeriod.EndDate);
                    decimal NetAmount = 0;
                    NetAmount = slcFeeTotal.Sum(x => x.Amount ?? 0);
                    CarerFeeStructureModel[0].NetAmount = NetAmount;
                    if ((DateTime.Now.Date >= financePeriod.StartDate.Date) && (DateTime.Now.Date <= financePeriod.EndDate.Date))
                        CarerFeeStructureModel[0].IsDisableCloseMonth = true;
                    else
                        CarerFeeStructureModel[0].IsDisableCloseMonth = false;
                }

                return new PagedResults<CarerFeeStructureModel>(queryParameter, CarerFeeStructureModel, totalRecords);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        private List<CarerFeeStructureModel> MapCarerFeeStructureViewModels(DataTable List)
        {
            List<CarerFeeStructureModel> CarerFeeStructureModel = new List<CarerFeeStructureModel>();
            foreach (DataRow row in List.Rows)
            {
                SLCFinanceListView item = row.GetItem<SLCFinanceListView>();
                CarerFeeStructureModel.Add(MapCarerFeeStructureViewModel(item));
            }
            return CarerFeeStructureModel;
        }


        private CarerFeeStructureModel MapCarerFeeStructureViewModel(SLCFinanceListView model)
        {
            var CarerFeeStructureModel = new CarerFeeStructureModel()
            {
                Id = model.Id,
                Description = model.Description,
                Fee = model.Amount ?? 0,
                Daily = model.Daily,
                Weekly = model.Weekly,
                NA = model.NA,
                IsMonthClose = model.IsMonthClose,
                IsDeduction = model.IsDeduction,
                CreatedOn = model.CreatedOn,
                CreatedByUser = model.CreatedByUser,
                LocalAuthorityCharges = model.LocalAuthorityCharges,
                IsShortDays = model.IsShortDays

            };
            return CarerFeeStructureModel;
        }
        public async Task<bool> DeleteCarerFeeStructure(SLCFeeStructureModel model)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                try
                {

                    var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == model.FinancePeriodId);
                    var slcFeeStructureResult = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.CarerId.ToString() == model.CarerId && a.Tdate >= financePeriod.StartDate && a.Tdate <= financePeriod.EndDate && a.IsMonthClose == true);
                    if (slcFeeStructureResult.Count != 0)
                    {
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.RecordCannotDelete);
                    }
                    var slcFeeTotal = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(p => p.CarerId.ToString() == model.CarerId && p.Tdate >= financePeriod.StartDate && p.Tdate <= financePeriod.EndDate && p.Id != model.Id);
                    decimal reminaingAmount = 0;
                    foreach (var item in slcFeeTotal)
                    {
                        reminaingAmount = reminaingAmount + item.Amount ?? 0;
                    }
                    if (reminaingAmount < 0)
                    {
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.RecordCannotDeleteForAmountNegative);
                    }


                    var slcFeeStructureValue = await _unitOfWork.SLcFeeStractureRepository.GetFirstOrDefaultAsync(x => x.Id == model.Id);
                    _unitOfWork.SLcFeeStractureRepository.Delete(model.Id);
                    AuditTrail auditTrailbart = new AuditTrail()
                    {
                        CreatedBy = model.CreatedById,
                        CreatedOn = DateTime.UtcNow,
                        ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                        ObjectId = model.CarerId.ToString(),
                        ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer.ToString(),
                        PropertyName = Common.Constants.AuditTrailAreas.FeeDeleted.ToString(),
                        PropertyNewValue = "",
                        PropertyOldValue = slcFeeStructureValue.Description,
                        TenantId = slcFeeStructureValue.TenantId
                    };
                    _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                    return true;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }
        public async Task<SLCCloseMonthModel> CarerCloseMonth(SLCCloseMonthModel model)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                try
                {
                    SLCCloseMonthModel sLCCloseMonthModel = new SLCCloseMonthModel();

                    var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == model.FinancePeriodId);
                    if (model.IsClosePeriod)
                    {
                        if (model.Type == "FinanceReportClosePeriod")
                        {
                            var slcFeeStructureCheck = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.Tdate < financePeriod.StartDate && x.IsMonthClose != true);
                            if (slcFeeStructureCheck.Count > 0)
                            {
                                var PeriodName = "";
                                var TDate = slcFeeStructureCheck.Select(x => x.Tdate).FirstOrDefault();
                                var FinancePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.StartDate <= TDate && x.EndDate >= TDate);
                                if (financePeriod != null)
                                    PeriodName = FinancePeriod.Title;
                                throw new BusinessException(Common.ErrorMessages.FeeStructures.CannotClosePeriodBeforeLastClose.ToString(), "You cannot close this period until last period is closed (" + PeriodName + ")");
                            }

                            if (!(DateTime.Now.Date >= financePeriod.StartDate.Date) || !(DateTime.Now.Date <= financePeriod.EndDate.Date))
                            {
                                var carerFinance = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.Tdate >= financePeriod.StartDate && a.Tdate <= financePeriod.EndDate);
                                carerFinance.ToList();

                                if (carerFinance.Count <= 0)
                                {
                                    throw new BusinessException(Common.ErrorMessages.FeeStructures.ThisPeriodisEmpty.ToString(), "You cannot close this period Because this period is empty");
                                }
                                int teanantid = 0;

                                //reopen false 
                                var slcFeeStructureResult = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.IsMonthClose == true && x.ReOpenPeriod != false);
                                SLcFeeStracture sLcFeeStracture = null;
                                foreach (var item in slcFeeStructureResult)
                                {
                                    item.ReOpenPeriod = false;
                                }
                                //end
                                foreach (var item in carerFinance)
                                {
                                    if (item.Amount == 0 && item.IsShortDays == true)
                                    {
                                        throw new BusinessException(Common.ErrorMessages.FeeStructures.CannotClosePeriodAmountIsZero);
                                    }
                                    item.IsMonthClose = true;
                                    item.UpdatedBy = model.UpdatedBy;
                                    item.UpdatedOn = DateTime.UtcNow;
                                    teanantid = item.TenantId;
                                }

                                await _unitOfWork.SaveChangesAsync();
                                //To check for if period close then open period for recent close period
                                var slcFeeStructureOpenPeriodcheck = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(p => p.IsMonthClose == true);
                                var topPeriodCheck = slcFeeStructureOpenPeriodcheck.OrderByDescending(x => x.Tdate).FirstOrDefault();
                                if (topPeriodCheck != null)
                                {
                                    if (topPeriodCheck.Tdate >= financePeriod.StartDate && topPeriodCheck.Tdate <= financePeriod.EndDate)
                                        sLCCloseMonthModel.IsPeriodOpen = true;
                                    else
                                        sLCCloseMonthModel.IsPeriodOpen = false;
                                }
                                AuditTrail auditTrailbart = new AuditTrail()
                                {
                                    CreatedBy = model.UpdatedBy,
                                    CreatedOn = DateTime.UtcNow,
                                    ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                    ObjectId = model.CarerId.ToString(),
                                    ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer.ToString(),
                                    PropertyName = Common.Constants.AuditTrailAreas.FinancePeriodClosed.ToString(),
                                    PropertyNewValue = financePeriod.Title,
                                    PropertyOldValue = "",
                                    TenantId = teanantid
                                };
                                _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                                await _unitOfWork.SaveChangesAsync();
                                RecurringJob.RemoveIfExists("MonthClose");
                                RecurringJob.AddOrUpdate("MonthClose", () => SLCMonthCloseEmailSendingService(financePeriod.StartDate.Date
                                    , financePeriod.EndDate.Date, model.FinancePeriodId ?? 0, model.UpdatedBy), GetCronExperssionCuurent());

                                scope.Complete();
                                return sLCCloseMonthModel;
                            }
                            else
                            {
                                throw new BusinessException(Common.ErrorMessages.FeeStructures.MonthCannotClose);
                            }
                        }
                        else
                        {
                            var slcFeeStructureCheck = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.Tdate < financePeriod.StartDate && x.CarerId.ToString() == model.CarerId && x.IsMonthClose != true);
                            if (slcFeeStructureCheck.Count > 0)
                            {
                                var PeriodName = "";
                                var TDate = slcFeeStructureCheck.Select(x => x.Tdate).FirstOrDefault();
                                var FinancePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.StartDate <= TDate && x.EndDate >= TDate);
                                if (financePeriod != null)
                                    PeriodName = FinancePeriod.Title;
                                throw new BusinessException(Common.ErrorMessages.FeeStructures.CannotClosePeriodBeforeLastClose.ToString(), "You cannot close this period until last period is closed (" + PeriodName + ")");
                            }

                            if (!(DateTime.Now.Date >= financePeriod.StartDate.Date) || !(DateTime.Now.Date <= financePeriod.EndDate.Date))
                            {
                                var carerFinance = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.CarerId.ToString() == model.CarerId && a.Tdate >= financePeriod.StartDate && a.Tdate <= financePeriod.EndDate);
                                carerFinance.ToList();

                                int teanantid = 0;

                                //reopen false 
                                var slcFeeStructureResult = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.IsMonthClose == true && x.CarerId.ToString() == model.CarerId && x.ReOpenPeriod != false);
                                SLcFeeStracture sLcFeeStracture = null;
                                foreach (var item in slcFeeStructureResult)
                                {
                                    item.ReOpenPeriod = false;
                                }
                                //end
                                foreach (var item in carerFinance)
                                {
                                    //var checkAmountZero = carerFinance.Where(x => x.IsShortDays == true && x.Amount == 0).FirstOrDefault();
                                    if (item.Amount == 0 && item.IsShortDays == true)
                                    {
                                        throw new BusinessException(Common.ErrorMessages.FeeStructures.CannotClosePeriodAmountIsZero);
                                    }
                                    item.IsMonthClose = true;
                                    item.UpdatedBy = model.UpdatedBy;
                                    item.UpdatedOn = DateTime.UtcNow;
                                    teanantid = item.TenantId;
                                }

                                await _unitOfWork.SaveChangesAsync();
                                //To check for if period close then open period for recent close period
                                var slcFeeStructureOpenPeriodcheck = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(p => p.CarerId.ToString() == model.CarerId && p.IsMonthClose == true);
                                var topPeriodCheck = slcFeeStructureOpenPeriodcheck.OrderByDescending(x => x.Tdate).FirstOrDefault();
                                if (topPeriodCheck != null)
                                {
                                    if (topPeriodCheck.Tdate >= financePeriod.StartDate && topPeriodCheck.Tdate <= financePeriod.EndDate)
                                        sLCCloseMonthModel.IsPeriodOpen = true;
                                    else
                                        sLCCloseMonthModel.IsPeriodOpen = false;
                                }
                                AuditTrail auditTrailbart = new AuditTrail()
                                {
                                    CreatedBy = model.UpdatedBy,
                                    CreatedOn = DateTime.UtcNow,
                                    ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                    ObjectId = model.CarerId.ToString(),
                                    ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer.ToString(),
                                    PropertyName = Common.Constants.AuditTrailAreas.FinancePeriodClosed.ToString(),
                                    PropertyNewValue = financePeriod.Title,
                                    PropertyOldValue = "",
                                    TenantId = teanantid
                                };
                                _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                                await _unitOfWork.SaveChangesAsync();
                                var admin = await this._unitOfWork.UserRepository.FindByIdAsync(model.UpdatedBy);
                                var tenant = admin.Tenant;

                                byte[] fileBytes = null;
                                fileBytes = await GenerateCarerFinanceReportPdfForEmail(model.CarerId, model.FinancePeriodId ?? 0);

                                var carerinfo = await _unitOfWork.UserRepository.GetFilteredResult(x => x.Id.ToString() == model.CarerId);

                                string filePath = null;
                                filePath = "~/FinanceTemplates/" + "FinanceEmailTemplate.html";
                                filePath = System.Web.Hosting.HostingEnvironment.MapPath(filePath);
                                string htmlBody = File.ReadAllText(filePath);
                                htmlBody = htmlBody.Replace("{{Name}}", carerinfo.FirstOrDefault().FirstName + " " + carerinfo.FirstOrDefault().LastName);
                                htmlBody = htmlBody.Replace("{{TenantName}}", tenant.Name);
                                string providerName = "";
                                string imageFolderName = System.Configuration.ConfigurationManager.AppSettings["templateImages:FolderName"];
                                string folderPath = System.Web.Hosting.HostingEnvironment.MapPath("~/" + imageFolderName + "/logos");
                                string logoPath = System.IO.Path.Combine(folderPath, tenant.TenantKey + "-logo.png");
                                var emailSent = this._emailService.SendEmail(htmlBody, logoPath, "Period Closed Report",
                                tenant.EmailAddress, tenant.Name, tenant.ReplyToAddress, tenant.Name, carerinfo.FirstOrDefault().EmailAddress,
                                carerinfo.FirstOrDefault().FirstName + " " + carerinfo.FirstOrDefault().LastName, providerName, null, "PeriodClosedReport.pdf", fileBytes);
                                scope.Complete();
                                return sLCCloseMonthModel;
                            }
                            else
                            {
                                throw new BusinessException(Common.ErrorMessages.FeeStructures.MonthCannotClose);
                            }
                        }
                    }
                    else
                    {
                        var carerFinance = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.CarerId.ToString() == model.CarerId && a.Tdate >= financePeriod.StartDate && a.Tdate <= financePeriod.EndDate);
                        carerFinance.ToList();
                        int teanantid = 0;
                        foreach (var item in carerFinance)
                        {
                            item.IsMonthClose = false;
                            item.UpdatedBy = model.UpdatedBy;
                            item.UpdatedOn = DateTime.UtcNow;
                            teanantid = item.TenantId;
                        }
                        await _unitOfWork.SaveChangesAsync();
                        AuditTrail auditTrailbart = new AuditTrail()
                        {
                            CreatedBy = model.UpdatedBy,
                            CreatedOn = DateTime.UtcNow,
                            ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                            ObjectId = model.CarerId.ToString(),
                            ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer.ToString(),
                            PropertyName = Common.Constants.AuditTrailAreas.FinancePeriodOpened.ToString(),
                            PropertyNewValue = financePeriod.Title,
                            PropertyOldValue = "",
                            TenantId = teanantid
                        };
                        _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);

                        await _unitOfWork.SaveChangesAsync();
                        scope.Complete();
                        return sLCCloseMonthModel;
                    }
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }

        }

        public async Task<string> CheckPwsFeeStructureByCarer(string UserId)
        {
            var Name = string.Empty;
            bool flg = false;
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var arrangement = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.CarerId.ToString() == UserId && x.IsArchive == false);
                foreach (var item in arrangement)
                {
                    var serviceUserFinanceFeeStructure = await _unitOfWork.ServiceUserFinanceFeeStructure.GetFirstOrDefaultAsync(x => x.ServiceUserId == item.ServiceUserId);
                    if (serviceUserFinanceFeeStructure == null)
                    {
                        var serviceUser = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == item.ServiceUserId);
                        if (serviceUser != null)
                        {  // salman 06/07 added if condition, only added if condition, other 4 lines were present before
                            if (flg == false)
                                Name += "[" + serviceUser.FirstName + " " + serviceUser.LastName + "] ";
                            else
                                Name += ", [" + serviceUser.FirstName + " " + serviceUser.LastName + "] ";
                            flg = true;
                        }
                    }
                }
            }
            return Name;
        }
        //Additional fee and Deduction
        public async Task<SLCFeeStructureModel> SaveCarerAdditionalFee(SLCFeeStructureModel model)
        {
            try
            {
                var tenantId = await _tenantService.GetCurrentTenantId();
                var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == model.FinancePeriodId);
                if (!(model.TDate.Date >= financePeriod.StartDate.Date) || !(model.TDate.Date <= financePeriod.EndDate.Date))
                    throw new BusinessException(Common.ErrorMessages.FeeStructures.TDateWithinPeriodDate);
                var slcFeeStructureResult = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.CarerId.ToString() == model.CarerId && a.Tdate >= financePeriod.StartDate && a.Tdate <= financePeriod.EndDate && a.IsMonthClose == true);
                if (slcFeeStructureResult.Count != 0)
                {
                    if (model.AdditionOrDeduction == Common.Constants.FinanceStatus.Addition)
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.AdditionFeeCannotAdd);
                    else
                        throw new BusinessException(Common.ErrorMessages.FeeStructures.DeductionCannotAdd);
                }
                var feeStructure = await _unitOfWork.FeeStructureRepository.FindByIdAsync(model.FeeStructureId);

                SLcFeeStracture slcFeeStructure = null;
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    if (model.AdditionOrDeduction == Common.Constants.FinanceStatus.Addition)
                    {
                        if (model.FeeStructureId != null)
                        {
                            model.Fee = feeStructure.Fee;
                            model.Weekend = feeStructure.Weekend;
                            model.Daily = feeStructure.Daily;
                            model.NA = feeStructure.NA;
                        }
                        else
                        {
                            model.Weekend = false;
                            model.Daily = false;
                            model.NA = true;
                        }
                    }
                    else
                    {
                        model.Weekend = false;
                        model.Daily = false;
                        model.NA = true;
                    }
                    slcFeeStructure = MapSLCFeeStructureModelToSLCFeeStructures(null, model);
                    slcFeeStructure.TenantId = tenantId;
                    _unitOfWork.SLcFeeStractureRepository.Insert(slcFeeStructure);

                    await _unitOfWork.SaveChangesAsync();

                    AuditTrail auditTrailbart = new AuditTrail()
                    {
                        CreatedBy = model.CreatedById,
                        CreatedOn = DateTime.UtcNow,
                        ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                        ObjectId = model.CarerId.ToString(),
                        ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer.ToString(),
                        PropertyName = model.AdditionOrDeduction == Common.Constants.FinanceStatus.Addition ? Common.Constants.AuditTrailAreas.AdditionalFeeAdded.ToString() + " - " + model.TDate.ToString("dd-MM-yyyy") : Common.Constants.AuditTrailAreas.DeductionAdded.ToString() + " - " + model.TDate.ToString("dd-MM-yyyy"),
                        PropertyNewValue = model.Description,
                        PropertyOldValue = "",
                        TenantId = tenantId
                    };
                    _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                }

                if (feeStructure != null)
                    feeStructure.User = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(p => p.Id == feeStructure.CreatedBy);
                var results = MapSLCFeeStructureToSLCFeeStructureModel(slcFeeStructure);
                return results;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region Update Carer Finance Amount
        public async Task<SLCFeeStructureModel> UpdateCarerFinanceAmount(SLCFeeStructureModel model)
        {
            try
            {
                var tenantId = await _tenantService.GetCurrentTenantId();
                var slcFeeStracture = await _unitOfWork.SLcFeeStractureRepository.FindByIdAsync(model.Id);
                var amount = slcFeeStracture.Amount;
                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    slcFeeStracture.Amount = model.Fee;
                    _unitOfWork.SLcFeeStractureRepository.Update(slcFeeStracture);
                    await _unitOfWork.SaveChangesAsync();
                    AuditTrail auditTrailbart = new AuditTrail()
                    {
                        CreatedBy = model.CreatedById,
                        CreatedOn = DateTime.UtcNow,
                        ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                        ObjectId = model.CarerId.ToString(),
                        ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer.ToString(),
                        PropertyName = Common.Constants.AuditTrailAreas.AmountUpdated,
                        PropertyNewValue = slcFeeStracture.Amount.ToString(),
                        PropertyOldValue = amount.ToString(),
                        TenantId = tenantId
                    };
                    _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                }
                return model;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion


        #region Carer finance excel report
        public async Task<Stream> DownloadCarerFinanceReportResultsInExcel(CarerFinanceSearchModel searchModel)
        {
            XLWorkbook workbook = null;
            MemoryStream memoryStream = null;

            try
            {
                var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == searchModel.FinancePeriodId);
                if (financePeriod == null)
                {
                    return null;
                }
                var whereclause = " where  convert(date,dbo.[SLcFeeStracture].TDate)>='" + financePeriod.StartDate.Date + "' and "
                    + " convert(date,dbo.[SLcFeeStracture].TDate)<='" + financePeriod.EndDate.Date + "'" + " and dbo.[SLcFeeStracture].CarerId = '" + searchModel.CarerId + "'";
                workbook = new XLWorkbook();
                memoryStream = new MemoryStream();

                var listQuery = string.Format(
                    "Select dbo.[SLcFeeStracture].Description,dbo.[SLcFeeStracture].Amount as 'Amount (£)',case when dbo.[SLcFeeStracture].Weekly='false' then 'UnSelected' else 'Selected' end as Weekly,case when dbo.[SLcFeeStracture].Daily='false' then 'UnSelected' else 'Selected' end as Daily,case when dbo.[SLcFeeStracture].NA='false' then 'UnSelected' else 'Selected' end as 'N/A',CONVERT(varchar,FORMAT(SWITCHOFFSET(CONVERT(datetime, dbo.[SLcFeeStracture].CreatedOn),DATENAME(TzOffset, SYSDATETIMEOFFSET())),'dd/MM/yyyy HH:mm')) +' by ' + CreatedByUser.FirstName + case when CreatedByUser.LastName is null  then '' else ' ' + CreatedByUser.LastName  end as 'CreatedByUser' from SLcFeeStracture left join dbo.[user] as CreatedByUser  on CreatedByUser.Id = dbo.[SLcFeeStracture].CreatedBy " + whereclause + " order by dbo.[SLcFeeStracture].Amount desc");


                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                decimal totalAmount = 0;
                if (exportedResults != null)
                {
                    foreach (DataRow row in exportedResults.Rows)
                    {
                        string values = string.Empty;
                        foreach (DataColumn col in exportedResults.Columns)
                        {
                            if (col.ColumnName == "Amount (£)")
                            {
                                totalAmount += Convert.ToDecimal(row[col.ColumnName]);
                            }
                            if (col.ColumnName != "PWS Name")
                            {
                                values = row[col.ColumnName].ToString();
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                {
                                    values = values.Replace("<br/>", Environment.NewLine);
                                    row[col.ColumnName] = values;
                                }
                            }

                            else
                            {
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                    values = values + "," + row[col.ColumnName].ToString();
                            }

                        }
                    }

                }
                exportedResults.Rows.Add(new Object[] { "Total Amount (£)", totalAmount });
                workbook.Worksheets.Add(exportedResults, "Report Results");

                workbook.SaveAs(memoryStream);
                return memoryStream;

            }
            //catch (Exception ex)
            //{
            //    //if (memoryStream != null)
            //    //    memoryStream.Dispose();
            //    //memoryStream = null;
            //    throw ex;
            //}
            finally
            {
                if (workbook != null)
                    workbook.Dispose();

                workbook = null;
            }
        }

        #endregion

        #region Carer Finance pdf report
        public async Task<byte[]> DownloadCarerFinanceReportResultsInPdf(string carerId, int FinancePeriodId)
        {
            return await GenerateCarerFinanceReportPdf(carerId, FinancePeriodId);
        }
        private async Task<byte[]> GenerateCarerFinanceReportPdf(string carerId, int FinancePeriodId)
        {
            var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == FinancePeriodId);
            if (financePeriod == null)
                throw new BusinessException(Common.ErrorMessages.FeeStructures.FinancePeriodNotExists);
            try
            {
                IList<CarerFeeStructureViewModel> SLCFinanceListView = new List<CarerFeeStructureViewModel>();
                var whereclause = " where  convert(date,dbo.[SLcFeeStracture].TDate)>='" + financePeriod.StartDate.Date + "' and "
                    + " convert(date,dbo.[SLcFeeStracture].TDate)<='" + financePeriod.EndDate.Date + "'" + " and dbo.[SLcFeeStracture].CarerId = '" + carerId + "'";

                var listQuery = string.Format(
                    "Select dbo.[SLcFeeStracture].Description,dbo.[SLcFeeStracture].Amount as 'TotalAmount',case when dbo.[SLcFeeStracture].Weekly='false' then 'UnSelected' else 'Selected' end as Weekly,case when dbo.[SLcFeeStracture].Daily='false' then 'UnSelected' else 'Selected' end as Daily,case when dbo.[SLcFeeStracture].NA='false' then 'UnSelected' else 'Selected' end as 'NA',CONVERT(varchar,FORMAT(SWITCHOFFSET(CONVERT(datetime, dbo.[SLcFeeStracture].CreatedOn),DATENAME(TzOffset, SYSDATETIMEOFFSET())),'dd/MM/yyyy HH:mm')) +' by ' + CreatedByUser.FirstName + case when CreatedByUser.LastName is null  then '' else ' ' + CreatedByUser.LastName  end as 'CreatedByUser' from SLcFeeStracture left join dbo.[user] as CreatedByUser  on CreatedByUser.Id = dbo.[SLcFeeStracture].CreatedBy " + whereclause + " order by dbo.[SLcFeeStracture].Amount desc");
                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                SLCFinanceListView = MapSLCFFinanceListViewModels(exportedResults);
                string filePath = null;

                filePath = "~/FinanceTemplates/" + "ki7452v1yo" + "-CarerFinanceReport.html";
                filePath = System.Web.Hosting.HostingEnvironment.MapPath(filePath);

                string content = File.ReadAllText(filePath);
                string bodyDetail = "";
                decimal totalAmount = 0;
                foreach (var item in SLCFinanceListView)
                {
                    bodyDetail += "<tr><td>" + item.Description + "</td><td>"
                        + item.TotalAmount + "</td><td>"
                        + item.Weekly + "</td><td>"
                        + item.Daily + "</td><td>"
                        + item.NA + "</td><td>"
                        + item.CreatedByUser + "</td></tr>";
                    totalAmount += item.TotalAmount;
                }
                content = content.Replace("[BodyDetail]", bodyDetail);
                content = content.Replace("[PoundSymbol]", "(£)");
                content = content.Replace("[TotalAmount]", Convert.ToString(totalAmount));
                return ParseHtml(content);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private async Task<byte[]> GenerateCarerFinanceReportPdfForEmail(string carerId, int FinancePeriodId)
        {
            var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == FinancePeriodId);
            if (financePeriod == null)
                throw new BusinessException(Common.ErrorMessages.FeeStructures.FinancePeriodNotExists);
            try
            {
                IList<CarerFeeStructureViewModel> SLCFinanceListView = new List<CarerFeeStructureViewModel>();
                var whereclause = " where  convert(date,dbo.[SLcFeeStracture].TDate)>='" + financePeriod.StartDate.Date + "' and "
                    + " convert(date,dbo.[SLcFeeStracture].TDate)<='" + financePeriod.EndDate.Date + "'" + " and dbo.[SLcFeeStracture].CarerId = '" + carerId + "'";

                var listQuery = string.Format(
                    "Select dbo.[SLcFeeStracture].Description,dbo.[SLcFeeStracture].Amount as 'TotalAmount',case when dbo.[SLcFeeStracture].Weekly='false' then 'UnSelected' else 'Selected' end as Weekly,case when dbo.[SLcFeeStracture].Daily='false' then 'UnSelected' else 'Selected' end as Daily,case when dbo.[SLcFeeStracture].NA='false' then 'UnSelected' else 'Selected' end as 'NA',CONVERT(varchar,FORMAT(SWITCHOFFSET(CONVERT(datetime, dbo.[SLcFeeStracture].CreatedOn),DATENAME(TzOffset, SYSDATETIMEOFFSET())),'dd/MM/yyyy HH:mm')) +' by ' + CreatedByUser.FirstName + case when CreatedByUser.LastName is null  then '' else ' ' + CreatedByUser.LastName  end as 'CreatedByUser' from SLcFeeStracture left join dbo.[user] as CreatedByUser  on CreatedByUser.Id = dbo.[SLcFeeStracture].CreatedBy " + whereclause + " order by dbo.[SLcFeeStracture].Id desc");
                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                SLCFinanceListView = MapSLCFFinanceListViewModels(exportedResults);
                string filePath = null;

                filePath = "~/FinanceTemplates/" + "ki7452v1yo" + "-CarerFinanceReport.html";
                filePath = System.Web.Hosting.HostingEnvironment.MapPath(filePath);

                string content = File.ReadAllText(filePath);
                string bodyDetail = "";
                decimal totalAmount = 0;
                foreach (var item in SLCFinanceListView)
                {
                    bodyDetail += "<tr><td>" + item.Description + "</td><td>"
                        + item.TotalAmount + "</td><td>"
                        + item.Weekly + "</td><td>"
                        + item.Daily + "</td><td>"
                        + item.NA + "</td><td>"
                        + item.CreatedByUser + "</td></tr>";
                    totalAmount += item.TotalAmount;
                }
                content = content.Replace("[BodyDetail]", bodyDetail);
                content = content.Replace("[PoundSymbol]", "(£)");
                content = content.Replace("[TotalAmount]", Convert.ToString(totalAmount));
                return ParseHtml(content);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        private List<CarerFeeStructureViewModel> MapSLCFFinanceListViewModels(DataTable List)
        {
            List<CarerFeeStructureViewModel> CarerFeeStructureModel = new List<CarerFeeStructureViewModel>();
            foreach (DataRow row in List.Rows)
            {
                CarerFeeStructureViewModel item = row.GetItem<CarerFeeStructureViewModel>();
                CarerFeeStructureModel.Add(MapQualificationAttachmentViewModel(item));
            }
            return CarerFeeStructureModel;
        }


        private CarerFeeStructureViewModel MapQualificationAttachmentViewModel(CarerFeeStructureViewModel model)
        {
            var carerListViewModel = new CarerFeeStructureViewModel()
            {
                Description = model.Description,
                Weekly = model.Weekly,
                CreatedByUser = model.CreatedByUser,
                Daily = model.Daily,
                NA = model.NA,
                TotalAmount = model.TotalAmount,
            };
            return carerListViewModel;
        }

        private byte[] ParseHtml(String html)
        {
            using (MemoryStream baos = new MemoryStream())
            {
                var parser = new CustomHTMLToPdfParser();

                parser.Parse(baos, html);

                return baos.ToArray();
            }

        }
        #endregion

        #region Assign/Get Carer Holidays
        public async Task<CarerHolidaysViewModel> UpdateCarerHolidays(CarerHolidaysViewModel carerholidaysModel)
        {
            try
            {
                var tenantId = await _tenantService.GetCurrentTenantId();
                var carer = await _unitOfWork.CarerRepository.GetFirstOrDefaultAsync(a => a.Id.ToString() == carerholidaysModel.CarerId);
                var holidayLeaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(a => a.CarerId.ToString() == carerholidaysModel.CarerId);
                int totalHolidays = 0;
                if (holidayLeaveSetup != null)
                {
                    foreach (var h in holidayLeaveSetup.Where(x => x.LeaveTypeId != 2))//2 for sickness
                    {
                        totalHolidays += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                    }
                    if (carerholidaysModel.Holidays < totalHolidays)
                        throw new BusinessException(Common.ErrorMessages.Holiday.CannotUpdateHoliday);
                }

                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    CarerHolidaysViewModel oldCarerobj = new CarerHolidaysViewModel();
                    oldCarerobj = await GetCarerHolidaysById(carerholidaysModel.CarerId);
                    //Carer carerObj = new Carer();
                    carer.Holidays = carerholidaysModel.Holidays;

                    if (oldCarerobj.Holidays != carerholidaysModel.Holidays)
                    {
                        AuditTrail auditTrailbart = new AuditTrail()
                        {
                            CreatedBy = carerholidaysModel.UpdatedById,
                            CreatedOn = DateTime.UtcNow,
                            ObjectArea = Common.Constants.AuditTrailAreas.Holidays,
                            ObjectId = carerholidaysModel.CarerId.ToString(),
                            ObjectType = Common.Constants.AuditTrailAreas.SharedLiveCarer,
                            PropertyName = Common.Constants.AuditTrailAreas.Holidays.ToString(),
                            PropertyNewValue = carerholidaysModel.Holidays.ToString(),
                            PropertyOldValue = oldCarerobj.Holidays == null || oldCarerobj.Holidays == 0 ? "" : oldCarerobj.Holidays.ToString(),
                            TenantId = tenantId
                        };
                        _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                    }
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                }
                return carerholidaysModel;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<CarerHolidaysViewModel> GetCarerHolidaysById(string Id)
        {
            var carer = await _unitOfWork.CarerRepository.GetFirstOrDefaultAsync(p => p.Id.ToString() == Id);
            CarerHolidaysViewModel carrHolidayModel = new CarerHolidaysViewModel();
            carrHolidayModel.Holidays = carer.Holidays ?? 0;
            return carrHolidayModel;

        }
        #endregion

        #region Get List Leave/Holiday Setup


        public async Task<List<LeaveSetupViewModel>> GetLeaveSetupListUpdated(LeaveSetupSearchModel searchModel)
        {
            try
            {
                //var arrrayeg = getFiscalYears(searchModel.FromDate, searchModel.ToDate);
                var arrangementList = new List<Arrangement>();
                var check = 0;
                if (searchModel.Typeid == 1)
                {
                    string AttributeFilter = GetAttributeFilterForServiceUser(searchModel);
                    string UserSearch = "";
                    string filter = "";
                    string andFilter = " ";
                    if (searchModel.WildCard != null)
                    {
                        UserSearch = " (c.FirstName+' '+c.LastName like '%" + searchModel.WildCard + "%')";
                    }
                    if (UserSearch.Length > 0 || AttributeFilter.Length > 0)
                    {
                        filter = " where ";
                    }
                    if (AttributeFilter.Length > 0)
                        andFilter = " and ";
                    //var listQuery = string.Format("select * from Arrangement where ServiceUserId in ( " +
                    //                              "select distinct c.Id  from ServiceUser c where" + AttributeFilter +
                    //                               UserSearch + " )");
                    var listQuery = string.Format("select * from Arrangement where ServiceUserId  in ( " +
                                                  "select distinct c.Id  from ServiceUser c " + filter + "" + AttributeFilter +
                                                   andFilter + UserSearch + "  ) and IsArchive=0 and ((StartDate <= '" + searchModel.ToDate + "' and (EndDate >= '" + searchModel.FromDate + "' or EndDate is null)) or IsVacant=1) ");
                    var ListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                    arrangementList = await MapArrangement(ListData);
                }
                else
                {
                    string AttributeFilter = GetAttributeFilterForCarer(searchModel, 1);
                    string UserSearch = "";
                    string filter = "";
                    string andFilter = " ";
                    if (searchModel.WildCard != null)
                    {
                        //UserSearch = " (c.FirstName+' '+c.LastName like '%" + searchModel.WildCard + "')";
                        UserSearch = " (usr.FirstName+' '+usr.LastName like '%" + searchModel.WildCard + "%')";
                    }
                    if (UserSearch.Length > 0 || AttributeFilter.Length > 0)
                    {
                        filter = " where ";
                        check = 1;
                    }
                    if (AttributeFilter.Length > 0)
                        andFilter = " and ";

                    //var listQuery = string.Format("select * from Arrangement where ServiceUserId  in ( " +
                    //                            "select distinct c.Id  from ServiceUser c " + filter + "" + AttributeFilter +
                    //                           andFilter + UserSearch + "  ) and IsArchive=0 and ((StartDate >= '" + searchModel.FromDate + "' and (EndDate <= '" + searchModel.ToDate + "' or EndDate is null)) or IsVacant=1) ");

                    var listQuery = string.Format("select * from Arrangement where CarerId in ( " +
                                                 "select distinct c.Id  from Carer c inner join [User] usr on usr.Id=c.Id " + filter + "" + AttributeFilter +
                                                   andFilter + UserSearch + "  ) and IsArchive=0 and ((StartDate <= '" + Convert.ToDateTime( searchModel.ToDate).ToString("MM/dd/yyyy") + "' and (EndDate >= '" + Convert.ToDateTime(searchModel.FromDate).ToString("MM/dd/yyyy") + "' or EndDate is null)) or IsVacant=1)");
                    var ListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                    arrangementList = await MapArrangement(ListData);
                }




                DateTime Date = new DateTime(searchModel.FromDate.Value.Year, searchModel.FromDate.Value.Month, 1);
                DateTime EDate = new DateTime(searchModel.ToDate.Value.Year, searchModel.ToDate.Value.Month + 1, 1).AddDays(-1);

                int currentMonth = Date.Month;
                int currentYear = Date.Year;
                //var arrangements = arrangementList.Where(x => x.IsArchive == false && (x.StartDate == null || x.StartDate >= Date) && (x.EndDate == null ||
                // x.EndDate <= EDate));
                var arrangements = arrangementList;

                //var arrangements = arrangementList.Where(x => x.IsArchive == false  &&
                //((x.StartDate != null ? Date.Month <= x.StartDate.Value.Month : x.StartDate == null 
                //&& x.StartDate != null ? Date.Year <= x.StartDate.Value.Year : x.StartDate == null)
                //|| (x.EndDate != null ? x.EndDate.Value.Month == Date.Month && x.EndDate.Value.Year == Date.Year : x.EndDate == null)
                //|| ((x.StartDate != null ? Date.Month <= x.StartDate.Value.Month : x.StartDate == null) &&
                //(x.EndDate != null ? Date.Month <= x.EndDate.Value.Month : x.EndDate == null) &&
                //x.StartDate != null ? Date.Year <= x.StartDate.Value.Year : x.StartDate == null 
                //&& x.EndDate.Value.Year == Date.Year)));
                arrangements = arrangements.OrderByDescending(x => x.Id).ToList();

                var leaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync();
                var naturalSupport = await _unitOfWork.NaturalSupportRepository.FindAllAsync(); // salman 27/8

                //var leaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(x=>x.LeaveTypeId>0&&
                //((x.StartDate != null ? Date.Month <= x.StartDate.Month : x.StartDate == null && 
                //x.StartDate != null ? Date.Year <= x.StartDate.Year : x.StartDate == null)
                //|| (x.EndDate != null ? x.EndDate.Month == Date.Month && x.EndDate.Year == Date.Year : x.EndDate == null)
                //|| ((x.StartDate != null ? Date.Month <= x.StartDate.Month : x.StartDate == null) &&
                //(x.EndDate != null ? Date.Month <= x.EndDate.Month : x.EndDate == null) &&
                //x.StartDate != null ? Date.Year <= x.StartDate.Year : x.StartDate == null
                //&& x.EndDate.Year == Date.Year)));

                List<HolidayLeaveSetupDetail> leaveSetupDetail = new List<HolidayLeaveSetupDetail>();
                leaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync();

                //if (check != 1)
                //{
                foreach (var item in leaveSetupDetail.Where(x => x.Arrangement.IsArchive == false))
                {
                    if (item.CarerId == null)
                    {
                        var test = item;
                    }
                    //string AttributeFilter = GetAttributeFilterForCarer(searchModel, 0);
                    var arrange = arrangements.Where(x => x.CarerId.ToString() == item.CarerId.ToString() && x.ServiceUserId.ToString()
                    == item.ServiceUserId.ToString()).FirstOrDefault();
                    if (arrange == null && (item.HolidayLeaveSetup.StartDate <= searchModel.ToDate
                        && item.HolidayLeaveSetup.EndDate >= searchModel.FromDate
                            ))
                    //    item.HolidayLeaveSetup.StartDate.Month <= currentMonth && item.HolidayLeaveSetup.EndDate.Month >= currentMonth
                    //&& item.HolidayLeaveSetup.StartDate.Year <= currentYear && item.HolidayLeaveSetup.EndDate.Year >= currentYear
                    {
                        var carer = await _unitOfWork.CarerRepository.FindByIdAsync(item.CarerId); // old 
                        var naturalSupportUser = await _unitOfWork.NaturalSupportRepository.FindByIdAsync(item.NaturalSupportId);


                        // add natural support here because carer Id will be null, we need to send natural support data here
                        //if (AttributeFilter.Length > 0)
                        //{
                        //    var arrangementsList = new List<Arrangement>();
                        //    if (item.CarerId.ToString() == "d4ffdf9b-c850-489d-affe-1163a844e895")
                        //    {

                        //    }
                        //    var listQuery = string.Format("select * from UserAttribute where  " + AttributeFilter + "" + " and CarerId = '" + item.CarerId + "'");
                        //    var ListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                        //    arrangementsList = await MapArrangement(ListData);
                        //    if (arrangementsList.Count() > 0)
                        //    {
                        //        var serviceuser = await _unitOfWork.ServiceUserRepository.FindByIdAsync(item.ServiceUserId);
                        //        Arrangement arrangement = new Arrangement();
                        //        arrangement.Id = -1;
                        //        arrangement.CarerId = item.CarerId;
                        //        arrangement.Carer = carer;
                        //        arrangement.ServiceUserId = item.ServiceUserId;
                        //        arrangement.ServiceUser = serviceuser;
                        //        arrangements.Add(arrangement);



                        //    }
                        //var listQuery1 = string.Format("select * from Arrangement where id= " + item.ArrangementId + "");
                        //var ListData1 = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                        //arrangementsList = await MapArrangement(ListData);
                        //if (arrangementsList.Count() > 0)
                        //{
                        //    var serviceuser = await _unitOfWork.ServiceUserRepository.FindByIdAsync(item.ServiceUserId);
                        //    var tbl = arrangements.Where(x => x.ServiceUserId.ToString()
                        //       == item.ServiceUserId.ToString()).FirstOrDefault();
                        //    Arrangement arrangement = new Arrangement();
                        //    arrangement.Id = item.ArrangementId ?? 0;
                        //    arrangement.CarerId = item.CarerId;
                        //    arrangement.Carer = carer;
                        //    arrangement.ServiceUserId = item.ServiceUserId;
                        //    arrangement.ServiceUser = serviceuser;
                        //    arrangements.Add(arrangement);
                        //}
                        //}
                        //else
                        //{
                        var serviceuser = await _unitOfWork.ServiceUserRepository.FindByIdAsync(item.ServiceUserId);
                        //var tbl = arrangements.Where(x => x.ServiceUserId.ToString()
                        //   == item.ServiceUserId.ToString()).FirstOrDefault();
                        Arrangement arrangement = new Arrangement();
                        arrangement.Id = -1;
                        //arrangement.CarerId = item.CarerId // old
                        arrangement.CarerId = item.CarerId ?? Guid.Empty; // salman 28/8
                        arrangement.Carer = carer;
                        arrangement.NaturalSupportId = item.NaturalSupportId;
                        arrangement.NaturalSupport = naturalSupportUser;
                        arrangement.ServiceUserId = item.ServiceUserId;
                        arrangement.ServiceUser = serviceuser;
                        arrangements.Add(arrangement);
                        //}
                        //}
                    }
                }
                //}

                //foreach (var items in arrangementList)
                foreach (var items in arrangements)
                {

                    if (items.Carer == null)
                    {
                        var carer = await _unitOfWork.CarerRepository.FindByIdAsync(items.CarerId);
                        items.Carer = carer;
                    }
                    if (items.ServiceUser == null)
                    {
                        var serviceUser = await _unitOfWork.ServiceUserRepository.FindByIdAsync(items.ServiceUserId);
                        items.ServiceUser = serviceUser;
                    }
                }

                //     return MapArrangementToLeaveSetupViewModelUpdated(arrangements.ToList(), leaveSetup, leaveSetupDetail, Date, EDate); // old 
                //return MapArrangementToLeaveSetupViewModelUpdated(arrangements.ToList(), leaveSetup, leaveSetupDetail, Date, EDate, naturalSupport); // new salman 27/8, old on 11/09/2023

                // new salman 09/11
                var mappedLeaveSetupList = MapArrangementToLeaveSetupViewModelUpdated(arrangements.ToList(), leaveSetup, leaveSetupDetail, Date, EDate, naturalSupport);
                var groupedByCarerIdLeaveSetupList = mappedLeaveSetupList.GroupBy(x => x.CarerId);

                // Order the groups alphabetically by CarerName first carer Name found
                var sortedGroupedByCarerIdLeaveSetupList = groupedByCarerIdLeaveSetupList.OrderBy(x => x.FirstOrDefault()?.CarerName);

                // Flatten the sorted groups into a single list
                var returnedSortedLeaveSetupListByCarer = sortedGroupedByCarerIdLeaveSetupList
                    .SelectMany(group => group)
                    .ToList();

                return returnedSortedLeaveSetupListByCarer;
                // salman 09/11
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //  public static List<LeaveSetupViewModel> MapArrangementToLeaveSetupViewModelUpdated(List<Arrangement> arrangementList,
        //   List<HolidayLeaveSetup> holidayLeaveSetups, List<HolidayLeaveSetupDetail> holidayLeaveSetupDetails, DateTime Date, DateTime EDate)
        public static List<LeaveSetupViewModel> MapArrangementToLeaveSetupViewModelUpdated(List<Arrangement> arrangementList,
          List<HolidayLeaveSetup> holidayLeaveSetups, List<HolidayLeaveSetupDetail> holidayLeaveSetupDetails, DateTime Date, DateTime EDate, List<NaturalSupport> naturalSupport)
        {
            var leaveSetupViewModelList = new List<LeaveSetupViewModel>();
            var listdata = new List<LeaveSetupViewModel>();
            var listtwo = new List<LeaveSetupViewModel>();
            int tempRoomArragnementId = -2;
            int carerArragnementId = -1000;



            //var fiscalYears = getFiscalYears(Date, EDate); // salman 14/7
            // var thisCarer = holidayLeaveSetups.Where(x => x.CarerId.ToString() == "6BFA9F81-22CA-4BB6-8905-41E57E88549E").ToList();
            foreach (var item in arrangementList.OrderBy(x => x.CarerId))//x.Carer.User.FirstName 
            {


                if (item.IsVacant == true)
                {
                    item.StartDate = Date;
                    item.EndDate = EDate;
                }
                //if (item.CarerId.ToString() == "23278695-6e1a-465a-97e2-7b0d3da588d0")
                //{

                //}
                //var checkCarer = leaveSetupViewModelList.Where(x => x.CarerId == item.CarerId.ToString() && x.Type == null).FirstOrDefault(); // old
                dynamic checkCarer = null;
                if (item.CarerId != null && item.CarerId != Guid.Empty)
                {
                    checkCarer = leaveSetupViewModelList.Where(x => x.CarerId == item.CarerId.ToString() && x.Type == null).FirstOrDefault();
                }
                else
                {
                    checkCarer = leaveSetupViewModelList.Where(x => x.CarerId == item.NaturalSupportId.ToString() && x.Type == null).FirstOrDefault();
                }
                var totalRooms = arrangementList.Where(x => x.CarerId == item.CarerId && x.Id != -1).ToList();
                //var totalRooms = arrangementList.Where(x => x.CarerId == item.CarerId).ToList();
                // salman

                var pwsSpecificNaturalSupport = new List<NaturalSupportBindingModel>(); // Assuming NaturalSupportBindingModel is your target type

                if (naturalSupport != null && naturalSupport.Any())
                {  // here the below we are filtering the data which received as an argument in the form of Data acces layer data
                    // then we have filtered it by Pws And MAPPED it to the binding model for Business access layer
                    // means we have done two things at a time
                    pwsSpecificNaturalSupport = naturalSupport
                        .Where(x => x.ServiceUserId == item.ServiceUserId)
                        .Select(x => new NaturalSupportBindingModel
                        {
                            Id = x.Id,             // Map the Id property
                            Name = x.FirstName + " " + x.LastName,         // Map the Name property
                            ServiceUserId = x.ServiceUserId.ToString()  // Map the ServiceUserId property
                        })
                        .ToList();
                }

                // end salman
                if (checkCarer == null)
                { // this is for carer
                    carerArragnementId--;
                    var leaveSetupObj = new LeaveSetupViewModel();
                    leaveSetupObj.NaturalSupportBindingModel = pwsSpecificNaturalSupport; // salman assigning naturalsupport binding model 25/8
                    leaveSetupObj.ArrangementId = carerArragnementId;
                    if (item.CarerId != null && item.CarerId != Guid.Empty)
                    {
                        leaveSetupObj.CarerId = item.CarerId.ToString();
                        leaveSetupObj.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                        leaveSetupObj.totalHoliday = item.Carer.Holidays ?? 0;
                        leaveSetupObj.NaturalSupportId = null;
                        leaveSetupObj.ServiceUserId = item.ServiceUserId.ToString();
                    }
                    else
                    {   //salman 29/8
                        leaveSetupObj.CarerId = item.NaturalSupportId.ToString();
                        leaveSetupObj.CarerName = item.NaturalSupport.FirstName + ' ' + item.NaturalSupport.LastName;
                        leaveSetupObj.totalHoliday = 0;
                        leaveSetupObj.NaturalSupportId = item.NaturalSupportId.ToString();
                        leaveSetupObj.ServiceUserId = item.ServiceUserId.ToString();
                    }
                    //old, un commented on 14/7
                    // item.Carer.Holidays??0 means if it is null we are sending 0
                    //leaveSetupObj.totalHoliday = getTotalHolidayBetweenDates(item.Carer.Holidays ?? 0, Date, EDate); // new salman 11/7, commented on 14/7
                    leaveSetupObj.TotalRooms = totalRooms.Count();
                    leaveSetupViewModelList.Add(leaveSetupObj);
                    listdata.Add(leaveSetupObj);
                    listtwo.Add(leaveSetupObj);
                    int ConsumedHoliday = 0;
                    int SicknessHoliday = 0;
                    List<CarerHolidayData> fiscalDatesWithCarer = new List<CarerHolidayData>(); // salman 14/7
                    foreach (var h in holidayLeaveSetups.Where(x => x.CarerId.ToString() == item.CarerId.ToString()))
                    {


                        //var HolidayDetail = h.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false && h.Id == x.HolidayLeaveSetupId).ToList();
                        //if (HolidayDetail.Count() > 0)
                        //{
                        //    if (h.LeaveTypeId != 2)//2 for sickness
                        //        ConsumedHoliday += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                        //    else
                        //        SicknessHoliday += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                        //}

                        // 14/7 this if else is of not use now, but I did not removed it to avoid any issue in working functionality
                        // I have implemented the logic for holidays and sick leaves below, now sending the object arerHolidayDataBindingModel at frontend which contain holidaytype property to differentiate between sick or normal holidays
                        if (h.LeaveTypeId != 2)//2 for sickness
                            ConsumedHoliday += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                        else
                            SicknessHoliday += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                        // salman
                        // we have removed if else for holidays or sickleaves, not it will send the type in the object
                        // steps:
                        // step 1: we will send h.StartDate and h.EndDate to a function, it will return us dates with respect to fiscal year 
                        var totalFiscalDatesInHolidays = calculateFiscalDates(h.StartDate, h.EndDate);
                        // step 2: then we will send those dates to the another function that will calculate the days in the date range they will be according to fiscal year 

                        if (totalFiscalDatesInHolidays.Any())
                        {

                            foreach (var date in totalFiscalDatesInHolidays)
                            {
                                var totalFiscalHolidays = calculateFiscalHolidays(date.StartDate, date.EndDate, item.CarerId, h.LeaveTypeId);
                                leaveSetupObj.carerHolidayDataBindingModel.Add(totalFiscalHolidays); // these insertions will become invalid(means will not be sent at frontend, they will be sent as one for each fiscal year) when we group them below after foreach loop
                            }
                        }

                    }
                    // leaveSetupObj.carerHolidayDataBindingModel= fiscalDatesWithCarer; // salman 14/7

                    // below code is for grouping the holidays of a carer with respect to year
                    // fiscal is settled before, the below code has nothing to do with fiscal year creation logic
                    //  below code is used to sum up all the holiday of a fiscal year for example, if fiscal year is 2023, if it has 4 records in the list, this code will group them and make them one record, based on fiscal year and leavetypeid, holiday type is basically leavetype which is 1 for holidays and 2 for sickleaves
                    // before we have implemented the logic like that, if date is in different years then the smaller year will be considered as fiscal year
                    // fiscal year starts from 1st april and ends at 31st march
                    List<CarerHolidayData> carerHolidayDataList = leaveSetupObj.carerHolidayDataBindingModel;
                    // Group the holidays by fiscal year and leave type ID, and sum the holidays within each group
                    var groupedHolidays = carerHolidayDataList
                        .GroupBy(holiday => new { holiday.FiscalYear, holiday.HolidayType })
                        .Select(group => new CarerHolidayData
                        {
                            FiscalYear = group.Key.FiscalYear,
                            CarerId = group.First().CarerId, // Assuming CarerId remains the same within each group
                            HolidayType = group.Key.HolidayType,
                            Holidays = group.Sum(holiday => holiday.Holidays)
                        })
                        .ToList();
                    leaveSetupObj.carerHolidayDataBindingModel = groupedHolidays;
                    leaveSetupObj.NaturalSupportBindingModel = pwsSpecificNaturalSupport; // salman temp 25/8
                                                                                          // after all the grouping it will insert each record for each fiscal year 
                                                                                          // end grouping
                                                                                          // 112D7DE1 - 7355 - 4259 - AC03 - 023D3F08042C sick leave 28, holidays 21 in 2023
                                                                                          // 6BFA9F81-22CA-4BB6-8905-41E57E88549E // holidays 24 in 2023
                                                                                          // 0B555E06-C0FF-4696-97D3-3261234DC225 // 2023 holidays 11, 2024 5 
                    /* for test
                    if (item.CarerId == new Guid("0B555E06-C0FF-4696-97D3-3261234DC225"))
                    {
                        var Tabaco = "test";
                    }
                    */

                    leaveSetupObj.ConsumedHoliday = ConsumedHoliday;
                    leaveSetupObj.SicknessHoliday = SicknessHoliday;
                }
                if (item.Id > 0)
                { // this code is for arrangement room, if id>0 they are rooms, if <0 they are carer

                    var getholiday = holidayLeaveSetups.Where(x => x.CarerId.ToString() == item.CarerId.ToString()).ToList();

                    var leaveSetup = new LeaveSetupViewModel();
                    leaveSetup.NaturalSupportBindingModel = pwsSpecificNaturalSupport; // salman 25/8

                    int flg = 0;

                    foreach (var holiday in getholiday)
                    {
                        var ActualEndDate = item.EndDate == null ? EDate : item.EndDate;
                        //if (Date <= holiday.StartDate && leaveSetup.ArrangementId == 0)
                        if (holiday.StartDate <= EDate && holiday.EndDate >= Date && leaveSetup.ArrangementId == 0) // For Salman updated Line
                        {

                            leaveSetup.LeaveSetupId = holiday.Id;
                            leaveSetup.CarerId = item.CarerId.ToString();
                            leaveSetup.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                            leaveSetup.PwsId = item.ServiceUserId.ToString();
                            if (item.ServiceUserId != null)
                                leaveSetup.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                            leaveSetup.RoomName = item.RoomName;
                            leaveSetup.RoomStartDate = holiday.StartDate;
                            leaveSetup.ActualRoomEndDate = holiday.EndDate;
                            leaveSetup.ActualArrangementEndDate = item.EndDate;
                            leaveSetup.IsVacant = item.IsVacant ?? false;
                            leaveSetup.ActualRoomStartDate = item.StartDate;
                            leaveSetup.RoomEndDate = Convert.ToDateTime(holiday.EndDate).AddDays(1);
                            leaveSetup.ArrangementId = item.Id;
                            if (holiday.LeaveTypeId == 1)
                                leaveSetup.Type = "Holiday";
                            else if (holiday.LeaveTypeId == 2)
                                leaveSetup.Type = "Sick";
                            leaveSetup.Subject = holiday.LeaveTypeId == 1 ? "Holiday" : "SicK";
                            leaveSetup.HolidayDays = Convert.ToInt32((holiday.EndDate - holiday.StartDate).TotalDays) + 1;
                            flg = 1;
                        }
                        else
                        {
                            var HolidayModel = new LeaveSetupHolidayViewModel();
                            HolidayModel.LeaveSetupId = holiday.Id;
                            HolidayModel.ArrangementId = item.Id;
                            HolidayModel.IsVacant = item.IsVacant ?? false;
                            HolidayModel.RoomStartDate = holiday.StartDate;
                            //if (item.EndDate == null)
                            //    HolidayModel.RoomEndDate = CurrenMonthendDate;// DateTime.Now;
                            //else
                            HolidayModel.RoomName = item.RoomName;
                            HolidayModel.ActualRoomEndDate = holiday.EndDate;
                            HolidayModel.ActualArrangementEndDate = item.EndDate;

                            HolidayModel.RoomEndDate = Convert.ToDateTime(holiday.EndDate).AddDays(1);
                            // HolidayModel.ActualRoomEndDate = ActualEndDate;
                            HolidayModel.PwsId = item.ServiceUserId.ToString();
                            if (item.ServiceUserId != null)
                                HolidayModel.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                            HolidayModel.ActualArrangementEndDate = item.EndDate;
                            HolidayModel.ActualRoomStartDate = item.StartDate;
                            if (holiday.LeaveTypeId == 1)
                                HolidayModel.Type = "Holiday";
                            else if (holiday.LeaveTypeId == 2)
                                HolidayModel.Type = "Sick";
                            HolidayModel.Subject = holiday.LeaveTypeId == 1 ? "Holiday" : "SicK";
                            HolidayModel.HolidayDays = Convert.ToInt32((holiday.EndDate - holiday.StartDate).TotalDays) + 1;
                            var arrang = arrangementList.Where(x => x.Id == item.Id && x.IsArchive == false).FirstOrDefault();

                            //if (flg == 1 && arrang != null)
                            if (flg == 1 && arrang != null && holiday.StartDate <= EDate && holiday.EndDate >= Date) // For Salman updated Line
                            {
                                leaveSetup.holidayBindingModel.Add(HolidayModel);
                            }
                        }
                    }
                    var CurrenMonthendDate = EDate;
                    var roomStartDate = item.StartDate;
                    while (roomStartDate <= (item.EndDate == null ? CurrenMonthendDate : item.EndDate))
                    {
                        var ActualEndDate = item.EndDate == null ? CurrenMonthendDate : item.EndDate;
                        var holiday = getholiday.FirstOrDefault(h => h.StartDate <= roomStartDate && h.EndDate >= roomStartDate);
                        List<HolidayLeaveSetupDetail> holidayActive = new List<HolidayLeaveSetupDetail>();

                        if (holiday != null)
                        {

                            // Add holiday
                            leaveSetup.Id = holiday.Id;
                            var HolidayModel = new LeaveSetupHolidayViewModel();
                            HolidayModel.LeaveSetupId = holiday.Id;
                            HolidayModel.ArrangementId = item.Id;
                            HolidayModel.IsVacant = item.IsVacant ?? false;
                            HolidayModel.RoomStartDate = holiday.StartDate;

                            //if (item.EndDate == null)
                            //    HolidayModel.RoomEndDate = CurrenMonthendDate;// DateTime.Now;
                            //else
                            HolidayModel.RoomEndDate = Convert.ToDateTime(holiday.EndDate).AddDays(1);
                            HolidayModel.ActualRoomEndDate = ActualEndDate;
                            HolidayModel.ActualArrangementEndDate = item.EndDate;
                            HolidayModel.ActualRoomStartDate = item.StartDate;
                            if (holiday.LeaveTypeId == 1)
                                HolidayModel.Type = "Holiday";
                            else if (holiday.LeaveTypeId == 2)
                                HolidayModel.Type = "Sick";
                            HolidayModel.Subject = holiday.LeaveTypeId == 1 ? "Holiday" : "SicK";
                            HolidayModel.HolidayDays = Convert.ToInt32((holiday.EndDate - holiday.StartDate).TotalDays) + 1;
                            var arrang = arrangementList.Where(x => x.Id == item.Id && x.IsArchive == false).FirstOrDefault();

                            if (flg == 1 && arrang != null)
                            {
                                // leaveSetup.holidayBindingModel.Add(HolidayModel);
                            }


                            roomStartDate = holiday.EndDate.AddDays(1);
                        }
                        else
                        {
                            // Add event
                            var check = leaveSetupViewModelList.Where(x => x.ArrangementId == item.Id);
                            if (flg == 0)
                            {

                                var nextHoliday = getholiday.FirstOrDefault(h => h.StartDate > roomStartDate && h.StartDate <= ActualEndDate);
                                var nextHoldayStartDate = new DateTime();
                                var nextHoldayEndDate = new DateTime();
                                if (nextHoliday == null)
                                {
                                    nextHoldayStartDate = ActualEndDate.Value.AddDays(1);
                                    nextHoldayEndDate = ActualEndDate.Value.AddDays(1);
                                    //nextHoliday = new LeaveSetupHolidayViewModel() { StartDate = item.EndDate.AddDays(1), EndDate = item.EndDate.AddDays(1) };
                                }
                                else
                                {
                                    nextHoldayStartDate = nextHoliday.StartDate;
                                    nextHoldayEndDate = nextHoliday.EndDate;
                                }
                                leaveSetup.IsVacant = item.IsVacant ?? false;
                                leaveSetup.CarerId = item.CarerId.ToString();
                                leaveSetup.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                                leaveSetup.PwsId = item.ServiceUserId.ToString();
                                if (item.ServiceUserId != null)
                                    leaveSetup.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                                leaveSetup.RoomName = item.RoomName;
                                leaveSetup.RoomStartDate = roomStartDate;
                                leaveSetup.ActualRoomEndDate = ActualEndDate;
                                leaveSetup.ActualArrangementEndDate = item.EndDate;

                                leaveSetup.ActualRoomStartDate = item.StartDate;
                                if (item.EndDate == null && CurrenMonthendDate == nextHoldayStartDate.AddDays(-1))//for just showing arrow on last date of current month on frontend when end date null 
                                {
                                    leaveSetup.RoomEndDate = CurrenMonthendDate.AddDays(2);//-1
                                }
                                else
                                if (item.EndDate == null && holiday == null)
                                    leaveSetup.RoomEndDate = nextHoldayStartDate.AddDays(0);
                                else
                                    leaveSetup.RoomEndDate = nextHoldayStartDate.AddDays(0);//-1
                                leaveSetup.ArrangementId = item.Id;
                                roomStartDate = nextHoldayStartDate;
                                flg = 1;
                                // leaveSetupViewModelList.Add(leaveSetups);
                            }
                            else
                            {
                                var HolidayModel = new LeaveSetupHolidayViewModel();
                                var nextHoliday = getholiday.FirstOrDefault(h => h.StartDate > roomStartDate && h.StartDate <= ActualEndDate);
                                var nextHoldayStartDate = new DateTime();
                                var nextHoldayEndDate = new DateTime();
                                if (nextHoliday == null)
                                {
                                    nextHoldayStartDate = ActualEndDate.Value.AddDays(1);
                                    nextHoldayEndDate = ActualEndDate.Value.AddDays(1);
                                    //nextHoliday = new LeaveSetupHolidayViewModel() { StartDate = item.EndDate.AddDays(1), EndDate = item.EndDate.AddDays(1) };
                                }
                                else
                                {
                                    nextHoldayStartDate = nextHoliday.StartDate;
                                    nextHoldayEndDate = nextHoliday.EndDate;
                                }
                                HolidayModel.CarerId = item.CarerId.ToString();
                                HolidayModel.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                                HolidayModel.PwsId = item.ServiceUserId.ToString();
                                if (item.ServiceUserId != null)
                                    HolidayModel.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                                HolidayModel.RoomName = item.RoomName;
                                HolidayModel.RoomStartDate = roomStartDate;
                                HolidayModel.ActualRoomEndDate = ActualEndDate;
                                HolidayModel.ActualArrangementEndDate = item.EndDate;
                                HolidayModel.IsVacant = item.IsVacant ?? false;
                                HolidayModel.ActualRoomStartDate = item.StartDate;
                                if (item.EndDate == null && CurrenMonthendDate == nextHoldayStartDate.AddDays(-1))//for just showing arrow on last date of current month on frontend when end date null
                                                                                                                  //HolidayModel.RoomEndDate = CurrenMonthendDate;// DateTime.Now;
                                {
                                    HolidayModel.RoomEndDate = CurrenMonthendDate.AddDays(2);//-1
                                }
                                else
                                    HolidayModel.RoomEndDate = nextHoldayStartDate.AddDays(0);//-1
                                HolidayModel.ArrangementId = item.Id;
                                roomStartDate = nextHoldayStartDate;
                                leaveSetup.holidayBindingModel.Add(HolidayModel);
                            }
                        }
                    }

                    if (leaveSetup.ArrangementId != 0)
                    {
                        leaveSetupViewModelList.Add(leaveSetup);
                        listdata.Add(leaveSetup);
                        listtwo.Add(leaveSetup);
                    }

                }
                //foreach (var holidayDetail in holidayLeaveSetupDetails.Where(x => x.CarerId == item.CarerId)) // old
                foreach (var holidayDetail in holidayLeaveSetupDetails.Where(x => x.CarerId == item.CarerId || (item.NaturalSupportId != null && x.NaturalSupportId == item.NaturalSupportId))) // salman 29/8

                {
                    var check = leaveSetupViewModelList.Where(x => x.TId == holidayDetail.Id).FirstOrDefault();
                    //if (item.CarerId.ToString() == "d4ffdf9b-c850-489d-affe-1163a844e895")
                    //{

                    //}
                    if (check == null)
                    {
                        var arrang = arrangementList.Where(x => x.Id == holidayDetail.ArrangementId && x.IsVacant != true).FirstOrDefault();
                        if (arrang != null)
                        {
                            // var result = leaveSetupViewModelList.Where(x => x.CarerId == item.CarerId.ToString() && x.PwsId == item.ServiceUserId.ToString() && x.Type == "Temporary" && x.RoomName == arrang.RoomName).FirstOrDefault(); // old 
                            // new 31/8
                            dynamic result = null;
                            if (item.CarerId != null && item.CarerId != Guid.Empty)
                            {
                                result = leaveSetupViewModelList.Where(x => x.CarerId == item.CarerId.ToString() && x.PwsId == item.ServiceUserId.ToString() && x.Type == "Temporary" && x.RoomName == arrang.RoomName).FirstOrDefault();
                            }
                            else
                            {
                                result = leaveSetupViewModelList.Where(x => x.CarerId == item.NaturalSupportId.ToString() && x.PwsId == item.ServiceUserId.ToString() && x.Type == "Temporary" && x.RoomName == arrang.RoomName).FirstOrDefault();
                            }
                            // end 31/8
                            var leaveSetups = new LeaveSetupViewModel();
                            leaveSetups.NaturalSupportBindingModel = pwsSpecificNaturalSupport; //salman natural support 25/8
                            leaveSetups.TId = holidayDetail.Id;
                            leaveSetups.Id = holidayDetail.HolidayLeaveSetupId;
                            leaveSetups.TempArrangementId = holidayDetail.ArrangementId ?? 0;
                            if (result != null)
                            {
                                leaveSetups.ArrangementId = result.ArrangementId;
                            }
                            else
                            {
                                leaveSetups.ArrangementId = tempRoomArragnementId--;
                            }
                            //leaveSetups.CarerId = item.CarerId.ToString(); // old
                            // new based on condition 29/8
                            if (item.CarerId != null && item.CarerId != Guid.Empty)
                            {
                                leaveSetups.CarerId = item.CarerId.ToString();
                                leaveSetups.ArrangementTypeId = holidayDetail.ArrangementTypeId ?? 0;
                            }
                            else
                            {
                                leaveSetups.CarerId = item.NaturalSupportId.ToString();
                                leaveSetups.ArrangementTypeId = 3; // it is not a good approach we need to add this while inserting in the holidayleavesetupdetail table, but for now we are doing it static
                            }

                            leaveSetups.PwsId = item.ServiceUserId.ToString();
                            if (arrang != null) // old
                            //if (arrang != null && (item.CarerId != null && item.CarerId != Guid.Empty)) // salman 29/8
                            {
                                leaveSetups.CarerName = arrang.Carer.User.FirstName + ' ' + arrang.Carer.User.LastName;
                                leaveSetups.RoomName = arrang.RoomName;
                                leaveSetups.PwsName = arrang.ServiceUser.FirstName + ' ' + arrang.ServiceUser.LastName;
                            }
                            /*
                            if (arrang != null && (item.NaturalSupportId != null && item.NaturalSupportId != Guid.Empty)) // salman 29/8
                            {
                                leaveSetups.CarerName = arrang.NaturalSupport.FirstName + ' ' + arrang.NaturalSupport.LastName;
                                leaveSetups.RoomName = arrang.RoomName;
                                leaveSetups.PwsName = arrang.ServiceUser.FirstName + ' ' + arrang.ServiceUser.LastName;
                            }
                            */
                            leaveSetups.RoomStartDate = holidayDetail.StartDate;
                            leaveSetups.HolidayDays = Convert.ToInt32((holidayDetail.EndDate - holidayDetail.StartDate).TotalDays) + 1;
                            leaveSetups.RoomEndDate = Convert.ToDateTime(holidayDetail.EndDate).AddDays(1);
                            leaveSetups.Type = "Temporary";
                            //leaveSetups.ArrangementTypeId = holidayDetail.ArrangementTypeId ?? 0; // moved this code to condition of NaturalSupportId or CarerId
                            leaveSetupViewModelList.Add(leaveSetups);
                            listdata.Add(leaveSetups);
                            listtwo.Add(leaveSetups);
                        }
                    }
                }
            }

            return leaveSetupViewModelList;
        }
        public async Task<List<LeaveSetupViewModel>> GetLeaveSetupList(DateTime Date)
        {
            try
            {
                DateTime searchFromDate = Date;
                // DateTime searchToDate = toDate;

                int currentMonth = Date.Month;
                int currentYear = Date.Year;
                var arrangements = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.IsArchive == false && x.IsVacant != true && ((x.StartDate != null ? Date.Month <= x.StartDate.Value.Month : x.StartDate == null && x.StartDate != null ? Date.Year <= x.StartDate.Value.Year : x.StartDate == null)
                || (x.EndDate != null ? x.EndDate.Value.Month == Date.Month && x.EndDate.Value.Year == Date.Year : x.EndDate == null)
                || ((x.StartDate != null ? Date.Month <= x.StartDate.Value.Month : x.StartDate == null) && (x.EndDate != null ? Date.Month <= x.EndDate.Value.Month : x.EndDate == null) && x.StartDate != null ? Date.Year <= x.StartDate.Value.Year : x.StartDate == null && x.EndDate.Value.Year == Date.Year)));
                arrangements = arrangements.OrderByDescending(x => x.Id).ToList();
                var leaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync();
                //x => (x.StartDate.Month == Date.Month && x.StartDate.Year == Date.Year) && (x.EndDate.Month == Date.Month && x.EndDate.Year == Date.Year)
                //&& (Date.Month >= x.StartDate.Month && Date.Month <= x.EndDate.Month)
                List<HolidayLeaveSetupDetail> leaveSetupDetail = new List<HolidayLeaveSetupDetail>();
                leaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync();


                foreach (var item in leaveSetupDetail.Where(x => x.Arrangement.IsArchive == false))
                {
                    var arrange = arrangements.Where(x => x.CarerId.ToString() == item.CarerId.ToString() && x.ServiceUserId.ToString()
                    == item.ServiceUserId.ToString()).FirstOrDefault();
                    if (arrange == null && (item.StartDate.Month <= currentMonth && item.EndDate.Month >= currentMonth
                        && item.StartDate.Year <= currentYear && item.EndDate.Year >= currentYear))
                    {
                        var carer = await _unitOfWork.CarerRepository.FindByIdAsync(item.CarerId);
                        var serviceuser = await _unitOfWork.ServiceUserRepository.FindByIdAsync(item.ServiceUserId);
                        var tbl = arrangements.Where(x => x.ServiceUserId.ToString()
                           == item.ServiceUserId.ToString()).FirstOrDefault();
                        Arrangement arrangement = new Arrangement();
                        arrangement.Id = -1;
                        //arrangement.CarerId = item.CarerId
                        arrangement.CarerId = item.CarerId ?? Guid.Empty;// salman 28/8
                        arrangement.Carer = carer;
                        arrangement.ServiceUserId = item.ServiceUserId;
                        arrangement.ServiceUser = serviceuser;
                        arrangements.Add(arrangement);
                    }
                }
                return MapArrangementToLeaveSetupViewModel(arrangements, leaveSetup, leaveSetupDetail, Date);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static List<LeaveSetupViewModel> MapArrangementToLeaveSetupViewModel(List<Arrangement> arrangementList,
            List<HolidayLeaveSetup> holidayLeaveSetups, List<HolidayLeaveSetupDetail> holidayLeaveSetupDetails, DateTime Date)
        {
            var leaveSetupViewModelList = new List<LeaveSetupViewModel>();
            var listdata = new List<LeaveSetupViewModel>();
            var listtwo = new List<LeaveSetupViewModel>();
            int tempRoomArragnementId = -2;
            int carerArragnementId = -1000;
            foreach (var item in arrangementList.OrderBy(x => x.CarerId))
            {
                var checkCarer = leaveSetupViewModelList.Where(x => x.CarerId == item.CarerId.ToString() && x.Type == null).FirstOrDefault();
                var totalRooms = arrangementList.Where(x => x.CarerId == item.CarerId && x.Id != -1).ToList();
                if (checkCarer == null)
                {
                    carerArragnementId--;
                    var leaveSetupObj = new LeaveSetupViewModel();
                    leaveSetupObj.ArrangementId = carerArragnementId;
                    leaveSetupObj.CarerId = item.CarerId.ToString();
                    leaveSetupObj.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                    leaveSetupObj.totalHoliday = item.Carer.Holidays ?? 0;
                    leaveSetupObj.TotalRooms = totalRooms.Count();
                    leaveSetupViewModelList.Add(leaveSetupObj);
                    listdata.Add(leaveSetupObj);
                    listtwo.Add(leaveSetupObj);
                    int ConsumedHoliday = 0;
                    int SicknessHoliday = 0;
                    // salman
                    List<CarerHolidayData> carerHolidays = new List<CarerHolidayData>();
                    // end salman
                    foreach (var h in holidayLeaveSetups.Where(x => x.CarerId.ToString() == item.CarerId.ToString()))
                    {
                        var HolidayDetail = h.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false && h.Id == x.HolidayLeaveSetupId).ToList();
                        if (HolidayDetail.Count() > 0)
                        {
                            List<CarerHolidayData> fiscalDates = new List<CarerHolidayData>();
                            if (h.LeaveTypeId != 2)//2 for sickness
                                ConsumedHoliday += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                            else
                                SicknessHoliday += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                        }
                    }
                    leaveSetupObj.ConsumedHoliday = ConsumedHoliday;
                    leaveSetupObj.SicknessHoliday = SicknessHoliday;
                }
                if (item.Id > 0)
                {
                    //if (item.EndDate == null)
                    //    item.EndDate = DateTime.Now;

                    var getholiday = holidayLeaveSetups.Where(x => x.CarerId.ToString() == item.CarerId.ToString()).ToList();

                    var leaveSetup = new LeaveSetupViewModel();

                    int flg = 0;
                    var roomStartDate = item.StartDate;
                    //if (item.CarerId.ToString() == "3fb88b05-34e6-4049-8d1a-ef9a64561a5f")
                    //{

                    //}
                    var CurrenMonthendDate = Date.AddMonths(1).AddDays(-1).Date;
                    while (roomStartDate <= (item.EndDate == null ? CurrenMonthendDate : item.EndDate))
                    {
                        var ActualEndDate = item.EndDate == null ? CurrenMonthendDate : item.EndDate;
                        var holiday = getholiday.FirstOrDefault(h => h.StartDate <= roomStartDate && h.EndDate >= roomStartDate);
                        List<HolidayLeaveSetupDetail> holidayActive = new List<HolidayLeaveSetupDetail>();
                        //if (holiday != null)
                        //    foreach (var h in getholiday.Where(h => h.StartDate <= roomStartDate && h.EndDate >= roomStartDate))
                        //    {
                        //        holidayActive = h.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false).ToList();
                        //        if (holidayActive.Count() > 0)
                        //        {
                        //            break;
                        //        }
                        //    }

                        //if (holiday != null && holidayActive.Count() > 0)
                        if (holiday != null)
                        {
                            // Add holiday
                            leaveSetup.Id = holiday.Id;
                            var HolidayModel = new LeaveSetupHolidayViewModel();
                            HolidayModel.LeaveSetupId = holiday.Id;
                            HolidayModel.ArrangementId = item.Id;
                            HolidayModel.RoomStartDate = holiday.StartDate;
                            //if (item.EndDate == null)
                            //    HolidayModel.RoomEndDate = CurrenMonthendDate;// DateTime.Now;
                            //else
                            HolidayModel.RoomEndDate = Convert.ToDateTime(holiday.EndDate).AddDays(1);
                            HolidayModel.ActualRoomEndDate = ActualEndDate;
                            HolidayModel.ActualArrangementEndDate = item.EndDate;
                            HolidayModel.ActualRoomStartDate = item.StartDate;
                            if (holiday.LeaveTypeId == 1)
                                HolidayModel.Type = "Holiday";
                            else if (holiday.LeaveTypeId == 2)
                                HolidayModel.Type = "Sick";
                            HolidayModel.Subject = holiday.LeaveTypeId == 1 ? "Holiday" : "SicK";
                            HolidayModel.HolidayDays = Convert.ToInt32((holiday.EndDate - holiday.StartDate).TotalDays) + 1;
                            var arrang = arrangementList.Where(x => x.Id == item.Id && x.IsArchive == false).FirstOrDefault();

                            if (flg == 1 && arrang != null)
                                leaveSetup.holidayBindingModel.Add(HolidayModel);
                            else if (arrang != null) //code for when arrange start date and end date equal to holiday start and end date
                            {
                                flg = 1;
                                leaveSetup.LeaveSetupId = holiday.Id;
                                leaveSetup.CarerId = item.CarerId.ToString();
                                leaveSetup.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                                leaveSetup.PwsId = item.ServiceUserId.ToString();
                                leaveSetup.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                                leaveSetup.RoomName = item.RoomName;
                                leaveSetup.RoomStartDate = holiday.StartDate;
                                leaveSetup.ActualRoomEndDate = ActualEndDate;
                                leaveSetup.ActualArrangementEndDate = item.EndDate;

                                leaveSetup.ActualRoomStartDate = item.StartDate;
                                //if (item.EndDate == null)
                                //    leaveSetup.RoomEndDate = CurrenMonthendDate;// DateTime.Now;
                                //else
                                leaveSetup.RoomEndDate = Convert.ToDateTime(holiday.EndDate).AddDays(1);
                                leaveSetup.ArrangementId = item.Id;
                                if (holiday.LeaveTypeId == 1)
                                    leaveSetup.Type = "Holiday";
                                else if (holiday.LeaveTypeId == 2)
                                    leaveSetup.Type = "Sick";
                                leaveSetup.Subject = holiday.LeaveTypeId == 1 ? "Holiday" : "SicK";
                                leaveSetup.HolidayDays = Convert.ToInt32((holiday.EndDate - holiday.StartDate).TotalDays) + 1;
                            }
                            roomStartDate = holiday.EndDate.AddDays(1);
                        }
                        else
                        {
                            // Add event
                            var check = leaveSetupViewModelList.Where(x => x.ArrangementId == item.Id);
                            if (flg == 0)
                            {

                                var nextHoliday = getholiday.FirstOrDefault(h => h.StartDate > roomStartDate && h.StartDate <= ActualEndDate);
                                var nextHoldayStartDate = new DateTime();
                                var nextHoldayEndDate = new DateTime();
                                if (nextHoliday == null)
                                {
                                    nextHoldayStartDate = ActualEndDate.Value.AddDays(1);
                                    nextHoldayEndDate = ActualEndDate.Value.AddDays(1);
                                    //nextHoliday = new LeaveSetupHolidayViewModel() { StartDate = item.EndDate.AddDays(1), EndDate = item.EndDate.AddDays(1) };
                                }
                                else
                                {
                                    nextHoldayStartDate = nextHoliday.StartDate;
                                    nextHoldayEndDate = nextHoliday.EndDate;
                                }
                                leaveSetup.CarerId = item.CarerId.ToString();
                                leaveSetup.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                                leaveSetup.PwsId = item.ServiceUserId.ToString();
                                leaveSetup.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                                leaveSetup.RoomName = item.RoomName;
                                leaveSetup.RoomStartDate = roomStartDate;
                                leaveSetup.ActualRoomEndDate = ActualEndDate;
                                leaveSetup.ActualArrangementEndDate = item.EndDate;

                                leaveSetup.ActualRoomStartDate = item.StartDate;
                                if (item.EndDate == null && CurrenMonthendDate == nextHoldayStartDate.AddDays(-1))//for just showing arrow on last date of current month on frontend when end date null 
                                {
                                    leaveSetup.RoomEndDate = CurrenMonthendDate.AddDays(2);//-1
                                }
                                else
                                if (item.EndDate == null && holiday == null)
                                    leaveSetup.RoomEndDate = nextHoldayStartDate.AddDays(0);
                                else
                                    leaveSetup.RoomEndDate = nextHoldayStartDate.AddDays(0);//-1
                                leaveSetup.ArrangementId = item.Id;
                                roomStartDate = nextHoldayStartDate;
                                flg = 1;
                                // leaveSetupViewModelList.Add(leaveSetups);
                            }
                            else
                            {
                                var HolidayModel = new LeaveSetupHolidayViewModel();
                                var nextHoliday = getholiday.FirstOrDefault(h => h.StartDate > roomStartDate && h.StartDate <= ActualEndDate);
                                var nextHoldayStartDate = new DateTime();
                                var nextHoldayEndDate = new DateTime();
                                if (nextHoliday == null)
                                {
                                    nextHoldayStartDate = ActualEndDate.Value.AddDays(1);
                                    nextHoldayEndDate = ActualEndDate.Value.AddDays(1);
                                    //nextHoliday = new LeaveSetupHolidayViewModel() { StartDate = item.EndDate.AddDays(1), EndDate = item.EndDate.AddDays(1) };
                                }
                                else
                                {
                                    nextHoldayStartDate = nextHoliday.StartDate;
                                    nextHoldayEndDate = nextHoliday.EndDate;
                                }
                                HolidayModel.CarerId = item.CarerId.ToString();
                                HolidayModel.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                                HolidayModel.PwsId = item.ServiceUserId.ToString();
                                HolidayModel.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                                HolidayModel.RoomName = item.RoomName;
                                HolidayModel.RoomStartDate = roomStartDate;
                                HolidayModel.ActualRoomEndDate = ActualEndDate;
                                HolidayModel.ActualArrangementEndDate = item.EndDate;

                                HolidayModel.ActualRoomStartDate = item.StartDate;
                                if (item.EndDate == null && CurrenMonthendDate == nextHoldayStartDate.AddDays(-1))//for just showing arrow on last date of current month on frontend when end date null
                                                                                                                  //HolidayModel.RoomEndDate = CurrenMonthendDate;// DateTime.Now;
                                {
                                    HolidayModel.RoomEndDate = CurrenMonthendDate.AddDays(2);//-1
                                }
                                else
                                    HolidayModel.RoomEndDate = nextHoldayStartDate.AddDays(0);//-1
                                HolidayModel.ArrangementId = item.Id;
                                roomStartDate = nextHoldayStartDate;
                                leaveSetup.holidayBindingModel.Add(HolidayModel);
                            }
                        }
                    }
                    //if (item.EndDate == null)
                    //{
                    //    leaveSetup.CarerId = item.CarerId.ToString();
                    //    leaveSetup.CarerName = item.Carer.User.FirstName + ' ' + item.Carer.User.LastName;
                    //    leaveSetup.PwsId = item.ServiceUserId.ToString();
                    //    leaveSetup.PwsName = item.ServiceUser.FirstName + ' ' + item.ServiceUser.LastName;
                    //    leaveSetup.RoomName = item.RoomName;
                    //    leaveSetup.RoomStartDate = item.StartDate;
                    //    if (item.EndDate == null)
                    //        leaveSetup.RoomEndDate = null;
                    //    else
                    //        leaveSetup.RoomEndDate = Convert.ToDateTime(item.EndDate).AddDays(1);
                    //    leaveSetup.ArrangementId = item.Id;
                    //}
                    if (leaveSetup.ArrangementId != 0)
                    {
                        leaveSetupViewModelList.Add(leaveSetup);
                        listdata.Add(leaveSetup);
                        listtwo.Add(leaveSetup);
                    }
                }
                foreach (var holidayDetail in holidayLeaveSetupDetails.Where(x => x.CarerId == item.CarerId))
                {
                    var check = leaveSetupViewModelList.Where(x => x.TId == holidayDetail.Id).FirstOrDefault();

                    if (check == null)
                    {
                        var arrang = arrangementList.Where(x => x.Id == holidayDetail.ArrangementId).FirstOrDefault();
                        if (arrang != null)
                        {
                            var result = leaveSetupViewModelList.Where(x => x.CarerId == item.CarerId.ToString() && x.PwsId == item.ServiceUserId.ToString() && x.Type == "Temporary" && x.RoomName == arrang.RoomName).FirstOrDefault();
                            var leaveSetups = new LeaveSetupViewModel();
                            leaveSetups.TId = holidayDetail.Id;
                            leaveSetups.Id = holidayDetail.HolidayLeaveSetupId;
                            leaveSetups.TempArrangementId = holidayDetail.ArrangementId ?? 0;
                            if (result != null)
                            {
                                leaveSetups.ArrangementId = result.ArrangementId;
                            }
                            else
                            {
                                leaveSetups.ArrangementId = tempRoomArragnementId--;
                            }
                            leaveSetups.CarerId = item.CarerId.ToString();
                            leaveSetups.PwsId = item.ServiceUserId.ToString();
                            if (arrang != null)
                            {
                                leaveSetups.CarerName = arrang.Carer.User.FirstName + ' ' + arrang.Carer.User.LastName;
                                leaveSetups.RoomName = arrang.RoomName;
                                leaveSetups.PwsName = arrang.ServiceUser.FirstName + ' ' + arrang.ServiceUser.LastName;
                            }
                            leaveSetups.RoomStartDate = holidayDetail.StartDate;
                            leaveSetups.HolidayDays = Convert.ToInt32((holidayDetail.EndDate - holidayDetail.StartDate).TotalDays) + 1;
                            leaveSetups.RoomEndDate = Convert.ToDateTime(holidayDetail.EndDate).AddDays(1);
                            leaveSetups.Type = "Temporary";
                            leaveSetupViewModelList.Add(leaveSetups);
                            listdata.Add(leaveSetups);
                            listtwo.Add(leaveSetups);
                        }
                    }
                }
            }

            return leaveSetupViewModelList;
        }
        #endregion

        #region Save/Update/Get Holiday/Leave setup/delete
        public async Task<HolidayLeaveSetupModel> SaveHolidayLeaveSetup(HolidayLeaveSetupModel input, Guid loginUserId)
        {
            try
            {
                var User = await _unitOfWork.UserRepository.FindByIdAsync(loginUserId);
                using (var scope = new TransactionScope(TransactionScopeOption.RequiresNew, TimeSpan.FromMinutes(30), TransactionScopeAsyncFlowOption.Enabled))
                {
                    HolidayLeaveSetup holidayLeaveSetup = null;

                    if (input != null)
                    {
                        var tenantId = await _tenantService.GetCurrentTenantId();
                        var slcFeeStructureProcess = await processSLCFeeStructure(input); // will delete the data from slcfeestructuretable
                        input.CreatedBy = loginUserId;
                        var arrangement = await _unitOfWork.ArrangementRepository.FindByIdAsync(input.ArrangementId);
                        //var carerId = input.CarerId;
                        var serviceUserId = arrangement.ServiceUserId;
                        //input.CarerId = carerId;
                        input.ServiceUserId = serviceUserId;
                        var carer = await _unitOfWork.CarerRepository.GetFirstOrDefaultAsync(x => x.Id == input.CarerId);
                        if (input.LeaveTypeId != 2)//2 for sickness
                        {
                            if (carer.Holidays == 0 || carer.Holidays == null)
                                throw new BusinessException(Common.ErrorMessages.Holiday.AssignHolidaysToCarer);
                        }
                        var holidayLeaveSetupDetailResult = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == input.CarerId);
                        foreach (var itemDetail in holidayLeaveSetupDetailResult)
                        {
                            var result = holidayLeaveSetupDetailResult.Where(x => x.StartDate <= input.StartDate && x.EndDate >= input.EndDate || input.StartDate == x.EndDate || x.StartDate == input.StartDate || (x.StartDate >= input.StartDate && x.EndDate <= input.EndDate) || (input.StartDate >= x.StartDate && input.StartDate <= x.EndDate) || (input.EndDate >= x.StartDate && input.EndDate <= x.EndDate));
                            if (result.Count() > 0)
                            {
                                throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignHolidayAlreadyTemporaryCarerOfAnotherCarerWithDateRange);
                            }
                        }
                        var inputTotalholidaysCarer = Convert.ToInt32((input.EndDate - input.StartDate).TotalDays) + 1;
                        var inputHolidaysYear = input.StartDate.Year; // salman
                                                                      // financial year starts from 6th april of every year and ends at 5th aprilof next year
                        DateTime inputHolidaysStartDate = new DateTime(inputHolidaysYear, Common.Constants.FinancialYearSettings.FinancialMonth, Common.Constants.FinancialYearSettings.FinancialStartDay);
                        // year of end date for financial year will be always one greater than the year of startdate of financial year
                        DateTime inputHolidaysEndDate = new DateTime(inputHolidaysYear + 1, Common.Constants.FinancialYearSettings.FinancialMonth, Common.Constants.FinancialYearSettings.FinancialEndDay); ;
                        //if (inputTotalholidaysCarer > carer.Holidays)
                        //    throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignMoreHolidaysThanTotalAssignToCarer);
                        // var holidayLeaveSetupResultCheck = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(a => a.CarerId.ToString() == input.CarerId.ToString() && a.LeaveTypeId != 2);//2 for sickness // old
                        var holidayLeaveSetupResultCheck = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(a => a.CarerId.ToString() == input.CarerId.ToString() && a.LeaveTypeId != 2 && ((a.StartDate >= inputHolidaysStartDate && a.StartDate <= inputHolidaysEndDate) || (a.EndDate >= inputHolidaysStartDate && a.EndDate <= inputHolidaysEndDate)));//2 for sickness // new salman 5/7/23
                        int totalHolidays = 0;
                        if (holidayLeaveSetupResultCheck != null)
                        {
                            foreach (var h in holidayLeaveSetupResultCheck)
                            {
                                //var HolidayDetail = h.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false && h.Id == x.HolidayLeaveSetupId).ToList();
                                //if (HolidayDetail.Count() > 0)
                                //{
                                // totalHolidays += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1; // old 05/07
                                // salman

                                var innerTotalHolidays = Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;

                                if (h.StartDate < inputHolidaysStartDate)
                                {
                                    // if stardate is less than the start date of financial but end date is in the range of financial year
                                    // we need to subtract the extra days
                                    var daysToMinus = Convert.ToInt32((inputHolidaysStartDate - h.StartDate).TotalDays) + 1;
                                    innerTotalHolidays = innerTotalHolidays - daysToMinus;
                                }

                                if (h.EndDate > inputHolidaysEndDate)
                                {
                                    // if end date is greater than the end date of the financial year but start date is in the range of financial year
                                    // we need to subtract the extra days
                                    var daysToMinus = Convert.ToInt32((h.EndDate - inputHolidaysEndDate).TotalDays) + 1;
                                    innerTotalHolidays = innerTotalHolidays - daysToMinus;
                                }

                                totalHolidays += innerTotalHolidays;

                                // end salman

                                //}
                            }
                        }
                        totalHolidays = totalHolidays + inputTotalholidaysCarer;
                        if (input.LeaveTypeId != 2)//2 for sickness
                        {
                            if (carer.Holidays < totalHolidays)
                                throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignMoreHolidaysThanTotalAssignToCarer);
                        }
                        var holidayLeaveSetupCarerResult = await _unitOfWork.HolidayLeaveSetupRepository.GetFirstOrDefaultAsync(x => (x.StartDate <= input.StartDate && x.EndDate >= input.EndDate || input.StartDate == x.EndDate || x.StartDate == input.StartDate || (x.StartDate >= input.StartDate && x.EndDate <= input.EndDate) || (input.StartDate >= x.StartDate && input.StartDate <= x.EndDate) || (input.EndDate >= x.StartDate && input.EndDate <= x.EndDate)) && (x.CarerId == input.CarerId));
                        if (holidayLeaveSetupCarerResult != null)
                        {
                            var HolidayDetail = holidayLeaveSetupCarerResult.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false).ToList();
                            if (HolidayDetail.Count() > 0)
                                throw new BusinessException(Common.ErrorMessages.Holiday.CarerisAlreadyOnHolidayWithSelectedDateRange);
                        }
                        holidayLeaveSetup = MapHolidayLeaveSetupViewModelToHolidayLeaveSetup(input);
                        holidayLeaveSetup.TenantId = tenantId;
                        _unitOfWork.HolidayLeaveSetupRepository.Insert(holidayLeaveSetup);
                        await _unitOfWork.SaveChangesAsync();
                        var holidayLeaveSetupId = holidayLeaveSetup.Id;

                        foreach (var item in input.holidayLeaveSetupDetaiBindinglModel)
                        {
                            HolidayLeaveSetupDetail tbl = new HolidayLeaveSetupDetail();
                            var serviceuser = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == item.ServiceUserId);
                            // var user = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == item.CarerId); // old, now we are receving natural support id as well when carer id is null 
                            // new salman 27/8
                            dynamic user = null; // dynamic variable type will decided at run time and it will be according to condition
                            List<HolidayLeaveSetupDetail> holidayLeaveSetupDetail = null;
                            var holidayLeaveSetupDetailUniqueArrangementCount = 0; // salman 7/9 , it should consider it the one room if temp carer is assigned to one room but different dates, for now it is considering them different count if arrangment is one but dates are different
                            if (item.CarerId != null && item.CarerId != Guid.Empty)
                            {
                                // Use the UserRepository since item.CarerId is not null and is not an empty GUID
                                user = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == item.CarerId);
                                holidayLeaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == item.CarerId);
                                
                            }
                            else
                            {
                                // Use the NaturalSupportRepository since item.CarerId is null or an empty GUID
                                user = await _unitOfWork.NaturalSupportRepository.GetFirstOrDefaultAsync(x => x.Id == new Guid(item.NaturalSupportId));
                                holidayLeaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.NaturalSupportId == new Guid(item.NaturalSupportId));
                                
                            }
                            // end salman 27/8
                            //var arrangementRoomCount = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.CarerId == item.CarerId && x.IsArchive == false);//&& x.IsVacant != true
                            var arrangementRoomCount = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.CarerId == item.ServiceUserId && x.IsArchive == false);
                            //var holidayLeaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == item.CarerId); // moved this code in the above if els condition
                            var holidayLeaveSetupResult = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(x => x.CarerId == item.CarerId);
                            //var totalRooms = arrangementRoomCount.Count + holidayLeaveSetupDetail.Count; // old, this code was causing issue of "Temp carer already assigned to three rooms, if we add a temp carer to same room with different dates
                            holidayLeaveSetupDetailUniqueArrangementCount = holidayLeaveSetupDetail.Select(x => x.ArrangementId).Distinct().Count(); // // this will consider multiple rows of same arrangment as one arrangment, in this way temp carer can be assigned to three rooms independent of one room with different dates
                            var totalRooms = arrangementRoomCount.Count + holidayLeaveSetupDetailUniqueArrangementCount; // new 07/09
                            // now if three arrangements are added and if user wants to add another holiday with different date to the same carer, need to handle this case for now it is giving same error because it is not checking if the new holiday is applied on existing arrangement or not, after adding all 3
                            bool isArrangementIdPresentInList = holidayLeaveSetupDetail.Select(x => x.ArrangementId).Contains(item.ArrangementId);// it will check if the new holiday arrangement id is already present in our arrangement list, then it will allow to add 
         

                            foreach (var itemLeaveSetup in holidayLeaveSetupResult)
                            {
                                var result = holidayLeaveSetupResult.Where(x => x.StartDate <= item.StartDate && x.EndDate >= item.EndDate || item.StartDate == x.EndDate || x.StartDate == item.StartDate || (x.StartDate >= item.StartDate && x.EndDate <= item.EndDate) || (item.StartDate >= x.StartDate && item.StartDate <= x.EndDate) || (item.EndDate >= x.StartDate && item.EndDate <= x.EndDate));
                                if (result.Count() > 0)
                                {
                                    throw new BusinessException(Common.ErrorMessages.Holiday.CarerIsOnHoliday.ToString(), "Temporary carer is already on holiday with selected date range. (" + user.FirstName + " " + user.LastName + ")");
                                }
                            }
                            //  if (totalRooms > 2)//total 3 // old
                            if (totalRooms > 2 && isArrangementIdPresentInList == false)//total 3, it will give the error only if 3 rooms are added and current holiday is not the holiday of existing rooms, means current record is 4th room
                            {
                                throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignRoomIfAlready3.ToString(), "3 rooms are already assigned to temporary carer. (" + user.FirstName + " " + user.LastName + ")");
                            }
                            foreach (var itemDetail in holidayLeaveSetupDetail)
                            {
                                var result = holidayLeaveSetupDetail.Where(x => x.StartDate <= item.StartDate && x.EndDate >= item.EndDate || item.StartDate == x.EndDate || x.StartDate == item.StartDate || (x.StartDate >= item.StartDate && x.EndDate <= item.EndDate) || (item.StartDate >= x.StartDate && item.StartDate <= x.EndDate) || (item.EndDate >= x.StartDate && item.EndDate <= x.EndDate));
                                if (result.Count() > 0)
                                {
                                    throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignRoomWithDateRangeAlreadyAssign.ToString(), "Temporary carer is already assigned room with selected date range (" + user.FirstName + " " + user.LastName + ")");
                                }
                            }


                            tbl.HolidayLeaveSetupId = holidayLeaveSetupId;
                            //tbl.CarerId = item.CarerId;
                            tbl.CarerId = item.CarerId ?? null;// added 25/7
                            tbl.ServiceUserId = item.ServiceUserId;
                            tbl.FeeStructureId = item.FeeStructureId;
                            tbl.StartDate = item.StartDate;
                            tbl.EndDate = item.EndDate;
                            tbl.ParentId = item.ParentId;
                            tbl.ArrangementId = item.ArrangementId;
                            tbl.CreatedOn = DateTime.UtcNow;
                            tbl.UpdatedOn = DateTime.UtcNow;
                            tbl.CreatedBy = (Guid)input.CreatedBy;
                            tbl.ArrangementTypeId = item.ArrangementTypeId; // salman 07/03
                            if (item.NaturalSupportId != null)
                            {
                                tbl.NaturalSupportId = Guid.Parse(item.NaturalSupportId); // salman 25/8
                            }

                            _unitOfWork.HolidayLeaveSetupDetailRepository.Insert(tbl);

                            //history
                            //carer

                            if (item.CarerId != null && item.CarerId != Guid.Empty)
                            {
                                AuditTrail auditTrails = new AuditTrail()
                                { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer, ObjectId = item.CarerId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.SharedLiveCarer, PropertyName = Common.Constants.AuditTrailAreas.TemporaryCarer.ToString(), PropertyNewValue = "PWS" + " - " + tbl.ServiceUser.FirstName + " " + tbl.ServiceUser.LastName, PropertyOldValue = "", TenantId = tenantId };
                                _auditService.CreateAuditTrail(auditTrails, this._unitOfWork);

                                //pws
                                AuditTrail auditTrailsServiceUser = new AuditTrail()
                                { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.PeopleWeSupport, ObjectId = item.ServiceUserId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport, PropertyName = Common.Constants.AuditTrailAreas.Holiday.ToString(), PropertyNewValue = Common.Constants.AuditTrailAreas.TemporaryCarer.ToString() + " - " + user.FirstName + " " + user.LastName, PropertyOldValue = "", TenantId = tenantId };
                                _auditService.CreateAuditTrail(auditTrailsServiceUser, this._unitOfWork);
                            }
                            else
                            {  // in case of natural support
                                AuditTrail auditTrails = new AuditTrail()
                                { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.BetterTogetherNaturalSupport, ObjectId = item.NaturalSupportId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.NaturalSupport, PropertyName = Common.Constants.AuditTrailAreas.NaturalSupport.ToString(), PropertyNewValue = "PWS" + " - " + tbl.ServiceUser.FirstName + " " + tbl.ServiceUser.LastName, PropertyOldValue = "", TenantId = tenantId };
                                _auditService.CreateAuditTrail(auditTrails, this._unitOfWork);

                                //pws
                                AuditTrail auditTrailsServiceUser = new AuditTrail()
                                { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.PeopleWeSupport, ObjectId = item.ServiceUserId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport, PropertyName = Common.Constants.AuditTrailAreas.Holiday.ToString(), PropertyNewValue = Common.Constants.AuditTrailAreas.NaturalSupport.ToString() + " - " + user.FirstName + " " + user.LastName, PropertyOldValue = "", TenantId = tenantId };
                                _auditService.CreateAuditTrail(auditTrailsServiceUser, this._unitOfWork);
                            }


                        }
                        await _unitOfWork.SaveChangesAsync();
                        scope.Complete();
                    }
                    return MapHolidayLeaveSetupViewModel(holidayLeaveSetup);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        // salman new
        private async Task<bool> processSLCFeeStructure(HolidayLeaveSetupModel input)
        {   // this will only work for past data because slcfeestructure only hold past dates
            // calculate months in the date range 
            List<int> inputMonthNumbers = new List<int>();
            DateTime currentDate = input.StartDate;

            while (currentDate <= input.EndDate)
            {
                inputMonthNumbers.Add(currentDate.Month);
                currentDate = currentDate.AddMonths(1);
            }

            // inputMonthNumbers will be used to fetch all feestructure records of carere with in the months of input start and end date
            var slcFeeStructureData = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.CarerId == input.CarerId && inputMonthNumbers.Contains(x.M));
            var recordsInDateRangeDaily = new List<SLcFeeStracture>();

            foreach (var record in slcFeeStructureData)
            {   // each record from DB
                foreach (var holidayRecord in input.holidayLeaveSetupDetaiBindinglModel) 
                {   // each record from frontend holidayleavesetupDetailBindingModel

                    if (record.Daily == true)
                    {
                        if ((record.StartDate >= holidayRecord.StartDate && record.EndDate <= holidayRecord.EndDate)) // Records with WeeklyValue 1
                        {
                            recordsInDateRangeDaily.Add(record);
                        }
                    }
                    else
                    {   // for weekly record
                        if (record.CarerId == new Guid("5aa9778b-87e1-4184-963a-e7c538c9f9cc") && record.M > 8)
                        {
                            var abc = "true";
                        }
                        decimal feeStructureWeeklyFee = 0;
                        decimal feeStructureWeeklyLocalAuthorityCharge = 0;
                        // we need to get feestructure fee for each record and it can only be fetched by using fee title from description
                        int secondHyphenIndex = record.Description.IndexOf('-', record.Description.IndexOf('-') + 1);
                        int colonIndex = record.Description.IndexOf(':');

                        if (secondHyphenIndex != -1 && colonIndex != -1)
                        {
                            // Extract the text between the second hyphen and the colon.
                            string FeeStructureFeeTitle = record.Description.Substring(secondHyphenIndex + 1, colonIndex - secondHyphenIndex - 1).Trim();
                            if (!string.IsNullOrWhiteSpace(FeeStructureFeeTitle))
                            {
                                // Add your LINQ query here to retrieve the record based on the condition.
                                var feeStructureRecord = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(x=> x.FeeTitle == FeeStructureFeeTitle);

                                if (feeStructureRecord != null)
                                {
                                    // Process the retrieved feeStructureRecord
                                    // ...

                                    feeStructureWeeklyFee = feeStructureRecord.Fee;
                                    feeStructureWeeklyLocalAuthorityCharge = feeStructureRecord.LocalAuthorityCharge??0;
                                }
                            }
                        }
                        DateTime? overlapStartDate = holidayRecord.StartDate > record.StartDate ? holidayRecord.StartDate : record.StartDate;
                        DateTime? overlapEndDate = holidayRecord.EndDate < record.EndDate ? holidayRecord.EndDate : record.EndDate;
                        int? overlappingDays = 0;
                        if (overlapStartDate <= overlapEndDate)
                        {
                            TimeSpan? overlap = overlapEndDate - overlapStartDate;
                            overlappingDays = (int?)overlap?.Days;
                            overlappingDays = overlappingDays + 1;


                            decimal weeklyAmountForDays = 0;
                            decimal weeklyLocalAuthorityCharge = 0;
                            // for amount
                            if (record.Amount > 0 && overlappingDays > 0)
                            {

                                weeklyAmountForDays = (feeStructureWeeklyFee / 7) * overlappingDays ?? 0;
                                decimal remaningWeeklyAmount = Math.Round((record.Amount - weeklyAmountForDays) ?? 0, 2);
                                record.Amount = remaningWeeklyAmount;

                                _unitOfWork.SLcFeeStractureRepository.Update(record);
                            }
                            // for local authority charge
                            if (record.LocalAuthorityCharges > 0 && overlappingDays > 0)
                            {

                                weeklyLocalAuthorityCharge = (feeStructureWeeklyLocalAuthorityCharge / 7) * overlappingDays ?? 0;
                                decimal remaningWeeklyLocalAuthorityCharge = Math.Round((record.LocalAuthorityCharges - weeklyLocalAuthorityCharge) ?? 0, 2);
                                record.LocalAuthorityCharges = remaningWeeklyLocalAuthorityCharge;

                                _unitOfWork.SLcFeeStractureRepository.Update(record);
                            }
                        }
                        
                    }
                }
            }
            // Delete the records in the date range
            foreach (var currentRecord in recordsInDateRangeDaily)
            {
               _unitOfWork.SLcFeeStractureRepository.Delete(currentRecord.Id);
            }

            return true;
        }

        //get holiday record by id
        public async Task<HolidayLeaveSetupModel> GetHolidayLeaveSetupById(int Id)
        {
            var holidayLeaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.FindByIdAsync(Id);
            //var naturalSupportBinding = await _unitOfWork.NaturalSupportRepository.FindAllAsync(x=>x.ServiceUserId == holidayLeaveSetup.ServiceUserId);
            //var holidayLeaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.HolidayLeaveSetupId == Id);
            //var leaveType = await _unitOfWork.LeaveTypeRepository.GetFirstOrDefaultAsync(a => a.Id == holidayLeaveSetup.LeaveTypeId);
            HolidayLeaveSetupModel holidaLeaveSetupObj = new HolidayLeaveSetupModel();
            holidaLeaveSetupObj.Id = holidayLeaveSetup.Id;
            holidaLeaveSetupObj.LeaveTypeId = holidayLeaveSetup.LeaveTypeId;
            holidaLeaveSetupObj.StartDate = holidayLeaveSetup.StartDate;
            holidaLeaveSetupObj.EndDate = holidayLeaveSetup.EndDate;
            holidaLeaveSetupObj.LeaveTypeName = holidayLeaveSetup.LeaveType.Name;
            holidaLeaveSetupObj.CarerId = holidayLeaveSetup.CarerId;
            holidaLeaveSetupObj.ServiceUserId = holidayLeaveSetup.ServiceUserId;
            holidaLeaveSetupObj.CreatedBy = holidayLeaveSetup.CreatedBy;

            // natural supports salman 28/8, mapping 
            //var pwsSpecificNaturalSupport = new List<NaturalSupportBindingModel>();
            //pwsSpecificNaturalSupport = naturalSupportBinding
            //            .Select(x => new NaturalSupportBindingModel
            //            {
            //                Id = x.Id,             // Map the Id property
            //                Name = x.FirstName + " " + x.LastName,         // Map the Name property
            //                ServiceUserId = x.ServiceUserId.ToString()  // Map the ServiceUserId property
            //            })
            //            .ToList();
            //detail table data
            List<HolidayLeaveSetupDetailModel> holidayLeaveSetupDetailList = new List<HolidayLeaveSetupDetailModel>();
            foreach (var item in holidayLeaveSetup.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false).ToList())
            //foreach (var item in holidayLeaveSetup.HolidayLeaveSetupDetails.ToList())
            {
                var Leavedetail = new HolidayLeaveSetupDetailModel();
                Leavedetail.Id = item.Id;

                // first it was out of foreach loop
                // natural supports salman 28/8, mapping 
                var naturalSupportBinding = await _unitOfWork.NaturalSupportRepository.FindAllAsync(x => x.ServiceUserId == item.ServiceUserId);
                var pwsSpecificNaturalSupport = new List<NaturalSupportBindingModel>();
                pwsSpecificNaturalSupport = naturalSupportBinding
                            .Select(x => new NaturalSupportBindingModel
                            {
                                Id = x.Id,             // Map the Id property
                                Name = x.FirstName + " " + x.LastName,         // Map the Name property
                                ServiceUserId = x.ServiceUserId.ToString()  // Map the ServiceUserId property
                            })
                            .ToList();
                // end out of foreach loop

                //Leavedetail.CarerId = item.CarerId; // old
                if (item.CarerId != null && item.CarerId != Guid.Empty)
                {
                    Leavedetail.CarerId = item.CarerId;
                    Leavedetail.IsNaturalSupport = false;
                }
                else
                {  //added 29/8
                    Leavedetail.CarerId = null;//item.NaturalSupportId;
                    Leavedetail.NaturalSupportId = item.NaturalSupportId.ToString();
                    Leavedetail.IsNaturalSupport = true;
                }
                Leavedetail.ArrangementId = item.ArrangementId;
                Leavedetail.ParentId = item.ParentId;
                Leavedetail.ServiceUserId = item.ServiceUserId;
                Leavedetail.FeeStructureId = item.FeeStructureId;
                Leavedetail.StartDate = item.StartDate;
                Leavedetail.EndDate = item.EndDate;
                Leavedetail.StartDate = item.StartDate;
                Leavedetail.ArrangementTypeId = item.ArrangementTypeId;
                Leavedetail.PwsName = item.Arrangement.ServiceUser.FirstName + ' ' + item.Arrangement.ServiceUser.LastName;
                Leavedetail.NaturalSupportId = item.NaturalSupportId.ToString(); // salman 27/8
                Leavedetail.NaturalSupportBindingModel = pwsSpecificNaturalSupport; // salman 28/8
                holidayLeaveSetupDetailList.Add(Leavedetail);
            }
            holidaLeaveSetupObj.holidayLeaveSetupDetaiBindinglModel = holidayLeaveSetupDetailList.OrderByDescending(x => x.ArrangementId).ToList();
            return holidaLeaveSetupObj;
        }

        //update holiday leave setup
        public async Task<HolidayLeaveSetupModel> UpdateHolidayLeaveSetup(HolidayLeaveSetupModel input, Guid loginUserId)
        {
            try
            {
                var User = await _unitOfWork.UserRepository.FindByIdAsync(loginUserId);
                var holidayLeaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.FindByIdAsync(input.Id);
                var holidayLeaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.HolidayLeaveSetupId == input.Id);
                holidayLeaveSetupDetail.ToList();
                var TenantId = await _tenantService.GetCurrentTenantId();
                input.TenantId = TenantId;
                input.UpdatedBy = loginUserId;
                // salman new
                var processUpdateSLC = await processUpdateSLCFeeStructure(input, holidayLeaveSetup, holidayLeaveSetupDetail, TenantId, loginUserId);

                using (var scope = new TransactionScope(TransactionScopeOption.RequiresNew, TimeSpan.FromMinutes(30), TransactionScopeAsyncFlowOption.Enabled))
                {
                    if (input != null)
                    {
                        var tenantId = await _tenantService.GetCurrentTenantId();
                        input.CreatedBy = loginUserId;
                        HolidayLeaveSetupModel oldHolidayObj = new HolidayLeaveSetupModel();
                        oldHolidayObj = await GetHolidayLeaveSetupById(input.Id);

                        var arrangement = await _unitOfWork.ArrangementRepository.FindByIdAsync(input.ArrangementId);
                        //var carerId = arrangement.CarerId;
                        var carer = await _unitOfWork.CarerRepository.GetFirstOrDefaultAsync(x => x.Id == input.CarerId);
                        if (input.Type != Common.Constants.LeaveStructureStatus.Temporary)//if not temporary carer
                        {
                            if (input.LeaveTypeId != 2)//2 for sickness
                            {
                                if (carer.Holidays == 0 || carer.Holidays == null)
                                    throw new BusinessException(Common.ErrorMessages.Holiday.AssignHolidaysToCarer);
                            }
                        }
                        var inputTotalholidaysCarer = Convert.ToInt32((input.EndDate - input.StartDate).TotalDays) + 1;
                        //if (inputTotalholidaysCarer > carer.Holidays)
                        //    throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignMoreHolidaysThanTotalAssignToCarer);
                        if (input.Type != Common.Constants.LeaveStructureStatus.Temporary)//if not temporary carer
                        {
                            var holidayLeaveSetupResultCheck = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(a => a.CarerId.ToString() == input.CarerId.ToString() && a.Id != input.Id && a.LeaveTypeId != 2);//2 for sickness 
                            int totalHolidays = 0;
                            if (holidayLeaveSetupResultCheck != null)
                            {
                                foreach (var h in holidayLeaveSetupResultCheck)
                                {
                                    //var HolidayDetail = h.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false && h.Id == x.HolidayLeaveSetupId).ToList();
                                    //if (HolidayDetail.Count() > 0)
                                    //{
                                    totalHolidays += Convert.ToInt32((h.EndDate - h.StartDate).TotalDays) + 1;
                                    //}
                                }
                            }
                            totalHolidays = totalHolidays + inputTotalholidaysCarer;
                            if (input.LeaveTypeId != 2)//2 for sickness
                            {
                                if (carer.Holidays < totalHolidays)
                                    throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignMoreHolidaysThanTotalAssignToCarer);
                            }
                        }
                        if (input.Type != Common.Constants.LeaveStructureStatus.Temporary)//if not temporary carer
                        {
                            var holidayLeaveSetupCarerResult = await _unitOfWork.HolidayLeaveSetupRepository.GetFirstOrDefaultAsync(x => (x.StartDate <= input.StartDate && x.EndDate >= input.EndDate || input.StartDate == x.EndDate || x.StartDate == input.StartDate || (x.StartDate >= input.StartDate && x.EndDate <= input.EndDate) || (input.StartDate >= x.StartDate && input.StartDate <= x.EndDate) || (input.EndDate >= x.StartDate && input.EndDate <= x.EndDate)) && (x.CarerId == input.CarerId && x.Id != input.Id));
                            if (holidayLeaveSetupCarerResult != null)
                            {
                                var HolidayDetail = holidayLeaveSetupCarerResult.HolidayLeaveSetupDetails.Where(x => x.Arrangement.IsArchive == false).ToList();
                                if (HolidayDetail.Count() > 0)
                                    throw new BusinessException(Common.ErrorMessages.Holiday.CarerisAlreadyOnHolidayWithSelectedDateRange);
                            }
                        }

                        //record for history leave setup table
                        oldHolidayObj.StartDateString = Convert.ToDateTime(oldHolidayObj.StartDate).ToString("dd/MM/yyyy");
                        oldHolidayObj.EndDateString = Convert.ToDateTime(oldHolidayObj.EndDate).ToString("dd/MM/yyyy");
                        input.StartDateString = Convert.ToDateTime(input.StartDate).ToString("dd/MM/yyyy");
                        input.EndDateString = Convert.ToDateTime(input.EndDate).ToString("dd/MM/yyyy");
                        oldHolidayObj.LeaveTypeName = holidayLeaveSetup.LeaveType.Name;
                        var leaveType = await _unitOfWork.LeaveTypeRepository.GetFirstOrDefaultAsync(x => x.Id == input.LeaveTypeId);
                        input.LeaveTypeName = leaveType.Name;


                        var serviceUserId = arrangement.ServiceUserId;
                        holidayLeaveSetup.LeaveTypeId = input.LeaveTypeId;
                        holidayLeaveSetup.StartDate = input.StartDate;
                        holidayLeaveSetup.EndDate = input.EndDate;
                        //holidayLeaveSetup.CarerId = input.CarerId;
                        //holidayLeaveSetup.ServiceUserId = serviceUserId;
                        holidayLeaveSetup.UpdatedOn = DateTime.UtcNow;
                        holidayLeaveSetup.TenantId = tenantId;
                        holidayLeaveSetup.UpdatedBy = loginUserId;
                        _unitOfWork.HolidayLeaveSetupRepository.Update(holidayLeaveSetup);
                        await _unitOfWork.SaveChangesAsync();

                        //history
                        _auditService.AuditTrailHandler<HolidayLeaveSetupModel>(Common.Constants.AuditTrailObjectPropertySettings.TemporaryCarerHolidaySetup,
                   oldHolidayObj, input, Common.Constants.AuditTrailAreas.SharedLiveCarer,
                   Common.Constants.AuditTrailAreas.LeaveStructure.ToString(), input.CarerId.ToString(), _unitOfWork);

                        foreach (var item in input.holidayLeaveSetupDetaiBindinglModel)
                        {
                            var checkHolidayDetail = holidayLeaveSetupDetail.Where(x => x.Id == item.Id).FirstOrDefault();
                            //var serviceuser = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == item.ServiceUserId);
                            //var user = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == item.CarerId); // old, first it was checking only in user table, now in case of natural support its data needs to be picked from natural support table
                            // salman
                            dynamic user = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == item.CarerId);
                            if (user == null)
                            {
                                //user = await _unitOfWork.NaturalSupportRepository.GetFirstOrDefaultAsync(x => x.Id == item.CarerId); // may be it is by mistake
                                user = await _unitOfWork.NaturalSupportRepository.GetFirstOrDefaultAsync(x => x.Id == new Guid(item.NaturalSupportId));
                            }
                            // end salman
                            if (checkHolidayDetail != null)
                            {
                                //get previos record for history-
                                var fee = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(a => a.Id == item.FeeStructureId);
                                var oldData = oldHolidayObj.holidayLeaveSetupDetaiBindinglModel.Where(x => x.Id == item.Id).FirstOrDefault();
                                var userText = "temporary carer"; // salman 
                                //var userOld = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == oldData.CarerId); // old
                                dynamic userOld = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == oldData.CarerId);
                                if (userOld == null)
                                {
                                    userOld = await _unitOfWork.NaturalSupportRepository.GetFirstOrDefaultAsync(x => x.Id == oldData.CarerId);
                                }
                                oldHolidayObj.StartDateString = Convert.ToDateTime(oldData.StartDate).ToString("dd/MM/yyyy");
                                oldHolidayObj.EndDateString = Convert.ToDateTime(oldData.EndDate).ToString("dd/MM/yyyy");
                                input.StartDateString = Convert.ToDateTime(item.StartDate).ToString("dd/MM/yyyy");
                                input.EndDateString = Convert.ToDateTime(item.EndDate).ToString("dd/MM/yyyy");
                                //  oldHolidayObj.FeeStructureName = checkHolidayDetail.FeeStructure.FeeTitle; // old
                                if (checkHolidayDetail.FeeStructure != null)
                                {
                                    oldHolidayObj.FeeStructureName = checkHolidayDetail.FeeStructure.FeeTitle;
                                }
                                // input.FeeStructureName = fee.FeeTitle; // old
                                if (fee != null)
                                {
                                    input.FeeStructureName = fee.FeeTitle;
                                }
                                if (userOld != null)
                                    oldHolidayObj.CarerName = userOld.FirstName + " " + userOld.LastName;
                                if (item.CarerId != null)
                                    input.CarerName = user.FirstName + " " + user.LastName;
                                //salman for arrangementtype history
                                var oldArrangementType = await _unitOfWork.ArrangementTypeRepository.GetFirstOrDefaultAsync(a => a.Id == oldData.ArrangementTypeId);
                                if (oldArrangementType != null)
                                {
                                    oldHolidayObj.ArrangementTypeString = oldArrangementType.ArrangementTypeText;
                                }
                                var newArrangementType = await _unitOfWork.ArrangementTypeRepository.GetFirstOrDefaultAsync(a => a.Id == item.ArrangementTypeId);
                                if (newArrangementType != null)
                                {
                                    input.ArrangementTypeString = newArrangementType.ArrangementTypeText;
                                }
                                //end for arrangementtypehistory

                                input.UpdatedBy = loginUserId;
                                //apply checks when update
                                var arrangementRoomCount = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.CarerId == item.CarerId && x.IsArchive == false);//&& x.IsVacant != true
                                //var holidayLeaveSetupDetailRep = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == item.CarerId && x.HolidayLeaveSetupId != input.Id); // old
                                // salman 04/09
                                List<HolidayLeaveSetupDetail> holidayLeaveSetupDetailRep ;
                                if(item.CarerId != null && item.CarerId != Guid.Empty)
                                {
                                    holidayLeaveSetupDetailRep = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == item.CarerId && x.HolidayLeaveSetupId != input.Id);
                                    userText = "temporary carer"; // salman
                                }
                                else
                                {
                                    holidayLeaveSetupDetailRep = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.NaturalSupportId == Guid.Parse(item.NaturalSupportId) && x.HolidayLeaveSetupId != input.Id);
                                    userText = "natural support"; // salman
                                }
                                // end salman
                                var holidayLeaveSetupResult = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(x => x.CarerId == item.CarerId && x.Id != input.Id);
                                // var totalRooms = arrangementRoomCount.Count + holidayLeaveSetupDetailRep.Count;  // old
                                var holidayLeaveSetupDetailUniqueArrangementCount = holidayLeaveSetupDetailRep.Select(x => x.ArrangementId).Distinct().Count(); // // this will consider multiple rows of same arrangment as one arrangment, in this way temp carer can be assigned to three rooms independent of one room with different dates
                                var totalRooms = arrangementRoomCount.Count + holidayLeaveSetupDetailUniqueArrangementCount; // new 07/09
                                bool isArrangementIdPresentInList = holidayLeaveSetupDetailRep.Select(x => x.ArrangementId).Contains(item.ArrangementId);// it will check if the new holiday arrangement id is already present in our arrangement list, then it will allow to add 
                                foreach (var itemLeaveSetup in holidayLeaveSetupResult)
                                {
                                    var result = holidayLeaveSetupResult.Where(x => x.StartDate <= item.StartDate && x.EndDate >= item.EndDate || item.StartDate == x.EndDate || x.StartDate == item.StartDate || (x.StartDate >= item.StartDate && x.EndDate <= item.EndDate) || (item.StartDate >= x.StartDate && item.StartDate <= x.EndDate) || (item.EndDate >= x.StartDate && item.EndDate <= x.EndDate));
                                    if (result.Count() > 0)
                                    {
                                        throw new BusinessException(Common.ErrorMessages.Holiday.CarerIsOnHoliday.ToString(), "Temporary carer is already on holiday with selected date range. (" + user.FirstName + " " + user.LastName + ")");
                                    }
                                }
                                //if (totalRooms > 2)//total 3 // old
                                if (totalRooms > 2 && isArrangementIdPresentInList == false)//total 3, it will give the error only if 3 rooms are added and current holiday is not the holiday of existing rooms, means current record is 4th room
                                {
                                    throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignRoomIfAlready3.ToString(), "3 rooms are already assigned to "+ userText +". (" + user.FirstName + " " + user.LastName + ")");
                                }
                                foreach (var itemDetail in holidayLeaveSetupDetailRep)
                                {
                                    var result = holidayLeaveSetupDetailRep.Where(x => x.StartDate <= item.StartDate && x.EndDate >= item.EndDate || item.StartDate == x.EndDate || x.StartDate == item.StartDate || (x.StartDate >= item.StartDate && x.EndDate <= item.EndDate) || (item.StartDate >= x.StartDate && item.StartDate <= x.EndDate) || (item.EndDate >= x.StartDate && item.EndDate <= x.EndDate));
                                    if (result.Count() > 0)
                                    {
                                        throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignRoomWithDateRangeAlreadyAssign.ToString(), "Temporary carer is already assigned room with selected date range (" + user.FirstName + " " + user.LastName + ")");
                                    }
                                }
                                checkHolidayDetail.ParentId = item.ParentId;
                                //checkHolidayDetail.CarerId = item.CarerId;
                                checkHolidayDetail.CarerId = item.CarerId; //salman 27/8
                                checkHolidayDetail.ServiceUserId = item.ServiceUserId;
                                checkHolidayDetail.FeeStructureId = item.FeeStructureId;
                                checkHolidayDetail.StartDate = item.StartDate;
                                checkHolidayDetail.EndDate = item.EndDate;
                                checkHolidayDetail.CreatedOn = DateTime.UtcNow;
                                checkHolidayDetail.UpdatedOn = DateTime.UtcNow;
                                checkHolidayDetail.CreatedBy = (Guid)input.CreatedBy;
                                checkHolidayDetail.UpdatedBy = loginUserId;
                                checkHolidayDetail.ArrangementTypeId = item.ArrangementTypeId; // salman 03/07
                                if (item.NaturalSupportId != null && item.NaturalSupportId != "") // salman
                                {
                                    checkHolidayDetail.NaturalSupportId = new Guid(item.NaturalSupportId); // salman 31/8
                                }
                                //holidayLeaveSetupDetail[0].CarerId = null; // temporary salman, needs to be removed
                                // _unitOfWork.HolidayLeaveSetupDetailRepository.Update(holidayLeaveSetupDetail); // old 31/8

                                if (item.NaturalSupportId != null && item.IsNaturalSupport)
                                {
                                    checkHolidayDetail.CarerId = null;
                                }

                                // salman 04/09
                                // adding if we we have natural support holiday and we change it to the Normal Carer Holiday then we need
                                // to check if the Natural Support Id is comming we need to set it null
                                if(item.CarerId != null && item.IsNaturalSupport == false)
                                {
                                    checkHolidayDetail.NaturalSupportId = null;
                                }
                                // end salman

                                _unitOfWork.HolidayLeaveSetupDetailRepository.Update(checkHolidayDetail); // salman 31/8


                                //history
                                _auditService.AuditTrailHandler<HolidayLeaveSetupModel>(Common.Constants.AuditTrailObjectPropertySettings.TemporaryCarerHolidays,
                           oldHolidayObj, input, Common.Constants.AuditTrailAreas.SharedLiveCarer,
                           Common.Constants.AuditTrailAreas.TemporaryCarer.ToString(), input.CarerId.ToString(), _unitOfWork);
                                if (input.Type == Common.Constants.LeaveStructureStatus.Temporary)
                                {
                                    var holidayLeaveSetupObj = await _unitOfWork.HolidayLeaveSetupRepository.GetFirstOrDefaultAsync(a => a.Id == input.Id);
                                    //get Main carer when click on temporary for add history in main carer
                                    // var carerid = input.Type == Common.Constants.LeaveStructureStatus.Temporary ? holidayLeaveSetupObj.CarerId : input.CarerId;
                                    _auditService.AuditTrailHandler<HolidayLeaveSetupModel>(Common.Constants.AuditTrailObjectPropertySettings.TemporaryCarerHolidays,
                               oldHolidayObj, input, Common.Constants.AuditTrailAreas.SharedLiveCarer,
                               Common.Constants.AuditTrailAreas.TemporaryCarer.ToString(), holidayLeaveSetupObj.CarerId.ToString(), _unitOfWork);
                                }
                            }
                            else
                            {
                                var arrangementRoomCount = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.CarerId == item.CarerId && x.IsArchive == false && x.IsVacant != true);
                                //var holidayLeaveSetupDetailRep = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == item.CarerId); // old
                                // below code is added for the case of natural support, if one is already added then on edit popup if admin adds a new record with natural support, then we need to handle, so the below code is written for that
                                // salman 05/09
                                var userText = "temporary carer"; // salman
                                List<HolidayLeaveSetupDetail> holidayLeaveSetupDetailRep = null;
                                if(item.CarerId !=null && item.CarerId != Guid.Empty)
                                {
                                    holidayLeaveSetupDetailRep = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.CarerId == item.CarerId);
                                    userText = "temporary carer"; // salman
                                }
                                else
                                {
                                    holidayLeaveSetupDetailRep = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.NaturalSupportId == new Guid(item.NaturalSupportId));
                                    userText = "natural support"; // salman
                                }
                                // end salman
                                var holidayLeaveSetupResult = await _unitOfWork.HolidayLeaveSetupRepository.FindAllAsync(x => x.CarerId == item.CarerId);
                               
                                //var totalRooms = arrangementRoomCount.Count + holidayLeaveSetupDetailRep.Count;  // old, this code was causing issue of "Temp carer already assigned to three rooms, if we add a temp carer to same room with different dates
                                var holidayLeaveSetupDetailUniqueArrangementCount = holidayLeaveSetupDetailRep.Select(x => x.ArrangementId).Distinct().Count(); // // this will consider multiple rows of same arrangment as one arrangment, in this way temp carer can be assigned to three rooms independent of one room with different dates
                                var totalRooms = arrangementRoomCount.Count + holidayLeaveSetupDetailUniqueArrangementCount;
                                // now if three arrangements are added and if user wants to add another holiday with different date to the same carer, need to handle this case for now it is giving same error because it is not checking if the new holiday is applied on existing arrangement or not, after adding all 3
                                bool isArrangementIdPresentInList = holidayLeaveSetupDetailRep.Select(x => x.ArrangementId).Contains(item.ArrangementId);// it will check if the new holiday arrangement id is already present in our arrangement list, then it will allow to add 

                                foreach (var itemLeaveSetup in holidayLeaveSetupResult)
                                {
                                    var result = holidayLeaveSetupResult.Where(x => x.StartDate <= item.StartDate && x.EndDate >= item.EndDate || item.StartDate == x.EndDate || x.StartDate == item.StartDate || (x.StartDate >= item.StartDate && x.EndDate <= item.EndDate) || (item.StartDate >= x.StartDate && item.StartDate <= x.EndDate) || (item.EndDate >= x.StartDate && item.EndDate <= x.EndDate));
                                    if (result.Count() > 0)
                                    {
                                        throw new BusinessException(Common.ErrorMessages.Holiday.CarerIsOnHoliday.ToString(), "Temporary carer is already on holiday with selected date range. (" + user.FirstName + " " + user.LastName + ")");
                                    }
                                }
                                //if (totalRooms > 2) // total 3 old
                                if (totalRooms > 2 && isArrangementIdPresentInList == false)//total 3 //total 3, it will give the error only if 3 rooms are added and current holiday is not the holiday of existing rooms, means current record is 4th room
                                {
                                    throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignRoomIfAlready3.ToString(), "3 rooms are already assigned to "+ userText +" (" + user.FirstName + " " + user.LastName + ")");
                                }
                                foreach (var itemDetail in holidayLeaveSetupDetailRep)
                                {
                                    var result = holidayLeaveSetupDetailRep.Where(x => x.StartDate <= item.StartDate && x.EndDate >= item.EndDate || item.StartDate == x.EndDate || x.StartDate == item.StartDate || (x.StartDate >= item.StartDate && x.EndDate <= item.EndDate) || (item.StartDate >= x.StartDate && item.StartDate <= x.EndDate) || (item.EndDate >= x.StartDate && item.EndDate <= x.EndDate));
                                    if (result.Count() > 0)
                                    {
                                        throw new BusinessException(Common.ErrorMessages.Holiday.CannotAssignRoomWithDateRangeAlreadyAssign.ToString(), "Temporary carer is already assigned room with selected date range (" + user.FirstName + " " + user.LastName + ")");
                                    }
                                }
                                HolidayLeaveSetupDetail tbl = new HolidayLeaveSetupDetail();
                                tbl.HolidayLeaveSetupId = input.Id;
                                // tbl.CarerId = item.CarerId;
                                tbl.CarerId = item.CarerId; // salman 27/8
                                if (item.NaturalSupportId !="" && item.NaturalSupportId != null)
                                {   // now as we are sending natural support as well so we need to add its id
                                    tbl.NaturalSupportId = new Guid(item.NaturalSupportId); // salman 05/09
                                }
                                tbl.ParentId = item.ParentId;
                                tbl.ServiceUserId = item.ServiceUserId;
                                tbl.FeeStructureId = item.FeeStructureId;
                                tbl.StartDate = item.StartDate;
                                tbl.EndDate = item.EndDate;
                                tbl.ArrangementId = item.ArrangementId;
                                tbl.ArrangementTypeId = item.ArrangementTypeId;
                                tbl.CreatedOn = DateTime.UtcNow;
                                tbl.UpdatedOn = DateTime.UtcNow;
                                tbl.CreatedBy = (Guid)input.CreatedBy;
                                _unitOfWork.HolidayLeaveSetupDetailRepository.Insert(tbl);

                                //carer

                                // old
                                /*
                                AuditTrail auditTrails = new AuditTrail()
                                //pws
                                AuditTrail auditTrailsServiceUser = new AuditTrail()
                                { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.PeopleWeSupport, ObjectId = serviceUserId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport, PropertyName = Common.Constants.AuditTrailAreas.Holiday.ToString(), PropertyNewValue = Common.Constants.AuditTrailAreas.TemporaryCarer.ToString() + " - " + user.FirstName + " " + user.LastName, PropertyOldValue = "", TenantId = tenantId };
                                _auditService.CreateAuditTrail(auditTrailsServiceUser, this._unitOfWork);
                                */
                                // end old
                                // new 05/09 added for Natural support as well
                                if (tbl.CarerId != null && tbl.CarerId != Guid.Empty)
                                {
                                    AuditTrail auditTrails = new AuditTrail()
                                    { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer, ObjectId = item.CarerId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.SharedLiveCarer, PropertyName = Common.Constants.AuditTrailAreas.TemporaryCarer.ToString(), PropertyNewValue = "PWS" + " - " + tbl.ServiceUser.FirstName + " " + tbl.ServiceUser.LastName, PropertyOldValue = "", TenantId = tenantId };
                                    _auditService.CreateAuditTrail(auditTrails, this._unitOfWork);

                                    //pws
                                    AuditTrail auditTrailsServiceUser = new AuditTrail()
                                    { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.PeopleWeSupport, ObjectId = serviceUserId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport, PropertyName = Common.Constants.AuditTrailAreas.Holiday.ToString(), PropertyNewValue = Common.Constants.AuditTrailAreas.TemporaryCarer.ToString() + " - " + user.FirstName + " " + user.LastName, PropertyOldValue = "", TenantId = tenantId };
                                    _auditService.CreateAuditTrail(auditTrailsServiceUser, this._unitOfWork);

                                } // added if and if else for the natural support
                                else if (tbl.NaturalSupportId != null && tbl.NaturalSupportId != Guid.Empty)
                                {
                                    AuditTrail auditTrails = new AuditTrail()
                                    { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.BetterTogetherNaturalSupport, ObjectId = item.NaturalSupportId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.NaturalSupport, PropertyName = Common.Constants.AuditTrailAreas.NaturalSupport.ToString(), PropertyNewValue = "PWS" + " - " + tbl.ServiceUser.FirstName + " " + tbl.ServiceUser.LastName, PropertyOldValue = "", TenantId = tenantId };
                                    _auditService.CreateAuditTrail(auditTrails, this._unitOfWork);

                                    //pws
                                    AuditTrail auditTrailsServiceUser = new AuditTrail()
                                    { CreatedBy = (Guid)input.CreatedBy, CreatedOn = DateTime.UtcNow, ObjectArea = Common.Constants.AuditTrailAreas.PeopleWeSupport, ObjectId = serviceUserId.ToString(), ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport, PropertyName = Common.Constants.AuditTrailAreas.Holiday.ToString(), PropertyNewValue = Common.Constants.AuditTrailAreas.NaturalSupport.ToString() + " - " + user.FirstName + " " + user.LastName, PropertyOldValue = "", TenantId = tenantId };
                                    _auditService.CreateAuditTrail(auditTrailsServiceUser, this._unitOfWork);
                                }
                                
                            }
                        }
                        input.UpdatedBy = loginUserId;
                        await _unitOfWork.SaveChangesAsync();
                        scope.Complete();
                    }
                    return MapHolidayLeaveSetupViewModel(holidayLeaveSetup);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //Delete Holiday Event
        // new function for update slcfeestrature
        private async Task<bool> processUpdateSLCFeeStructure(HolidayLeaveSetupModel input, HolidayLeaveSetup holidayLeaveSetup, List<HolidayLeaveSetupDetail> holidayLeaveSetupDetail, int tenantId, Guid loginUserId)
        {
            List<int> inputMonthNumbers = new List<int>();
            DateTime currentDate = input.StartDate;

            while (currentDate <= input.EndDate)
            {
                inputMonthNumbers.Add(currentDate.Month);
                currentDate = currentDate.AddMonths(1);
            }
            var slcFeeStructureData = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.CarerId == input.CarerId && inputMonthNumbers.Contains(x.M));
            List<DateTime> newAddedDates = new List<DateTime>();
            List<DateTime> removedDates = new List<DateTime>();
            foreach (var inputDetailHoliday in input.holidayLeaveSetupDetaiBindinglModel)
            {
                foreach( var oldDetailHoliday in holidayLeaveSetupDetail)
                {
                    if( oldDetailHoliday.Id == inputDetailHoliday.Id)
                    {
                        // if user update exisiting records

                        for (DateTime loopCurrentDate = inputDetailHoliday.StartDate; loopCurrentDate <= inputDetailHoliday.EndDate; loopCurrentDate = loopCurrentDate.AddDays(1))
                        {
                            // Check if the current date is not within the oldDetailHoliday range
                            if (loopCurrentDate < oldDetailHoliday.StartDate || loopCurrentDate > oldDetailHoliday.EndDate)
                            {
                                newAddedDates.Add(loopCurrentDate);
                            }
                        }

                        // dates removed 
                        for (DateTime loopCurrentDate = oldDetailHoliday.StartDate; loopCurrentDate <= oldDetailHoliday.EndDate; loopCurrentDate = loopCurrentDate.AddDays(1))
                        {
                            // Check if the current date is not within the oldDetailHoliday range
                            if (loopCurrentDate < inputDetailHoliday.StartDate || loopCurrentDate > inputDetailHoliday.EndDate)
                            {
                                removedDates.Add(loopCurrentDate);
                            }
                        }

                        // end dates removed
                    }
                    
                }
                // if user has added new temporary carer on edit, then this code will be run
                var matchingNewRecord = holidayLeaveSetupDetail.FirstOrDefault(newRecord => newRecord.Id == inputDetailHoliday.Id);
                if (matchingNewRecord == null)
                {   // only process those records which are not proceeded in above olddetailholiday loop
                    for (DateTime loopCurrentDate = inputDetailHoliday.StartDate; loopCurrentDate <= inputDetailHoliday.EndDate; loopCurrentDate = loopCurrentDate.AddDays(1))
                    {
                        // Check if the current date is not within the oldDetailHoliday range

                        newAddedDates.Add(loopCurrentDate);

                    }
                }
            }

            // loop through each date to match in the record of slcfeestructure
            foreach (DateTime newDate in newAddedDates)
            {
                foreach (var singleSlcFeeStructureData in slcFeeStructureData)
                {
                    if (newDate >= singleSlcFeeStructureData.StartDate && newDate <= singleSlcFeeStructureData.EndDate)
                    {
                        // get the fee structure fee of current record

                        #region find fee from descirtion title

                        int secondHyphenIndex = singleSlcFeeStructureData.Description.IndexOf('-', singleSlcFeeStructureData.Description.IndexOf('-') + 1);
                        int colonIndex = singleSlcFeeStructureData.Description.IndexOf(':');
                        decimal feeStructureWeeklyFee = 0;
                        decimal feeStructureWeeklyLocalAuthorityCharge = 0;
                        if (secondHyphenIndex != -1 && colonIndex != -1)
                        {
                            // Extract the text between the second hyphen and the colon.
                            string FeeStructureFeeTitle = singleSlcFeeStructureData.Description.Substring(secondHyphenIndex + 1, colonIndex - secondHyphenIndex - 1).Trim();
                            if (!string.IsNullOrWhiteSpace(FeeStructureFeeTitle))
                            {
                                // Add your LINQ query here to retrieve the record based on the condition.
                                var feeStructureRecord = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(x => x.FeeTitle == FeeStructureFeeTitle);

                                if (feeStructureRecord != null)
                                {
                                    // Process the retrieved feeStructureRecord
                                    // ...

                                    feeStructureWeeklyFee = feeStructureRecord.Fee;
                                    feeStructureWeeklyLocalAuthorityCharge = feeStructureRecord.LocalAuthorityCharge ?? 0;
                                }
                            }
                        }
                        #endregion

                        #region fee deduction from each record per date
                        decimal weeklyAmountForDay = 0;
                        decimal weeklyLocalAuthorityCharge = 0;
                        // for amount
                        if ((singleSlcFeeStructureData.IsShortDays == null || singleSlcFeeStructureData.IsShortDays == false ))
                        {

                            weeklyAmountForDay = (feeStructureWeeklyFee / 7);
                            decimal remaningWeeklyAmount = Math.Round((singleSlcFeeStructureData.Amount - weeklyAmountForDay) ?? 0, 2);
                            singleSlcFeeStructureData.Amount = remaningWeeklyAmount;

                            _unitOfWork.SLcFeeStractureRepository.Update(singleSlcFeeStructureData);
                        }
                        // for local authority charge
                        if ((singleSlcFeeStructureData.IsShortDays == null || singleSlcFeeStructureData.IsShortDays == false))
                        {

                            weeklyLocalAuthorityCharge = (feeStructureWeeklyLocalAuthorityCharge / 7);
                            decimal remaningWeeklyLocalAuthorityCharge = Math.Round((singleSlcFeeStructureData.LocalAuthorityCharges - weeklyLocalAuthorityCharge) ?? 0, 2);
                            singleSlcFeeStructureData.LocalAuthorityCharges = remaningWeeklyLocalAuthorityCharge;

                            _unitOfWork.SLcFeeStractureRepository.Update(singleSlcFeeStructureData);
                        }

                        #endregion
                    }
                }
            }

            // foreach loop when holiday is removed 
            foreach (DateTime rempvedSingleDate in removedDates)
            {
                foreach (var singleSlcFeeStructureData in slcFeeStructureData)
                {
                    if (rempvedSingleDate >= singleSlcFeeStructureData.StartDate && rempvedSingleDate <= singleSlcFeeStructureData.EndDate)
                    {
                        // get the fee structure fee of current record

                        #region find fee from descirtion title

                        int secondHyphenIndex = singleSlcFeeStructureData.Description.IndexOf('-', singleSlcFeeStructureData.Description.IndexOf('-') + 1);
                        int colonIndex = singleSlcFeeStructureData.Description.IndexOf(':');
                        decimal feeStructureWeeklyFee = 0;
                        decimal feeStructureWeeklyLocalAuthorityCharge = 0;
                        if (secondHyphenIndex != -1 && colonIndex != -1)
                        {
                            // Extract the text between the second hyphen and the colon.
                            string FeeStructureFeeTitle = singleSlcFeeStructureData.Description.Substring(secondHyphenIndex + 1, colonIndex - secondHyphenIndex - 1).Trim();
                            if (!string.IsNullOrWhiteSpace(FeeStructureFeeTitle))
                            {
                                // Add your LINQ query here to retrieve the record based on the condition.
                                var feeStructureRecord = await _unitOfWork.FeeStructureRepository.GetFirstOrDefaultAsync(x => x.FeeTitle == FeeStructureFeeTitle);

                                if (feeStructureRecord != null)
                                {
                                    // Process the retrieved feeStructureRecord
                                    // ...

                                    feeStructureWeeklyFee = feeStructureRecord.Fee;
                                    feeStructureWeeklyLocalAuthorityCharge = feeStructureRecord.LocalAuthorityCharge ?? 0;
                                }
                            }
                        }
                        #endregion

                        #region fee adding to each record per date
                        decimal weeklyAmountForDay = 0;
                        decimal weeklyLocalAuthorityCharge = 0;
                        // for amount
                        if ((singleSlcFeeStructureData.IsShortDays == null || singleSlcFeeStructureData.IsShortDays == false))
                        {

                            weeklyAmountForDay = (feeStructureWeeklyFee / 7);
                            decimal remaningWeeklyAmount = Math.Round((singleSlcFeeStructureData.Amount + weeklyAmountForDay) ?? 0, 2);
                            singleSlcFeeStructureData.Amount = remaningWeeklyAmount;

                             _unitOfWork.SLcFeeStractureRepository.Update(singleSlcFeeStructureData);
                        }
                        // for local authority charge
                        if ((singleSlcFeeStructureData.IsShortDays == null || singleSlcFeeStructureData.IsShortDays == false))
                        {

                            weeklyLocalAuthorityCharge = (feeStructureWeeklyLocalAuthorityCharge / 7);
                            decimal remaningWeeklyLocalAuthorityCharge = Math.Round((singleSlcFeeStructureData.LocalAuthorityCharges + weeklyLocalAuthorityCharge) ?? 0, 2);
                            singleSlcFeeStructureData.LocalAuthorityCharges = remaningWeeklyLocalAuthorityCharge;

                            _unitOfWork.SLcFeeStractureRepository.Update(singleSlcFeeStructureData);
                        }

                        #endregion
                    }
                }
            }
            /*
            #region Fee Add in the SLCFEEStructure when holiday removed
            var oldLeaveSetup = holidayLeaveSetup;
            // Missing dates list 
            List<DateTime> missingDatesList = new List<DateTime>();
            if(input.StartDate > oldLeaveSetup.StartDate)
            {
                DateTime currentDateTempStart = oldLeaveSetup.StartDate;

                // Iterate through the dates until you reach the input.StartDate
                while (currentDateTempStart < input.StartDate)
                {
                    missingDatesList.Add(currentDateTempStart);
                    currentDateTempStart = currentDateTempStart.AddDays(1);
                }
            }

            if(input.EndDate < oldLeaveSetup.EndDate)
            {
                DateTime currentDateTempEnd = input.EndDate.AddDays(1); // one day is added to not include EndDate
                while (currentDateTempEnd <= oldLeaveSetup.EndDate)
                {
                    missingDatesList.Add(currentDateTempEnd);
                    currentDateTempEnd = currentDateTempEnd.AddDays(1);
                }
            }

            var a = missingDatesList;
            // we need to add these missing dates, in each arrangement of the carere, that wil be present in the holidayLeaveSetupDetail
            Guid parentHolidayCarerId = holidayLeaveSetup.CarerId;
            var uniqueHolidaydetailRecords = holidayLeaveSetupDetail
            .GroupBy(x => new { x.ArrangementId, x.ServiceUserId })
            .Select(group => group.First())
            .ToList();   // taken unique because it is giving each temporary carer record as separate entry in holidayleavesetupdetail, which is causing issue while adding missing dates
            //foreach (var singleHolidayLeaveSetupDetail in holidayLeaveSetupDetail)
            foreach( var singleHolidayLeaveSetupDetail in uniqueHolidaydetailRecords)
            {
                var serviceUserFeeIds = await _unitOfWork.ServiceUserFinanceFeeStructure.FindAllAsync(x => x.ServiceUserId == singleHolidayLeaveSetupDetail.ServiceUserId);
                var serviceUserData = await _unitOfWork.ServiceUserRepository.FindByIdAsync(singleHolidayLeaveSetupDetail.ServiceUserId);
                var arrangementData = await _unitOfWork.ArrangementRepository.FindByIdAsync(singleHolidayLeaveSetupDetail.ArrangementId);
                if (serviceUserFeeIds != null)
                {
                    foreach (var feeId in serviceUserFeeIds)
                    {
                        var feeDataOfFeeId = await _unitOfWork.FeeStructureRepository.FindByIdAsync(feeId.FeeStructureId);

                        if (feeDataOfFeeId.Daily == true)
                        {

                            //for (DateTime loopStartDate = singleHolidayLeaveSetupDetail.StartDate; loopStartDate <= singleHolidayLeaveSetupDetail.EndDate; loopStartDate = loopStartDate.AddDays(1))
                            foreach (DateTime missingDate in missingDatesList)
                            {
                                var SLcFeeStract = new SLcFeeStracture();

                                SLcFeeStract.Amount = feeDataOfFeeId.Fee;
                                SLcFeeStract.LocalAuthorityCharges = feeDataOfFeeId.LocalAuthorityCharge;
                                SLcFeeStract.M = missingDate.Month;
                                SLcFeeStract.Y = missingDate.Year;
                                SLcFeeStract.Weekly = false;
                                SLcFeeStract.Daily = true;
                                SLcFeeStract.NA = false;
                                SLcFeeStract.FK_ArrangementId = singleHolidayLeaveSetupDetail.ArrangementId;
                                SLcFeeStract.FK_LeaveSetup = null;
                                SLcFeeStract.Description = "Pws " + serviceUserData.FirstName + " " + serviceUserData.LastName + "-" + arrangementData.Carer.User.FirstName + " " + arrangementData.Carer.User.LastName + " -" + feeDataOfFeeId.FeeTitle + ": "
                                                        + missingDate.ToString("dd/MM/yyyy") + " - " +
                                                          missingDate.ToString("dd/MM/yyyy");
                                SLcFeeStract.ServiceUserId = singleHolidayLeaveSetupDetail.ServiceUserId;
                                SLcFeeStract.CreatedBy = serviceUserData.CreatedBy;
                                SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                SLcFeeStract.StartDate = missingDate;
                                SLcFeeStract.EndDate = missingDate;
                                SLcFeeStract.TenantId = serviceUserData.TenantId;
                                SLcFeeStract.Tdate = missingDate;
                                //SLcFeeStract.CarerId = getTempSLC.FirstOrDefault().CarerId;
                                SLcFeeStract.CarerId = parentHolidayCarerId;
                                _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                            }
                        }
                    }
                }
            }
            // end 

            #endregion

            #region Removing daily price from slcfeestructure when holiday is added
            // for removing daily price from slcfeestracture related to carer
            List<int> inputMonthNumbers = new List<int>();
            DateTime currentDate = input.StartDate;

            while (currentDate <= input.EndDate)
            {
                inputMonthNumbers.Add(currentDate.Month);
                currentDate = currentDate.AddMonths(1);
            }
            // inputMonthNumbers will be used to fetch all feestructure records of carere with in the months of input start and end date
            var slcFeeStructureData = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.CarerId == input.CarerId && inputMonthNumbers.Contains(x.M));

            var recordsInDateRangeDaily = new List<SLcFeeStracture>();
            foreach (var record in slcFeeStructureData)
            {   // each record from DB
                foreach (var holidayRecord in input.holidayLeaveSetupDetaiBindinglModel)
                {   // each record from frontend holidayleavesetupDetailBindingModel

                    if (record.Daily == true)
                    {
                        if ((record.StartDate >= holidayRecord.StartDate && record.EndDate <= holidayRecord.EndDate)) // Records with WeeklyValue 1
                        {
                            recordsInDateRangeDaily.Add(record);
                        }
                    }
                }
            }

            // Delete the records in the date range
            foreach (var currentRecord in recordsInDateRangeDaily)
            {
                _unitOfWork.SLcFeeStractureRepository.Delete(currentRecord.Id);
            }

            #endregion

            */
            // end removing daily price from slc

            // now adding daily
            return true;
        }

        public async Task<Boolean> DeleteHolidayLeaveSetupEventById(int id, Guid UserId)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                try
                {

                    var _leaveSetup = await _unitOfWork.HolidayLeaveSetupRepository.GetFirstOrDefaultAsync(x => x.Id == id);
                    var _leaveSetupDetail = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(a => a.HolidayLeaveSetupId == id);
                    var _slcFeeStracture = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.FK_LeaveSetup == id);
                    var deleteProcessSLCFeeStructure = await processDeleteSLCFeeStructure(id,_leaveSetup,_leaveSetupDetail, _slcFeeStracture);

                    foreach (var i in _slcFeeStracture.ToList())
                    {
                        _unitOfWork.SLcFeeStractureRepository.Delete(i.Id);
                    }
                    foreach (var i in _leaveSetupDetail.ToList())
                    {
                        _unitOfWork.HolidayLeaveSetupDetailRepository.Delete(i.Id);
                    }
                    _unitOfWork.HolidayLeaveSetupRepository.Delete(id);


                    AuditTrail auditTrailbart = new AuditTrail()
                    {
                        CreatedBy = UserId,
                        CreatedOn = DateTime.UtcNow,
                        ObjectArea = Common.Constants.AuditTrailAreas.LeaveStructure,
                        //ObjectId = task.CreatedBy.ToString(),
                        ObjectId = _leaveSetup.CarerId.ToString(),
                        ObjectType = Common.Constants.AuditTrailAreas.BetterTogetherShaeredLiveCarer,
                        PropertyName = Common.Constants.AuditTrailAreas.HolidayEventDeleted.ToString(),
                        PropertyNewValue = "",
                        PropertyOldValue = _leaveSetup.StartDate.ToString("dd/MM/yyyy") + "-" + _leaveSetup.EndDate.ToString("dd/MM/yyyy"),
                        TenantId = _leaveSetup.TenantId
                    };
                    _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                    await _unitOfWork.SaveChangesAsync();
                    scope.Complete();
                    return true;
                }
                catch (Exception ex)
                {
                    throw ex;
                }
            }
        }

        // for delete slcfeestructure
        private async Task<bool> processDeleteSLCFeeStructure(int id, HolidayLeaveSetup holidayLeaveSetupData, List<HolidayLeaveSetupDetail> holidayLeaveSetupDetailData, List<SLcFeeStracture> slcFeeStractureDat)
        {
            DateTime parentHolidayStartDate = holidayLeaveSetupData.StartDate;
            DateTime parentHolidayEndDate = holidayLeaveSetupData.EndDate;
            Guid parentHolidayCarerId = holidayLeaveSetupData.CarerId;
            
            // this will be only used for weekly
            List<int> inputMonthNumbers = new List<int>();
            DateTime currentDate = holidayLeaveSetupData.StartDate;

            while (currentDate <= holidayLeaveSetupData.EndDate)
            {
                inputMonthNumbers.Add(currentDate.Month);
                currentDate = currentDate.AddMonths(1);
            }
            var slcFeeStructureData = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.CarerId == holidayLeaveSetupData.CarerId && inputMonthNumbers.Contains(x.M));
            // end for weekly
            // collect all the arrangements ids and serviceuserids from the leavesetupdetail data
            foreach ( var singleHolidayLeaveSetupDetail in holidayLeaveSetupDetailData)
            {
                var serviceUserFeeIds = await _unitOfWork.ServiceUserFinanceFeeStructure.FindAllAsync(x => x.ServiceUserId == singleHolidayLeaveSetupDetail.ServiceUserId);
                var serviceUserData = await _unitOfWork.ServiceUserRepository.FindByIdAsync(singleHolidayLeaveSetupDetail.ServiceUserId);
                var arrangementData = await _unitOfWork.ArrangementRepository.FindByIdAsync(singleHolidayLeaveSetupDetail.ArrangementId);
               if (serviceUserFeeIds != null)
                {   
                    foreach(var feeId in serviceUserFeeIds)
                    {
                        var feeDataOfFeeId = await _unitOfWork.FeeStructureRepository.FindByIdAsync(feeId.FeeStructureId);
                        
                        if (feeDataOfFeeId.Daily == true) {

                            for (DateTime loopStartDate = singleHolidayLeaveSetupDetail.StartDate; loopStartDate <= singleHolidayLeaveSetupDetail.EndDate; loopStartDate = loopStartDate.AddDays(1)){
                                var SLcFeeStract = new SLcFeeStracture();

                                SLcFeeStract.Amount = feeDataOfFeeId.Fee;
                                SLcFeeStract.LocalAuthorityCharges = feeDataOfFeeId.LocalAuthorityCharge;
                                SLcFeeStract.M = loopStartDate.Month;
                                SLcFeeStract.Y = loopStartDate.Year;
                                SLcFeeStract.Weekly = false;
                                SLcFeeStract.Daily = true;
                                SLcFeeStract.NA = false;
                                SLcFeeStract.FK_ArrangementId = singleHolidayLeaveSetupDetail.ArrangementId;
                                SLcFeeStract.FK_LeaveSetup = null;
                                SLcFeeStract.Description = "Pws " + serviceUserData.FirstName + " " + serviceUserData.LastName + "-" + arrangementData.Carer.User.FirstName + " " + arrangementData.Carer.User.LastName + " -" + feeDataOfFeeId.FeeTitle + ": "
                                                        +loopStartDate.ToString("dd/MM/yyyy") + " - " +
                                                          loopStartDate.ToString("dd/MM/yyyy");
                                SLcFeeStract.ServiceUserId = singleHolidayLeaveSetupDetail.ServiceUserId;
                                SLcFeeStract.CreatedBy = serviceUserData.CreatedBy;
                                SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                SLcFeeStract.StartDate = loopStartDate;
                                SLcFeeStract.EndDate = loopStartDate;
                                SLcFeeStract.TenantId = serviceUserData.TenantId;
                                SLcFeeStract.Tdate = loopStartDate;
                                //SLcFeeStract.CarerId = getTempSLC.FirstOrDefault().CarerId;
                                SLcFeeStract.CarerId = parentHolidayCarerId;
                                _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                            }
                        }else if (feeDataOfFeeId.Weekend == true)
                        {
                            foreach (var record in slcFeeStructureData)
                            {
                                // for weekly records, this is mostly same as adding fee for weekly jus some loop changes and also we have added the fee per day instead of minus
                                // we just need to update Amount and Local Authority charge for the record
                                DateTime? overlapStartDate = singleHolidayLeaveSetupDetail.StartDate > record.StartDate ? singleHolidayLeaveSetupDetail.StartDate : record.StartDate;
                                DateTime? overlapEndDate = singleHolidayLeaveSetupDetail.EndDate < record.EndDate ? singleHolidayLeaveSetupDetail.EndDate : record.EndDate;
                                int? overlappingDays = 0;
                                if (overlapStartDate <= overlapEndDate) 
                                {
                                        TimeSpan? overlap = overlapEndDate - overlapStartDate;
                                        overlappingDays = (int?)overlap?.Days;
                                        overlappingDays = overlappingDays + 1;
                                        decimal weeklyAmountForDays = 0;
                                        decimal weeklyLocalAuthorityCharge = 0;
                                        if ((record.IsShortDays == false || record.IsShortDays == null) && overlappingDays > 0)
                                        {

                                            weeklyAmountForDays = (feeDataOfFeeId.Fee / 7) * overlappingDays ?? 0;
                                            decimal incrementedWeeklyAmount = Math.Round((record.Amount + weeklyAmountForDays) ?? 0, 2);
                                            record.Amount = incrementedWeeklyAmount;

                                            _unitOfWork.SLcFeeStractureRepository.Update(record);
                                        }
                                        // for local authority charge
                                        if ((record.IsShortDays == false || record.IsShortDays == null) && overlappingDays > 0)
                                        {

                                            weeklyLocalAuthorityCharge = (feeDataOfFeeId.LocalAuthorityCharge / 7) * overlappingDays ?? 0;
                                            decimal incrementedWeeklyLocalAuthorityCharge = Math.Round((record.LocalAuthorityCharges + weeklyLocalAuthorityCharge) ?? 0, 2);
                                            record.LocalAuthorityCharges = incrementedWeeklyLocalAuthorityCharge;

                                            _unitOfWork.SLcFeeStractureRepository.Update(record);
                                        }
                                }
                            }
                          
                        }

                    }
                }
            }

            return true;
        }
        private HolidayLeaveSetup MapHolidayLeaveSetupViewModelToHolidayLeaveSetup(HolidayLeaveSetupModel item)
        {
            var document = new HolidayLeaveSetup()
            {
                Id = item.Id,
                LeaveTypeId = item.LeaveTypeId,
                CarerId = item.CarerId,
                ServiceUserId = item.ServiceUserId,
                StartDate = item.StartDate,
                EndDate = item.EndDate,
                CreatedBy = item.CreatedBy,
                CreatedOn = DateTime.UtcNow,
            };
            return document;
        }
        public static HolidayLeaveSetupModel MapHolidayLeaveSetupViewModel(HolidayLeaveSetup holidayLeaveSetup)
        {
            var model = new HolidayLeaveSetupModel();

            model.Id = holidayLeaveSetup.Id;
            model.LeaveTypeId = holidayLeaveSetup.LeaveTypeId;
            model.CarerId = holidayLeaveSetup.CarerId;
            model.ServiceUserId = holidayLeaveSetup.ServiceUserId;
            model.StartDate = holidayLeaveSetup.StartDate;
            model.EndDate = holidayLeaveSetup.EndDate;
            model.CreatedOn = holidayLeaveSetup.CreatedOn;
            //model.CreatedByUser = Common.Helper.FullName(holidayLeaveSetup.User.FirstName, holidayLeaveSetup.User.LastName);
            if (holidayLeaveSetup.User1 != null)
                model.UpdatedByUser = Common.Helper.FullName(holidayLeaveSetup.User1.FirstName, holidayLeaveSetup.User1.LastName);
            model.UpdatedBy = holidayLeaveSetup.UpdatedBy;
            model.UpdatedOn = holidayLeaveSetup.UpdatedOn;
            return model;
        }

        #endregion

        //salman
        #region Arrangemtnt Types Region
        public async Task<List<ArrangementTypeViewModel>> GetAllArrangementTypes()
        {
            var arrangementTypesDAL = await _unitOfWork.ArrangementTypeRepository.FindAllAsync();
            arrangementTypesDAL.RemoveAll(arrangementType => arrangementType.Id == 3); // removing the Type with ID 3, which is "PWS going to Natural Support" because it is not needed yet in the dropdown when assigning carer, it is added for color at the frontend when arrangmenttypeid is 3, related to leavesetupholidaydetail table
            List<ArrangementTypeViewModel> arrangementTypes = new List<ArrangementTypeViewModel>();
            foreach (var arrangementTypeDAL in arrangementTypesDAL)
            {
                ArrangementTypeViewModel arrangementType = new ArrangementTypeViewModel
                {
                    Id = arrangementTypeDAL.Id, // Replace Property1 with the actual property name in ArrangementType
                    Type = arrangementTypeDAL.ArrangementTypeText,

                };

                arrangementTypes.Add(arrangementType);
            }
            return arrangementTypes;
        }
        //end salman

        //public async Task<Boolean> UpdateServiceUserFinanceUtility()
        //{

        //    try
        //    {
        //        using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
        //        {
        //            var serviceUsersList = await _unitOfWork.ServiceUserRepository.FindAllAsync(x => x.FeeStructureId !=null);
        //            foreach (var item in serviceUsersList)
        //            {

        //                FeeStractureService(item, item.TenantId);
        //            }
        //            await _unitOfWork.SaveChangesAsync();


        //            scope.Complete();
        //            return true;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        return false;
        //    }
        //}

        #endregion

        #region static Method
        public async Task FeeStractureHangFireService()
        {
            try
            {

                using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
                {
                    //DateTime currentdate = DateTime.UtcNow.Date;// old
                    DateTime currentdate = DateTime.UtcNow.Date; // salman 20/7
                    //DateTime currentdate =  new DateTime(2023, 9, 2); // temporaray needs to be removed
                    //currentdate = currentdate.AddDays(7);
                    currentdate = currentdate.AddDays(-1);// salman 20/7, added to make the date one day less, if cron job run on 20 july 2am, it will get the records of day 19 july so that all records should be inserted



                    var financePeriods = await _unitOfWork.FinancePeriodRepository.FindAllAsync(x => x.Id > 0);
                    //var pwsFeeRecord = await _unitOfWork.ServiceUserRepository.FindAllAsync(x => x.AppStatusValId != 3 && x.FeeStructureId > 0); // old
                    var pwsFeeRecord = await _unitOfWork.ServiceUserRepository.FindAllAsync(x => x.AppStatusValId != 3 && x.ServiceUserFinanceFeeStructures != null && x.ServiceUserFinanceFeeStructures.Count > 0); // new salman 18/7, this code was suggested by M sir but it was not working ServiceUserFinanceFeeStructures was returning count 0 even if we have added a temporary carer with serviceuser 
                                                                                                                                                                                                                     // var pwsFeeRecord = await _unitOfWork.ServiceUserRepository.FindAllAsync(x => x.AppStatusValId != 3); // salman

                    var tenantId = 0;
                    foreach (var pws in pwsFeeRecord)
                    {

                        int statustype = pws.PwsStatusId ?? 2;
                        var fees = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Id > 0);



                        //if (statustype == 1)
                        //    fees = fees.Where(x => x.Daily == true).ToList();
                        //else
                        //    fees = fees.Where(x => x.Weekend == true).ToList();

                        var FeeStructure = fees.FirstOrDefault();
                        tenantId = pws.TenantId;
                        var UserMappings = await _unitOfWork.ServiceUserFinanceFeeStructure.GetFirstOrDefaultAsync(x => x.ServiceUserId == pws.Id);

                        if (FeeStructure == null || UserMappings == null)
                        {
                            continue;
                        }
                        var arrangements = _unitOfWork.ArrangementRepository.FindAllAsync(x => x.ServiceUserId == pws.Id && x.IsVacant != true && x.IsVacant != true && x.StartDate <= currentdate.Date
                          && (x.EndDate >= currentdate.Date || x.EndDate == null) && (x.IsArchive == false || x.IsArchive == null));
                        string slection = "N/A";


                        // if (FeeStructure.Weekend == true)
                        {
                            slection = "Weekly";
                            foreach (var arrange in arrangements.Result)
                            {
                                var day = currentdate.Day;
                                var m = currentdate.Month;
                                var y = currentdate.Year;


                                var feestracture = _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.M == m && x.Y == y &&
                               x.CarerId == arrange.CarerId && x.ServiceUserId == pws.Id && x.Tdate.Value.Date.Day == day);

                                var fee = await _unitOfWork.SLcFeeStractureRepository.GetFilteredResult(x => x.CarerId == arrange.CarerId
                                 && x.ServiceUserId == pws.Id);
                                //var lastDayOfMonth = new DateTime(currentdate.Year, currentdate.Month,
                                // DateTime.DaysInMonth(currentdate.Year, currentdate.Month));
                                var feeorder = fee.OrderByDescending(x => x.Id).FirstOrDefault();

                                int Lastdayweek = 0;
                                if (feeorder != null)
                                    Lastdayweek = (int)feeorder.Tdate.Value.DayOfWeek;


                                if (feestracture.Result.Count <= 0)
                                {


                                    var lastDayOfMonth = DateTime.Now;
                                    var StartDayOfMonth = DateTime.Now;
                                    int flg = 0;
                                    if (financePeriods.Count() <= 0)
                                        continue;
                                    foreach (var f in financePeriods)
                                    {
                                        if (f.StartDate <= currentdate)
                                        {

                                            if (f.EndDate >= currentdate)
                                            {
                                                lastDayOfMonth = f.EndDate;
                                                StartDayOfMonth = f.StartDate;
                                                flg = 1;
                                                break;
                                            }
                                            else
                                                continue;
                                        }
                                        else
                                            continue;
                                    }

                                    if (flg == 0)
                                        continue;


                                    //if (feestracture.Count > 0)
                                    //{
                                    //    continue;
                                    //}
                                    var getTempSLC = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.ArrangementId ==
                                                      arrange.Id && x.StartDate <= currentdate && x.EndDate >= currentdate);
                                    if (getTempSLC.Count() > 0)
                                    {
                                        if (arrange.EndDate != null)
                                        {
                                            if (arrange.EndDate.Value.Date < currentdate.Date)
                                            {
                                                continue;
                                            }
                                        }

                                        var lstfees = pws.ServiceUserFinanceFeeStructures.Where(x => x.ServiceUserId == pws.Id);
                                        foreach (var itemfee in lstfees)
                                        {
                                            var feeStructures = fees.Where(x => x.Id == getTempSLC.FirstOrDefault().FeeStructureId
                                            ).FirstOrDefault();
                                            if (feeStructures != null)
                                            {
                                                double ondaypwsFee = 0;
                                                double ondayLocalFee = 0;
                                                slection = feeStructures.FeeTitle;
                                                var startdate = currentdate;
                                                int totaldays = 1;
                                                if (feeStructures.Fee > 0 && feeStructures.Daily == true)
                                                {
                                                    ondaypwsFee = Convert.ToDouble(feeStructures.Fee);
                                                }
                                                if (feeStructures.LocalAuthorityCharge > 0 && feeStructures.Daily == true)
                                                {
                                                    ondayLocalFee = Convert.ToDouble(feeStructures.LocalAuthorityCharge);
                                                }
                                                // var TempCarer = await _unitOfWork.UserRepository.FindByIdAsync(getTempSLC.FirstOrDefault().CarerId);
                                                var SLcFeeStract = new SLcFeeStracture();

                                                SLcFeeStract.Amount = Convert.ToDecimal(totaldays * ondaypwsFee);
                                                SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                                SLcFeeStract.M = m;
                                                SLcFeeStract.Y = y;
                                                SLcFeeStract.Weekly = false;
                                                SLcFeeStract.Daily = true;
                                                SLcFeeStract.NA = false;
                                                SLcFeeStract.FK_ArrangementId = arrange.Id;
                                                SLcFeeStract.FK_LeaveSetup = getTempSLC.FirstOrDefault().HolidayLeaveSetupId;
                                                SLcFeeStract.Description = "Holiday Fee of  Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                    + currentdate.ToString("dd/MM/yyyy") + " - " +
                                                      currentdate.ToString("dd/MM/yyyy");
                                                SLcFeeStract.ServiceUserId = pws.Id;
                                                SLcFeeStract.CreatedBy = pws.CreatedBy;
                                                SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                                SLcFeeStract.StartDate = currentdate;
                                                SLcFeeStract.EndDate = currentdate;
                                                SLcFeeStract.TenantId = tenantId;
                                                SLcFeeStract.Tdate = currentdate;
                                                //SLcFeeStract.CarerId = getTempSLC.FirstOrDefault().CarerId;
                                                SLcFeeStract.CarerId = getTempSLC.FirstOrDefault().CarerId ?? Guid.Empty;
                                                _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);


                                                AuditTrail auditTrailbart = new AuditTrail()
                                                {
                                                    CreatedBy = pws.CreatedBy,
                                                    CreatedOn = DateTime.UtcNow,
                                                    ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                                    ObjectId = pws.Id.ToString(),
                                                    ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport,
                                                    PropertyName = Common.Constants.AuditTrailAreas.HolidayFeeAdded.ToString(),
                                                    PropertyNewValue = SLcFeeStract.Amount.ToString(),
                                                    PropertyOldValue = "",
                                                    TenantId = tenantId
                                                };
                                                _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                                            }
                                            break;
                                        }
                                        await _unitOfWork.SaveChangesAsync();
                                    }
                                    if (statustype == 2)
                                    {
                                        int IsSunday = (int)currentdate.DayOfWeek;
                                        int IsFirst = currentdate.Day;

                                        // if ((lastDayOfMonth.Month!=m) && IsSunday != 0)
                                        if (lastDayOfMonth.Date != currentdate.Date && arrange.EndDate != currentdate && IsSunday != 0)
                                        {
                                            // if(lastDayOfMonth.Day!=day)
                                            continue;
                                        }

                                        // if (feestracture.Count <= 0)
                                        {
                                            double TotalFee = Convert.ToDouble(FeeStructure.Fee);
                                            double TotalDays = 0;
                                            int dayweek = (int)currentdate.DayOfWeek;
                                            int daydat = 7;

                                            int cdat = -1;
                                            if (lastDayOfMonth.Day == day && m == lastDayOfMonth.Month && dayweek != 0)
                                            {
                                                double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                var datediff = currentdate - StartDayOfMonth;
                                                if (datediff.TotalDays < 7 && datediff.TotalDays >= 0)
                                                {
                                                    int dayweeks = (int)StartDayOfMonth.DayOfWeek;
                                                    if (dayweeks == 0)
                                                        Lastdayweek = Convert.ToInt32((dayweek + 1));
                                                    else
                                                    {

                                                        Lastdayweek = Convert.ToInt32((dayweek + 1));
                                                    }
                                                    if (Lastdayweek < 0)
                                                        Lastdayweek = Lastdayweek * -1;
                                                    daydat = Lastdayweek;
                                                    TotalFee = (daydat) * perday;
                                                    TotalDays = daydat;
                                                    daydat = daydat - 1;
                                                    // TotalFee = perday * (dayweek + 1);
                                                    //daydat = dayweek;
                                                    cdat = 0;
                                                }
                                                else
                                                {
                                                    TotalFee = perday * (dayweek + 1);
                                                    TotalDays = (dayweek + 1);
                                                    daydat = dayweek;
                                                    cdat = 0;
                                                }
                                            }

                                            else if (lastDayOfMonth.Date != currentdate.Date && dayweek == 0)
                                            {
                                                var datechk = currentdate.AddDays(-6);
                                                if (currentdate.Date != lastDayOfMonth.Date)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;


                                                    if (StartDayOfMonth.Date == currentdate.Date)
                                                        continue;

                                                    else if (day != 1)
                                                    {
                                                        var datediff = currentdate - Convert.ToDateTime(arrange.StartDate);
                                                        if (datediff.TotalDays < 7 && datediff.TotalDays >= 0)
                                                        {
                                                            Lastdayweek = Convert.ToInt32(datediff.TotalDays);
                                                            daydat = Lastdayweek;
                                                        }
                                                        else
                                                        {
                                                            daydat -= Lastdayweek;
                                                            if (Lastdayweek != 0)
                                                                daydat -= 1;
                                                        }
                                                        TotalFee = (daydat) * perday;
                                                        TotalDays = daydat;
                                                        //daydat -=  Lastdayweek;

                                                    }
                                                    else
                                                    {
                                                        continue;
                                                    }
                                                }

                                            }

                                            else if (lastDayOfMonth.Date == currentdate.Date && dayweek == 0)
                                            {
                                                var datechk = currentdate.AddDays(-6);
                                                if (currentdate.Date == lastDayOfMonth.Date)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;


                                                    if (StartDayOfMonth.Date == currentdate.Date
                                                        && arrange.StartDate != arrange.EndDate
                                                        && StartDayOfMonth.Date != lastDayOfMonth.Date)
                                                        continue;

                                                    else if (day != 1)
                                                    {
                                                        var datediff = currentdate - Convert.ToDateTime(arrange.StartDate);
                                                        if (datediff.TotalDays < 7 && datediff.TotalDays >= 0)
                                                        {
                                                            Lastdayweek = Convert.ToInt32(datediff.TotalDays);
                                                            daydat = Lastdayweek;
                                                        }
                                                        else
                                                        {
                                                            daydat -= Lastdayweek;
                                                            if (Lastdayweek != 0 && currentdate != arrange.EndDate)
                                                                daydat -= 1;
                                                        }
                                                        TotalFee = (daydat) * perday;
                                                        TotalDays = daydat;
                                                        //daydat -=  Lastdayweek;

                                                    }
                                                    else if (arrange.StartDate != arrange.EndDate
                                                         && StartDayOfMonth.Date != lastDayOfMonth.Date)
                                                    {
                                                        continue;
                                                    }
                                                }

                                            }




                                            if (arrange.EndDate != null)
                                            {
                                                var totaldays = arrange.EndDate.Value.Date - Convert.ToDateTime(arrange.StartDate).Date;
                                                if (totaldays.TotalDays > 0 && totaldays.TotalDays <= 6 && daydat > 1)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    TotalFee = perday * (totaldays.TotalDays + 1);
                                                    TotalDays = (totaldays.TotalDays + 1);
                                                }

                                            }


                                            if (currentdate == arrange.EndDate)
                                            {
                                                var totaldays = arrange.EndDate.Value.Date - Convert.ToDateTime(arrange.StartDate).Date;
                                                if (IsSunday != 0 && totaldays.TotalDays >= 7)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    daydat = IsSunday;
                                                    TotalFee = (IsSunday + 1) * perday;
                                                    TotalDays = (IsSunday + 1);
                                                }
                                                else if (IsSunday == 0 && daydat != 7)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    daydat = IsSunday;
                                                    TotalFee = (IsSunday + 1) * perday;
                                                    TotalDays = (IsSunday + 1);
                                                }
                                                else if (IsSunday != 0)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    daydat = IsSunday;
                                                    TotalFee = (IsSunday + 1) * perday;
                                                    TotalDays = (IsSunday + 1);
                                                }
                                                if (daydat == 7 && arrange.EndDate == currentdate && IsSunday == 0)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    TotalFee = perday * (daydat + 1);
                                                    TotalDays = (daydat + 1);
                                                }
                                                cdat = 0;
                                            }

                                            else if (currentdate == lastDayOfMonth)
                                            {

                                                if (arrange.EndDate != null)
                                                {
                                                    var totaldays = arrange.EndDate.Value.Date - Convert.ToDateTime(arrange.StartDate).Date;
                                                    if (IsSunday != 0 && totaldays.TotalDays >= 7)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        daydat = IsSunday;
                                                        TotalFee = (IsSunday + 1) * perday;
                                                        TotalDays = (IsSunday + 1);
                                                    }
                                                }
                                                if (daydat == 7 && lastDayOfMonth == currentdate && IsSunday == 0)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    TotalFee = perday * (daydat + 1);
                                                    TotalDays = (daydat + 1);
                                                }
                                                if (lastDayOfMonth == StartDayOfMonth)
                                                {
                                                    TotalDays = 1;
                                                    daydat = 0;
                                                }
                                                cdat = 0;
                                            }

                                            var dat = currentdate.AddDays(-daydat);
                                            if (currentdate == lastDayOfMonth)
                                                Lastdayweek = 0;
                                            else
                                                Lastdayweek = dayweek;
                                            if (dat < arrange.StartDate)
                                                dat = Convert.ToDateTime(arrange.StartDate);
                                            else if (dat < StartDayOfMonth)
                                                dat = StartDayOfMonth;



                                            // feestracture
                                            var lstfees = pws.ServiceUserFinanceFeeStructures.Where(x => x.ServiceUserId == pws.Id);
                                            foreach (var itemfee in lstfees)
                                            {
                                                var feeStructures = fees.Where(x => x.Id == itemfee.FeeStructureId).FirstOrDefault();
                                                if (feeStructures != null)
                                                {
                                                    double ondaypwsFee = 0;
                                                    double ondayLocalFee = 0;
                                                    slection = feeStructures.FeeTitle;
                                                    var startdate = dat;
                                                    var edate = currentdate.AddDays(cdat);
                                                    int totaldays = 0;
                                                    for (; startdate.Date <= edate.Date; startdate = startdate.AddDays(1))
                                                    {
                                                        var chk = _unitOfWork.SLcFeeStractureRepository.FindAll(x => x.StartDate <= startdate && x.EndDate >= startdate &&
                                                          x.ServiceUserId == pws.Id && x.FK_ArrangementId == arrange.Id);
                                                        var getTempSLc = await _unitOfWork.HolidayLeaveSetupDetailRepository.FindAllAsync(x => x.ArrangementId ==
                                                      arrange.Id && x.StartDate <= startdate && x.EndDate >= startdate);
                                                        if (chk.Count() <= 0 && getTempSLc.Count <= 0)
                                                            totaldays += 1;
                                                    }




                                                    if (totaldays <= 0)
                                                        continue;
                                                    if (feeStructures.Fee > 0 && feeStructures.Weekend == true)
                                                    {
                                                        ondaypwsFee = Convert.ToDouble(feeStructures.Fee) / 7;
                                                    }
                                                    if (feeStructures.LocalAuthorityCharge > 0 && feeStructures.Weekend == true)
                                                    {
                                                        ondayLocalFee = Convert.ToDouble(feeStructures.LocalAuthorityCharge) / 7;
                                                    }

                                                    //totalDaysBetweenWeek.TotalDays;
                                                    var SLcFeeStract = new SLcFeeStracture();
                                                    if (totaldays >= 7)
                                                    {
                                                        SLcFeeStract.Amount = Convert.ToDecimal(7 * ondaypwsFee);
                                                        SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(7 * ondayLocalFee);
                                                    }
                                                    else
                                                    {
                                                        SLcFeeStract.Amount = 0;
                                                        SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                                        SLcFeeStract.IsShortDays = true;
                                                    }
                                                    if (cdat == 8)
                                                    {
                                                        cdat = -1;
                                                    }
                                                    SLcFeeStract.M = m;
                                                    SLcFeeStract.Y = y;
                                                    SLcFeeStract.Weekly = true;
                                                    SLcFeeStract.Daily = false;
                                                    SLcFeeStract.NA = false;
                                                    SLcFeeStract.FK_ArrangementId = arrange.Id;
                                                    SLcFeeStract.Description = "Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                        + dat.ToString("dd/MM/yyyy") + " - " +
                                                          currentdate.AddDays(cdat).ToString("dd/MM/yyyy");
                                                    SLcFeeStract.ServiceUserId = pws.Id;
                                                    SLcFeeStract.CreatedBy = pws.CreatedBy;
                                                    SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                                    SLcFeeStract.StartDate = dat;
                                                    SLcFeeStract.EndDate = currentdate.AddDays(cdat);
                                                    SLcFeeStract.TenantId = tenantId;
                                                    SLcFeeStract.Tdate = currentdate;
                                                    SLcFeeStract.CarerId = arrange.CarerId;
                                                    _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                                                    if (totaldays == 8)
                                                    {
                                                        var SLcFeeStractNew = new SLcFeeStracture();

                                                        SLcFeeStractNew.Amount = 0;
                                                        SLcFeeStractNew.LocalAuthorityCharges = Convert.ToDecimal(1 * ondayLocalFee);
                                                        SLcFeeStractNew.IsShortDays = true;

                                                        SLcFeeStractNew.M = m;
                                                        SLcFeeStractNew.Y = y;
                                                        SLcFeeStractNew.Weekly = true;
                                                        SLcFeeStractNew.Daily = false;
                                                        SLcFeeStractNew.NA = false;
                                                        SLcFeeStractNew.FK_ArrangementId = arrange.Id;
                                                        SLcFeeStractNew.Description = "Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                            + currentdate.ToString("dd/MM/yyyy") + " - " +
                                                              currentdate.ToString("dd/MM/yyyy");
                                                        SLcFeeStractNew.ServiceUserId = pws.Id;
                                                        SLcFeeStractNew.CreatedBy = pws.CreatedBy;
                                                        SLcFeeStractNew.CreatedOn = DateTime.UtcNow;
                                                        SLcFeeStractNew.StartDate = currentdate;
                                                        SLcFeeStractNew.EndDate = currentdate;
                                                        SLcFeeStractNew.TenantId = tenantId;
                                                        SLcFeeStractNew.Tdate = currentdate;
                                                        SLcFeeStractNew.CarerId = arrange.CarerId;
                                                        _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStractNew);
                                                    }
                                                }
                                            }
                                        }

                                        await _unitOfWork.SaveChangesAsync();
                                    }
                                    else if (getTempSLC.Count() <= 0)
                                    {

                                        if (arrange.EndDate != null)
                                        {
                                            if (arrange.EndDate.Value.Date < currentdate.Date)
                                            {
                                                continue;
                                            }
                                        }

                                        var lstfees = pws.ServiceUserFinanceFeeStructures.Where(x => x.ServiceUserId == pws.Id);
                                        foreach (var itemfee in lstfees)
                                        {
                                            var feeStructures = fees.Where(x => x.Id == itemfee.FeeStructureId).FirstOrDefault();
                                            if (feeStructures != null)
                                            {
                                                double ondaypwsFee = 0;
                                                double ondayLocalFee = 0;
                                                slection = feeStructures.FeeTitle;
                                                var startdate = currentdate;
                                                int totaldays = 1;
                                                if (feeStructures.Fee > 0 && feeStructures.Daily == true)
                                                {
                                                    ondaypwsFee = Convert.ToDouble(feeStructures.Fee);
                                                }
                                                if (feeStructures.LocalAuthorityCharge > 0 && feeStructures.Daily == true)
                                                {
                                                    ondayLocalFee = Convert.ToDouble(feeStructures.LocalAuthorityCharge);
                                                }

                                                var SLcFeeStract = new SLcFeeStracture();

                                                SLcFeeStract.Amount = Convert.ToDecimal(totaldays * ondaypwsFee);
                                                SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                                SLcFeeStract.M = m;
                                                SLcFeeStract.Y = y;
                                                SLcFeeStract.Weekly = false;
                                                SLcFeeStract.Daily = true;
                                                SLcFeeStract.NA = false;
                                                SLcFeeStract.FK_ArrangementId = arrange.Id;
                                                SLcFeeStract.Description = "Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                    + currentdate.ToString("dd/MM/yyyy") + " - " +
                                                      currentdate.ToString("dd/MM/yyyy");
                                                SLcFeeStract.ServiceUserId = pws.Id;
                                                SLcFeeStract.CreatedBy = pws.CreatedBy;
                                                SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                                SLcFeeStract.StartDate = currentdate;
                                                SLcFeeStract.EndDate = currentdate;
                                                SLcFeeStract.TenantId = tenantId;
                                                SLcFeeStract.Tdate = currentdate;
                                                SLcFeeStract.CarerId = arrange.CarerId;
                                                _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                                                AuditTrail auditTrailbart = new AuditTrail()
                                                {
                                                    CreatedBy = pws.CreatedBy,
                                                    CreatedOn = DateTime.UtcNow,
                                                    ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                                    ObjectId = pws.Id.ToString(),
                                                    ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport,
                                                    PropertyName = Common.Constants.AuditTrailAreas.HolidayFeeAdded.ToString(),
                                                    PropertyNewValue = SLcFeeStract.Amount.ToString(),
                                                    PropertyOldValue = "",
                                                    TenantId = tenantId
                                                };
                                                _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                                            }
                                        }
                                        await _unitOfWork.SaveChangesAsync();
                                    }

                                    //if (getTempSLC.Count() > 0)
                                    //{
                                    //    if (arrange.EndDate != null)
                                    //    {
                                    //        if (arrange.EndDate.Value.Date < currentdate.Date)
                                    //        {
                                    //            continue;
                                    //        }
                                    //    }

                                    //    var lstfees = pws.ServiceUserFinanceFeeStructures.Where(x => x.ServiceUserId == pws.Id);
                                    //    foreach (var itemfee in lstfees)
                                    //    {
                                    //        var feeStructures = fees.Where(x => x.Id == itemfee.FeeStructureId).FirstOrDefault();
                                    //        if (feeStructures != null)
                                    //        {
                                    //            double ondaypwsFee = 0;
                                    //            double ondayLocalFee = 0;
                                    //            slection = feeStructures.FeeTitle;
                                    //            var startdate = currentdate;
                                    //            int totaldays = 1;
                                    //            if (feeStructures.Fee > 0 && feeStructures.Daily == true)
                                    //            {
                                    //                ondaypwsFee = Convert.ToDouble(feeStructures.Fee);
                                    //            }
                                    //            if (feeStructures.LocalAuthorityCharge > 0 && feeStructures.Daily == true)
                                    //            {
                                    //                ondayLocalFee = Convert.ToDouble(feeStructures.LocalAuthorityCharge);
                                    //            }
                                    //            // var TempCarer = await _unitOfWork.UserRepository.FindByIdAsync(getTempSLC.FirstOrDefault().CarerId);
                                    //            var SLcFeeStract = new SLcFeeStracture();

                                    //            SLcFeeStract.Amount = Convert.ToDecimal(totaldays * ondaypwsFee);
                                    //            SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                    //            SLcFeeStract.M = m;
                                    //            SLcFeeStract.Y = y;
                                    //            SLcFeeStract.Weekly = false;
                                    //            SLcFeeStract.Daily = true;
                                    //            SLcFeeStract.NA = false;
                                    //            SLcFeeStract.FK_ArrangementId = arrange.Id;
                                    //            SLcFeeStract.Description = " Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                    //                + currentdate.ToString("dd/MM/yyyy") + " - " +
                                    //                  currentdate.ToString("dd/MM/yyyy");
                                    //            SLcFeeStract.ServiceUserId = pws.Id;
                                    //            SLcFeeStract.CreatedBy = pws.CreatedBy;
                                    //            SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                    //            SLcFeeStract.StartDate = currentdate;
                                    //            SLcFeeStract.EndDate = currentdate;
                                    //            SLcFeeStract.TenantId = tenantId;
                                    //            SLcFeeStract.Tdate = currentdate;
                                    //            SLcFeeStract.CarerId = getTempSLC.FirstOrDefault().CarerId;
                                    //            _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                                    //        }
                                    //    }
                                    //    await _unitOfWork.SaveChangesAsync();
                                    //}
                                }
                            }
                        }


                    }
                    scope.Complete();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public string GetCronExperssion()
        {
            return "0 1 * * *";
        }
        public string GetCronExperssionCuurent()
        {
            var dat = DateTime.UtcNow;
            string cron = "* " + "* " + dat.Day + " " + dat.Month + " *";

            return cron;
        }
        public async void FeeStractureService(ServiceUser pw, int tenantId)
        {
            try
            {


                {

                    var financePeriods = await _unitOfWork.FinancePeriodRepository.FindAllAsync(x => x.Id > 0);
                    var pwsFeeRecord = await _unitOfWork.ServiceUserRepository.FindAllAsync(x => x.Id == pw.Id);

                    int statustype = pw.PwsStatusId ?? 2;


                    var fees = await _unitOfWork.FeeStructureRepository.FindAllAsync(x => x.Id > 0);


                    var FeeStructure = fees.FirstOrDefault();
                    foreach (var pws in pwsFeeRecord)
                    {
                        if (FeeStructure == null)
                        {
                            continue;
                        }
                        if (pws.Id.ToString() == "61D46EEF-D580-45E5-99F1-466077F69E64")
                        {

                        }
                        string slection = "N/A";
                        // if (FeeStructure.Weekend == true)
                        {
                            slection = "Weekly";
                            DateTime dt1 = DateTime.Now;

                            var arrangementlist = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.ServiceUserId == pws.Id
                              && (x.IsArchive == false || x.IsArchive == null) && x.IsVacant != true);
                            if (arrangementlist.Count > 0)
                            {
                                var financeStartd = Convert.ToDateTime(System.Configuration.ConfigurationManager.AppSettings["financeappStartup"]).Date.ToString("dd/MM/yyyy");
                                var financeStartdat = Convert.ToDateTime(financeStartd);
                                var strdate = arrangementlist.OrderBy(x => x.StartDate).FirstOrDefault();
                                DateTime dt0 = Convert.ToDateTime(strdate.StartDate);
                                DateTime startRoomDate = dt0;
                                if (dt0 < financeStartdat)// start date start from deployement date of app
                                {
                                    dt0 = financeStartdat;
                                    startRoomDate = dt0;
                                }
                                var dte = arrangementlist.FirstOrDefault().EndDate ?? null;
                                if (dte != null)
                                {
                                    if (dte < DateTime.Now.Date)
                                        dt1 = Convert.ToDateTime(dte);
                                }
                                int Lastdayweek = 0;
                                for (; dt0.Date <= dt1.Date; dt0 = dt0.AddDays(1))
                                {

                                    DateTime currentdate = dt0.Date;
                                    /* old
                                    if (currentdate > DateTime.Now.Date)
                                        break;
                                    */
                                    // new salmn 1/9/2023
                                    if (currentdate == DateTime.Now.Date) // when it is > it was adding fee to carer, which was an issues according to QA because if we add holiday for today, the fee still given to carer, now this case will be handled by cron job automatically when the job of next day run, it will check if it is not holiday the fee for today will be given to carer, if it is holiday then not
                                        break;
                                    var arrangements = await _unitOfWork.ArrangementRepository.FindAllAsync(x => x.ServiceUserId == pws.Id && x.StartDate <= currentdate.Date
                                       && (x.EndDate >= dt1.Date || x.EndDate == null) && (x.IsArchive == false || x.IsArchive == null) && x.IsVacant != true);


                                    foreach (var arrange in arrangements)
                                    {
                                        var day = currentdate.Day;
                                        var m = currentdate.Month;
                                        var y = currentdate.Year;

                                        var feestracture = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.M == m && x.Y == y &&
                                        x.CarerId == arrange.CarerId && x.ServiceUserId == pws.Id && x.Tdate.Value.Date.Day == day);

                                        var fee = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(x => x.CarerId == arrange.CarerId
                                       && x.ServiceUserId == pws.Id);

                                        var lastDayOfMonth = DateTime.Now;
                                        var StartDayOfMonth = DateTime.Now;
                                        int flg = 0;
                                        if (financePeriods.Count() <= 0)
                                            continue;
                                        foreach (var f in financePeriods)
                                        {
                                            if (f.StartDate <= currentdate)
                                            {
                                                if (f.EndDate >= currentdate)
                                                {
                                                    lastDayOfMonth = f.EndDate;
                                                    StartDayOfMonth = f.StartDate;
                                                    flg = 1;
                                                    break;
                                                }
                                                else
                                                    continue;
                                            }
                                            else
                                                continue;
                                        }

                                        if (flg == 0)
                                            continue;


                                        if (feestracture.Count > 0)
                                        {
                                            continue;
                                        }

                                        if (statustype == 2)
                                        {
                                            int IsSunday = (int)currentdate.DayOfWeek;
                                            int IsFirst = currentdate.Day;

                                            // if ((lastDayOfMonth.Month!=m) && IsSunday != 0)
                                            if (lastDayOfMonth.Date != currentdate.Date && arrange.EndDate != currentdate && IsSunday != 0)
                                            {
                                                // if(lastDayOfMonth.Day!=day)
                                                continue;
                                            }

                                            // if (feestracture.Count <= 0)
                                            {
                                                double TotalFee = Convert.ToDouble(FeeStructure.Fee);
                                                double TotalDays = 0;
                                                int dayweek = (int)currentdate.DayOfWeek;
                                                int daydat = 7;

                                                int cdat = -1;
                                                if (lastDayOfMonth.Day == day && m == lastDayOfMonth.Month && dayweek != 0)
                                                {
                                                    double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                    var datediff = currentdate - StartDayOfMonth;
                                                    if (datediff.TotalDays < 7 && datediff.TotalDays >= 0)
                                                    {
                                                        int dayweeks = (int)StartDayOfMonth.DayOfWeek;
                                                        if (dayweeks == 0)
                                                            Lastdayweek = Convert.ToInt32((dayweek + 1));
                                                        else
                                                        {

                                                            Lastdayweek = Convert.ToInt32((dayweek + 1));
                                                        }
                                                        if (Lastdayweek < 0)
                                                            Lastdayweek = Lastdayweek * -1;
                                                        daydat = Lastdayweek;
                                                        TotalFee = (daydat) * perday;
                                                        TotalDays = daydat;
                                                        daydat = daydat - 1;
                                                        // TotalFee = perday * (dayweek + 1);
                                                        //daydat = dayweek;
                                                        cdat = 0;
                                                    }
                                                    else
                                                    {
                                                        TotalFee = perday * (dayweek + 1);
                                                        TotalDays = (dayweek + 1);
                                                        daydat = dayweek;
                                                        cdat = 0;
                                                    }
                                                }

                                                else if (lastDayOfMonth.Date != currentdate.Date && dayweek == 0)
                                                {
                                                    var datechk = currentdate.AddDays(-6);
                                                    if (currentdate.Date != lastDayOfMonth.Date)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;


                                                        if (StartDayOfMonth.Date == currentdate.Date)
                                                            continue;

                                                        else if (day != 1)
                                                        {
                                                            var datediff = currentdate - Convert.ToDateTime(arrange.StartDate);
                                                            if (datediff.TotalDays < 7 && datediff.TotalDays >= 0)
                                                            {
                                                                Lastdayweek = Convert.ToInt32(datediff.TotalDays);
                                                                daydat = Lastdayweek;
                                                            }
                                                            else
                                                            {
                                                                daydat -= Lastdayweek;
                                                                if (Lastdayweek != 0)
                                                                    daydat -= 1;
                                                            }
                                                            TotalFee = (daydat) * perday;
                                                            TotalDays = daydat;
                                                            //daydat -=  Lastdayweek;

                                                        }
                                                        else
                                                        {
                                                            continue;
                                                        }
                                                    }

                                                }

                                                else if (lastDayOfMonth.Date == currentdate.Date && dayweek == 0)
                                                {
                                                    var datechk = currentdate.AddDays(-6);
                                                    if (currentdate.Date == lastDayOfMonth.Date)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;


                                                        if (StartDayOfMonth.Date == currentdate.Date
                                                            && arrange.StartDate != arrange.EndDate
                                                            && StartDayOfMonth.Date != lastDayOfMonth.Date)
                                                            continue;

                                                        else if (day != 1)
                                                        {
                                                            var datediff = currentdate - Convert.ToDateTime(arrange.StartDate);
                                                            if (datediff.TotalDays < 7 && datediff.TotalDays >= 0)
                                                            {
                                                                Lastdayweek = Convert.ToInt32(datediff.TotalDays);
                                                                daydat = Lastdayweek;
                                                            }
                                                            else
                                                            {
                                                                daydat -= Lastdayweek;
                                                                if (Lastdayweek != 0 && currentdate != arrange.EndDate)
                                                                    daydat -= 1;
                                                            }
                                                            TotalFee = (daydat) * perday;
                                                            TotalDays = daydat;
                                                            //daydat -=  Lastdayweek;

                                                        }
                                                        else if (arrange.StartDate != arrange.EndDate
                                                             && StartDayOfMonth.Date != lastDayOfMonth.Date)
                                                        {
                                                            continue;
                                                        }
                                                    }

                                                }




                                                if (arrange.EndDate != null)
                                                {
                                                    var totaldays = arrange.EndDate.Value.Date - Convert.ToDateTime(arrange.StartDate).Date;
                                                    if (totaldays.TotalDays > 0 && totaldays.TotalDays <= 6 && daydat > 1)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        TotalFee = perday * (totaldays.TotalDays + 1);
                                                        TotalDays = (totaldays.TotalDays + 1);
                                                    }

                                                }


                                                if (currentdate == arrange.EndDate)
                                                {
                                                    var totaldays = arrange.EndDate.Value.Date - Convert.ToDateTime(arrange.StartDate).Date;
                                                    if (IsSunday != 0 && totaldays.TotalDays >= 7)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        daydat = IsSunday;
                                                        TotalFee = (IsSunday + 1) * perday;
                                                        TotalDays = (IsSunday + 1);
                                                    }
                                                    else if (IsSunday == 0 && daydat != 7)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        daydat = IsSunday;
                                                        TotalFee = (IsSunday + 1) * perday;
                                                        TotalDays = (IsSunday + 1);
                                                    }
                                                    else if (IsSunday != 0)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        daydat = IsSunday;
                                                        TotalFee = (IsSunday + 1) * perday;
                                                        TotalDays = (IsSunday + 1);
                                                    }
                                                    if (daydat == 7 && arrange.EndDate == currentdate && IsSunday == 0)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        TotalFee = perday * (daydat + 1);
                                                        TotalDays = (daydat + 1);
                                                    }
                                                    cdat = 0;
                                                }

                                                else if (currentdate == lastDayOfMonth)
                                                {

                                                    if (arrange.EndDate != null)
                                                    {
                                                        var totaldays = arrange.EndDate.Value.Date - Convert.ToDateTime(arrange.StartDate).Date;
                                                        if (IsSunday != 0 && totaldays.TotalDays >= 7)
                                                        {
                                                            double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                            daydat = IsSunday;
                                                            TotalFee = (IsSunday + 1) * perday;
                                                            TotalDays = (IsSunday + 1);
                                                        }
                                                    }
                                                    if (daydat == 7 && lastDayOfMonth == currentdate && IsSunday == 0)
                                                    {
                                                        double perday = Convert.ToDouble(FeeStructure.Fee) / 7;
                                                        TotalFee = perday * (daydat + 1);
                                                        TotalDays = (daydat + 1);
                                                    }
                                                    if (lastDayOfMonth == StartDayOfMonth)
                                                    {
                                                        TotalDays = 1;
                                                        daydat = 0;
                                                    }
                                                    cdat = 0;
                                                }

                                                var dat = currentdate.AddDays(-daydat);
                                                if (currentdate == lastDayOfMonth)
                                                    Lastdayweek = 0;
                                                else
                                                    Lastdayweek = dayweek;
                                                if (dat < arrange.StartDate)
                                                    dat = Convert.ToDateTime(arrange.StartDate);
                                                else if (dat < StartDayOfMonth)
                                                    dat = StartDayOfMonth;


                                                // feestracture
                                                var lstfees = pws.ServiceUserFinanceFeeStructures.Where(x => x.ServiceUserId == pws.Id);
                                                foreach (var itemfee in lstfees)
                                                {
                                                    var feeStructures = fees.Where(x => x.Id == itemfee.FeeStructureId).FirstOrDefault();
                                                    if (feeStructures != null)
                                                    {
                                                        double ondaypwsFee = 0;
                                                        double ondayLocalFee = 0;
                                                        slection = feeStructures.FeeTitle;
                                                        var startdate = dat;
                                                        var edate = currentdate.AddDays(cdat);
                                                        int totaldays = 0;
                                                        for (; startdate.Date <= edate.Date; startdate = startdate.AddDays(1))
                                                        {
                                                            var chk = _unitOfWork.SLcFeeStractureRepository.FindAll(x => x.StartDate <= startdate && x.EndDate >= startdate &&
                                                           x.ServiceUserId == pws.Id && x.FK_ArrangementId == arrange.Id);
                                                            if (chk.Count() <= 0)
                                                                totaldays += 1;
                                                        }

                                                        if (totaldays <= 0)
                                                            continue;
                                                        if (feeStructures.Fee > 0 && feeStructures.Weekend == true)
                                                        {
                                                            ondaypwsFee = Convert.ToDouble(feeStructures.Fee) / 7;
                                                        }
                                                        if (feeStructures.LocalAuthorityCharge > 0 && feeStructures.Weekend == true)
                                                        {
                                                            ondayLocalFee = Convert.ToDouble(feeStructures.LocalAuthorityCharge) / 7;
                                                        }

                                                        //totalDaysBetweenWeek.TotalDays;
                                                        var SLcFeeStract = new SLcFeeStracture();
                                                        if (totaldays >= 7)
                                                        {
                                                            SLcFeeStract.Amount = Convert.ToDecimal(7 * ondaypwsFee);
                                                            SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                                        }
                                                        else
                                                        {
                                                            SLcFeeStract.Amount = 0;
                                                            SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                                            SLcFeeStract.IsShortDays = true;
                                                        }
                                                        if (totaldays == 8)
                                                        {
                                                            cdat = -1;
                                                        }
                                                        SLcFeeStract.M = m;
                                                        SLcFeeStract.Y = y;
                                                        SLcFeeStract.Weekly = true;
                                                        SLcFeeStract.Daily = false;
                                                        SLcFeeStract.NA = false;
                                                        SLcFeeStract.FK_ArrangementId = arrange.Id;
                                                        SLcFeeStract.Description = "Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                            + dat.ToString("dd/MM/yyyy") + " - " +
                                                              currentdate.AddDays(cdat).ToString("dd/MM/yyyy");
                                                        SLcFeeStract.ServiceUserId = pws.Id;
                                                        SLcFeeStract.CreatedBy = pws.CreatedBy;
                                                        SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                                        SLcFeeStract.StartDate = dat;
                                                        SLcFeeStract.EndDate = currentdate.AddDays(cdat);
                                                        SLcFeeStract.TenantId = tenantId;
                                                        SLcFeeStract.Tdate = currentdate;
                                                        SLcFeeStract.CarerId = arrange.CarerId;
                                                        _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                                                        if (totaldays == 8)
                                                        {
                                                            var SLcFeeStractNew = new SLcFeeStracture();

                                                            SLcFeeStractNew.Amount = 0;
                                                            SLcFeeStractNew.LocalAuthorityCharges = Convert.ToDecimal(1 * ondayLocalFee);
                                                            SLcFeeStractNew.IsShortDays = true;

                                                            SLcFeeStractNew.M = m;
                                                            SLcFeeStractNew.Y = y;
                                                            SLcFeeStractNew.Weekly = true;
                                                            SLcFeeStractNew.Daily = false;
                                                            SLcFeeStractNew.NA = false;
                                                            SLcFeeStractNew.FK_ArrangementId = arrange.Id;
                                                            SLcFeeStractNew.Description = "Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                                + currentdate.ToString("dd/MM/yyyy") + " - " +
                                                                  currentdate.ToString("dd/MM/yyyy");
                                                            SLcFeeStractNew.ServiceUserId = pws.Id;
                                                            SLcFeeStractNew.CreatedBy = pws.CreatedBy;
                                                            SLcFeeStractNew.CreatedOn = DateTime.UtcNow;
                                                            SLcFeeStractNew.StartDate = currentdate;
                                                            SLcFeeStractNew.EndDate = currentdate;
                                                            SLcFeeStractNew.TenantId = tenantId;
                                                            SLcFeeStractNew.Tdate = currentdate;
                                                            SLcFeeStractNew.CarerId = arrange.CarerId;
                                                            _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStractNew);
                                                        }
                                                    }
                                                }
                                            }

                                            // await _unitOfWork.SaveChangesAsync();
                                        }
                                        else
                                        {

                                            if (arrange.EndDate != null)
                                            {
                                                if (arrange.EndDate.Value.Date < currentdate.Date)
                                                {
                                                    continue;
                                                }
                                            }

                                            var lstfees = pws.ServiceUserFinanceFeeStructures.Where(x => x.ServiceUserId == pws.Id);
                                            foreach (var itemfee in lstfees)
                                            {
                                                var feeStructures = fees.Where(x => x.Id == itemfee.FeeStructureId).FirstOrDefault();
                                                if (feeStructures != null)
                                                {
                                                    double ondaypwsFee = 0;
                                                    double ondayLocalFee = 0;
                                                    slection = feeStructures.FeeTitle;
                                                    var startdate = currentdate;
                                                    int totaldays = 1;
                                                    if (feeStructures.Fee > 0 && feeStructures.Daily == true)
                                                    {
                                                        ondaypwsFee = Convert.ToDouble(feeStructures.Fee);
                                                    }
                                                    if (feeStructures.LocalAuthorityCharge > 0 && feeStructures.Daily == true)
                                                    {
                                                        ondayLocalFee = Convert.ToDouble(feeStructures.LocalAuthorityCharge);
                                                    }

                                                    var SLcFeeStract = new SLcFeeStracture();

                                                    SLcFeeStract.Amount = Convert.ToDecimal(totaldays * ondaypwsFee);
                                                    SLcFeeStract.LocalAuthorityCharges = Convert.ToDecimal(totaldays * ondayLocalFee);
                                                    SLcFeeStract.M = m;
                                                    SLcFeeStract.Y = y;
                                                    SLcFeeStract.Weekly = false;
                                                    SLcFeeStract.Daily = true;
                                                    SLcFeeStract.NA = false;
                                                    SLcFeeStract.FK_ArrangementId = arrange.Id;
                                                    SLcFeeStract.Description = "Pws " + pws.FirstName + " " + pws.LastName + "-" + arrange.Carer.User.FirstName + " " + arrange.Carer.User.LastName + " -" + slection + ": "
                                                        + currentdate.ToString("dd/MM/yyyy") + " - " +
                                                          currentdate.ToString("dd/MM/yyyy");
                                                    SLcFeeStract.ServiceUserId = pws.Id;
                                                    SLcFeeStract.CreatedBy = pws.CreatedBy;
                                                    SLcFeeStract.CreatedOn = DateTime.UtcNow;
                                                    SLcFeeStract.StartDate = currentdate;
                                                    SLcFeeStract.EndDate = currentdate;
                                                    SLcFeeStract.TenantId = tenantId;
                                                    SLcFeeStract.Tdate = currentdate;
                                                    SLcFeeStract.CarerId = arrange.CarerId;
                                                    _unitOfWork.SLcFeeStractureRepository.Insert(SLcFeeStract);
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            AuditTrail auditTrailbart = new AuditTrail()
                            {
                                CreatedBy = pws.CreatedBy,
                                CreatedOn = DateTime.UtcNow,
                                ObjectArea = Common.Constants.AuditTrailAreas.Finance,
                                ObjectId = pws.Id.ToString(),
                                ObjectType = Common.Constants.AuditTrailAreas.PeopleWeSupport,
                                PropertyName = Common.Constants.AuditTrailAreas.WeeklyFeeAdded.ToString(),
                                PropertyNewValue = DateTime.UtcNow.ToString("dd/MM/yyyy"),
                                PropertyOldValue = "",
                                TenantId = tenantId
                            };
                            _auditService.CreateAuditTrail(auditTrailbart, this._unitOfWork);
                        }


                    }
                    //scope.Complete();
                }

            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public async Task SLCMonthCloseEmailSendingService(DateTime startdate, DateTime enddate, int FinancePeriodId, Guid UpdatedBy)
        {
            try
            {
                var carerFinance = await _unitOfWork.SLcFeeStractureRepository.FindAllAsync(a => a.Tdate >= startdate && a.Tdate <= enddate);
                carerFinance.ToList();
                List<Carer> lst = new List<Carer>();
                foreach (var item in carerFinance)
                {
                    var carerData = lst.Where(x => x.Id == item.CarerId).FirstOrDefault();
                    if (carerData == null)
                    {
                        Carer tbl = new Carer();
                        tbl.Id = item.CarerId;
                        lst.Add(tbl);
                    }

                }
                foreach (var item in lst)
                {
                    var admin = await this._unitOfWork.UserRepository.FindByIdAsync(UpdatedBy);
                    var tenant = admin.Tenant;
                    byte[] fileBytes = null;
                    fileBytes = await GenerateCarerFinanceReportPdfForEmail(item.Id.ToString(), FinancePeriodId);

                    var carerinfo = await _unitOfWork.UserRepository.GetFilteredResult(x => x.Id.ToString() == item.Id.ToString());

                    string filePath = null;
                    filePath = "~/FinanceTemplates/" + "FinanceEmailTemplate.html";
                    filePath = System.Web.Hosting.HostingEnvironment.MapPath(filePath);
                    string htmlBody = File.ReadAllText(filePath);
                    htmlBody = htmlBody.Replace("{{Name}}", carerinfo.FirstOrDefault().FirstName + " " + carerinfo.FirstOrDefault().LastName);
                    htmlBody = htmlBody.Replace("{{TenantName}}", tenant.Name);
                    string providerName = "";
                    string imageFolderName = System.Configuration.ConfigurationManager.AppSettings["templateImages:FolderName"];
                    string folderPath = System.Web.Hosting.HostingEnvironment.MapPath("~/" + imageFolderName + "/logos");
                    string logoPath = System.IO.Path.Combine(folderPath, tenant.TenantKey + "-logo.png");
                    var emailSent = this._emailService.SendEmail(htmlBody, logoPath, "Period Closed Report",
                    tenant.EmailAddress, tenant.Name, tenant.ReplyToAddress, tenant.Name, carerinfo.FirstOrDefault().EmailAddress,
                    carerinfo.FirstOrDefault().FirstName + " " + carerinfo.FirstOrDefault().LastName, providerName, null, "PeriodClosedReport.pdf", fileBytes);
                }
                RecurringJob.RemoveIfExists("MonthClose");

            }
            catch (Exception ex)
            {
                throw;
            }
        }


        public static FeeStructure MapFeeStructureModelToFeeStructures(FeeStructure fee, FeeStructureModel feeStructureModel)
        {

            if (fee == null)
            {
                fee = new FeeStructure();
                fee.CreatedBy = feeStructureModel.CreatedById.Value;
                fee.CreatedOn = DateTime.UtcNow;
            }
            else
            {
                fee.UpdatedBy = feeStructureModel.UpdatedById.Value;
                fee.UpdatedOn = DateTime.UtcNow;
            }

            fee.FeeTitle = feeStructureModel.FeeTitle;
            fee.Weekend = feeStructureModel.Weekend;
            fee.Daily = feeStructureModel.Daily;
            fee.NA = feeStructureModel.NA;
            fee.Fee = Convert.ToDecimal(feeStructureModel.Fee);
            fee.LocalAuthorityCharge = Convert.ToDecimal(feeStructureModel.LocalAuthorityCharge);
            return fee;
        }

        public static ServiceUserFinanceFeeStructure MapServiceUserFinanceViewModelToServiceUserFinanceFeeStructure(ServiceUserFinanceFeeStructure serviceUserFinance, ServiceUserFinanceViewModel serviceUserModel)
        {

            if (serviceUserFinance == null)
            {
                serviceUserFinance = new ServiceUserFinanceFeeStructure();
                serviceUserFinance.CreatedBy = serviceUserModel.UpdatedById.Value;
                serviceUserFinance.CreatedOn = DateTime.UtcNow;
                serviceUserFinance.ServiceUserId = new Guid(serviceUserModel.ServiceUserId);
            }
            else
            {
                serviceUserFinance.UpdatedBy = serviceUserModel.UpdatedById.Value;
                serviceUserFinance.UpdatedOn = DateTime.UtcNow;
                serviceUserFinance.ServiceUserId = new Guid(serviceUserModel.ServiceUserId);
            }
            return serviceUserFinance;
        }

        public static FeeStructureModel MapFeeStructureToFeeStructureModel(FeeStructure fee)
        {
            FeeStructureModel feeModel = new FeeStructureModel();

            feeModel.Id = fee.Id;
            feeModel.FeeTitle = fee.FeeTitle;
            feeModel.CreatedById = fee.CreatedBy;
            if (fee.User != null)
                feeModel.CreatedByUser = Helper.FullName(fee.User.FirstName, fee.User.LastName);
            feeModel.CreatedOn = fee.CreatedOn;
            feeModel.Weekend = fee.Weekend;
            feeModel.Daily = fee.Daily;
            feeModel.NA = fee.NA;
            feeModel.Fee = Convert.ToDouble(fee.Fee);
            if (fee.LocalAuthorityCharge > 0)
                feeModel.LocalAuthorityCharge = Convert.ToDouble(fee.LocalAuthorityCharge);


            feeModel.UpdatedById = fee.UpdatedBy;

            if (fee.UpdatedBy != null)
            {
                feeModel.UpdatedByUser = Helper.FullName(fee.User.FirstName, fee.User.LastName);
                feeModel.UpdatedOn = fee.UpdatedOn;
            }


            return feeModel;

        }


        public static IList<FeeStructureModel> MapFeeStructureToFeeStructureModels(IList<FeeStructure> fee)
        {
            IList<FeeStructureModel> feeModels = new List<FeeStructureModel>();

            foreach (var f in fee)
                feeModels.Add(MapFeeStructureToFeeStructureModel(f));
            return feeModels;
        }

        public static ServiceUserFinanceViewModel MapServiceUserFinanceFeeStructureToServiceUserFinanceViewModel(ServiceUserFinanceFeeStructure fee)
        {
            ServiceUserFinanceViewModel feeModel = new ServiceUserFinanceViewModel();
            //if (fee.FeeStructureId != null && fee.FeeStructure != null)
            //{
            //    feeModel.FeeStructureTitle = fee.FeeStructure.FeeTitle;
            //}
            feeModel.FeeStructureIdInt = fee.FeeStructureId;
            feeModel.CreatedById = fee.CreatedBy;
            if (fee.User != null)
                feeModel.CreatedByUser = Helper.FullName(fee.User.FirstName, fee.User.LastName);
            feeModel.CreatedOn = fee.CreatedOn;
            feeModel.UpdatedById = fee.UpdatedBy;
            if (fee.UpdatedBy != null)
            {
                feeModel.UpdatedByUser = Helper.FullName(fee.User.FirstName, fee.User.LastName);
                feeModel.UpdatedOn = fee.UpdatedOn;
            }
            return feeModel;
        }
        public static List<MonthViewModel> MapMonthToMonthViewModel(List<Month> monthsList)
        {
            var monthViewModelList = new List<MonthViewModel>();
            foreach (var item in monthsList)
            {
                var month = new MonthViewModel();
                month.Id = item.Id;
                month.Month = item.Name;
                monthViewModelList.Add(month);
            }
            return monthViewModelList;
        }
        public static List<YearViewModel> MapYearToYearViewModel(List<Year> monthsList)
        {
            var monthViewModelList = new List<YearViewModel>();
            foreach (var item in monthsList)
            {
                var month = new YearViewModel();
                month.Id = item.Id;
                month.Year = item.Name;
                monthViewModelList.Add(month);
            }
            return monthViewModelList;
        }
        public static SLcFeeStracture MapSLCFeeStructureModelToSLCFeeStructures(SLcFeeStracture fee, SLCFeeStructureModel feeStructureModel)
        {
            int currentDay = (int)System.DateTime.UtcNow.Day;

            fee = new SLcFeeStracture();
            fee.CreatedBy = feeStructureModel.CreatedById;
            fee.CreatedOn = DateTime.UtcNow;
            fee.FeeStracture = feeStructureModel.FeeStructureId;
            fee.CarerId = new Guid(feeStructureModel.CarerId);
            fee.Weekly = feeStructureModel.Weekend;
            fee.Daily = feeStructureModel.Daily;
            fee.NA = feeStructureModel.NA;
            fee.Amount = feeStructureModel.Fee;
            fee.Description = feeStructureModel.Description;
            //fee.M = feeStructureModel.Month;
            //fee.Y = feeStructureModel.Year;
            //fee.Tdate = Convert.ToDateTime(feeStructureModel.Year + "-" + feeStructureModel.Month + "-" + currentDay);
            fee.M = feeStructureModel.TDate.Month;
            fee.Y = feeStructureModel.TDate.Year;
            fee.Tdate = feeStructureModel.TDate;
            if (feeStructureModel.AdditionOrDeduction == Common.Constants.FinanceStatus.Addition)
            {
                fee.IsAdditionFee = true;
                fee.IsDeduction = false;
            }
            else
            {
                fee.IsAdditionFee = false;
                fee.IsDeduction = true;
            }
            return fee;
        }
        public static SLCFeeStructureModel MapSLCFeeStructureToSLCFeeStructureModel(SLcFeeStracture fee)
        {
            SLCFeeStructureModel feeModel = new SLCFeeStructureModel();

            feeModel.Id = fee.Id;
            feeModel.Description = fee.Description;
            feeModel.CreatedById = fee.CreatedBy;
            feeModel.Weekend = fee.Weekly;
            feeModel.Daily = fee.Daily;
            feeModel.NA = fee.NA;
            feeModel.Fee = fee.Amount ?? 0;
            return feeModel;

        }

        private async Task<List<Arrangement>> MapArrangement(DataTable List)
        {
            List<Arrangement> arrangements = new List<Arrangement>();
            foreach (DataRow row in List.Rows)
            {
                Arrangement item = row.GetItem<Arrangement>();
                arrangements.Add(item);
            }
            return arrangements;
        }

        public string GetAttributeFilterForServiceUser(LeaveSetupSearchModel searchModel)
        {
            string AttributeSearchList = "";
            string AttributeOptionList = "";
            bool flg = false;
            AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
            string onlyAtrributeOptionId = "";
            var attributesSearch = "";
            string attrFilter = "";
            if (AttributeSearchList.Length > 0)
            {
                int flagOption = 0;

                foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                {
                    if (flg == false)
                    {
                        attributesSearch += " c.Id in (select distinct serviceUserId from UserAttribute where " +
                       "AttributeId = " + item.AttributeId.ToString();
                        flg = true;
                    }
                    else
                    {
                        attributesSearch += " and c.Id in (select distinct serviceUserId from UserAttribute where " +
                       "AttributeId = " + item.AttributeId.ToString();
                    }
                    onlyAtrributeOptionId = "";
                    flagOption = 0;
                    foreach (var option in item.AttributeOptions.ToList())
                    {
                        if (flagOption == 0)
                            onlyAtrributeOptionId = option.Id.ToString();
                        else
                            onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                        flagOption = 1;
                    }
                    attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and serviceUserId is not null)";
                }
                attrFilter = attributesSearch;
            }
            return attrFilter;
        }
        public string GetAttributeFilterForCarer(LeaveSetupSearchModel searchModel, int search)
        {
            string AttributeSearchList = "";
            string AttributeOptionList = "";
            bool flg = false;
            AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
            string onlyAtrributeOptionId = "";
            string onlyAtrributeOptionIdTemp = "";
            var attributesSearch = "";
            var attributesSearchTemp = "";
            string attrFilter = "";
            string attrFilterTemp = "";
            if (AttributeSearchList.Length > 0)
            {
                int flagOption = 0;

                foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                {
                    if (flg == false)
                    {
                        attributesSearch += " c.Id in (select distinct CarerId  from UserAttribute where " +
                            "AttributeId = " + item.AttributeId.ToString();
                        attributesSearchTemp += "(AttributeId = " + item.AttributeId.ToString();
                        flg = true;
                    }
                    else
                    {
                        attributesSearch += " and c.Id in (select distinct CarerId  from UserAttribute where " +
                            "AttributeId = " + item.AttributeId.ToString();
                        attributesSearchTemp += " and (AttributeId = " + item.AttributeId.ToString();
                    }
                    onlyAtrributeOptionId = "";
                    flagOption = 0;
                    foreach (var option in item.AttributeOptions.ToList())
                    {
                        if (flagOption == 0)
                            onlyAtrributeOptionId = option.Id.ToString();
                        else
                            onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                        flagOption = 1;
                    }
                    attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and CarerId  is not null)";
                    attributesSearchTemp = attributesSearchTemp + " and OptionId in(" + onlyAtrributeOptionId + "))";
                }
                attrFilter = attributesSearch;
                attrFilterTemp = attributesSearchTemp;
            }
            if (search == 1)
                return attrFilter;
            else
                return attrFilterTemp;
        }

        // salman 14 july

        // salman 14 july

        public static List<FiscalDatesObjects> calculateFiscalDates(DateTime StartDate, DateTime EndDate)
        {
            List<FiscalDatesObjects> fiscalDates = new List<FiscalDatesObjects>();
            var dateOneSD = new DateTime();
            var dateOneED = new DateTime();
            var dateTwoSD = new DateTime();
            var dateTwoED = new DateTime();
            if (StartDate.Year == EndDate.Year)
            {
                if (StartDate.Month <= 3 && EndDate.Month > 3)
                {
                    dateOneSD = StartDate;
                    dateOneED = new DateTime(StartDate.Year, 3, 31);
                    dateTwoSD = new DateTime(StartDate.Year, 4, 1);
                    dateTwoED = EndDate;
                    fiscalDates.Add(new FiscalDatesObjects { StartDate = dateOneSD, EndDate = dateOneED });
                    fiscalDates.Add(new FiscalDatesObjects { StartDate = dateTwoSD, EndDate = dateTwoED });
                }
                else
                {
                    dateOneSD = StartDate;
                    dateOneED = EndDate;
                    fiscalDates.Add(new FiscalDatesObjects { StartDate = dateOneSD, EndDate = dateOneED });
                }

            }

            if (StartDate.Year != EndDate.Year)
            {
                if (StartDate.Month >= 3 && EndDate.Month > 3)
                {
                    dateOneSD = StartDate;
                    dateOneED = new DateTime(StartDate.Year + 1, 3, 31);// one year is added in it
                    dateTwoSD = new DateTime(StartDate.Year + 1, 4, 1); // one year is added in it
                    dateTwoED = EndDate;
                    fiscalDates.Add(new FiscalDatesObjects { StartDate = dateOneSD, EndDate = dateOneED });
                    fiscalDates.Add(new FiscalDatesObjects { StartDate = dateTwoSD, EndDate = dateTwoED });
                }
                else
                {
                    dateOneSD = StartDate;
                    dateOneED = EndDate;
                    fiscalDates.Add(new FiscalDatesObjects { StartDate = dateOneSD, EndDate = dateOneED });
                }

            }

            return fiscalDates;
        }

        public static CarerHolidayData calculateFiscalHolidays(DateTime StartDate, DateTime EndDate, Guid CarerId, int LeaveTypeId)
        {
            var SDY = StartDate.Year; // Start Date Year
            var SDM = StartDate.Month; // StartDate Month
            var fysd = new DateTime(); // fiscal year start date
            var fey = new DateTime(); // fiscal year end date
            var calculatedHolidays = 0;
            var carerDataReturn = new CarerHolidayData();
            var cYear = 0; //calculated year

            if (SDM > 3)
            {
                fysd = new DateTime(SDY, 4, 1);
                fey = new DateTime(SDY + 1, 3, 31);
                cYear = SDY;
            }
            else if (SDM <= 3)
            {
                fysd = new DateTime(SDY - 1, 4, 1);
                fey = new DateTime(SDY, 3, 31);
                cYear = SDY - 1;
            }

            if (StartDate >= fysd && EndDate <= fey)
            {
                calculatedHolidays = Convert.ToInt32((EndDate - StartDate).TotalDays) + 1;

                carerDataReturn = new CarerHolidayData { CarerId = CarerId, FiscalYear = cYear, Holidays = calculatedHolidays, HolidayType = LeaveTypeId };
            }

            return carerDataReturn;
        }
        // salman 13 july
        /*
        public static List<FiscalYear> getFiscalYears(DateTime? fromDate, DateTime? toDate)
        {
            if (fromDate == null || toDate == null)
            {
                return new List<FiscalYear>(); // Return an empty list if fromDate or toDate is null
            }

            // Adjust the fromDate to the start of the fiscal year
            DateTime fiscalYearStart = new DateTime(fromDate.Value.Year, 4, 1);
            if (fromDate < fiscalYearStart)
            {
                fiscalYearStart = new DateTime(fromDate.Value.Year - 1, 4, 1);
            }

            // Adjust the toDate to the end of the fiscal year
            DateTime fiscalYearEnd = new DateTime(toDate.Value.Year, 3, 31);
            if (toDate > fiscalYearEnd)
            {
                fiscalYearEnd = new DateTime(toDate.Value.Year + 1, 3, 31);
            }

            // Calculate the number of years between the adjusted fiscal years
            int numYears = fiscalYearEnd.Year - fiscalYearStart.Year;

            // Create a list of fiscal years
            List<FiscalYear> fiscalYears = new List<FiscalYear>();
            for (int i = 0; i < numYears; i++)
            {
                int year = fiscalYearStart.Year + i;
                fiscalYears.Add(new FiscalYear { Id = i + 1, Year = year,
                    FromDate = fromDate,
                    ToDate = toDate
                });
            }

            return fiscalYears;
        }
        */

        // end salman 13 july
        // salman new function for getting total holidays
        /*
        public static int getTotalHolidayBetweenDates(int carerYearlyHolidays, DateTime filteredFromDate, DateTime filteredToDate)
        {
            // UK financial year starts from 6 april to 5 april in next year 
            // so we are considering  6april 2023 to 5 april 2024 as one year
            // Adjust the start date if it's before April 6th
            // this function will return total holidays based on years included in date range selected from the frontend
            // for example if carer holidays are 25 per year and date range contains 2 years then it will return 50 as total holidays
            if (filteredFromDate.Month < 4 || (filteredFromDate.Month == 4 && filteredFromDate.Day < 6))
            {
                filteredFromDate = new DateTime(filteredFromDate.Year - 1, 4, 6);
            }

            // Adjust the end date if it's before April 6th
            if (filteredToDate.Month < 4 || (filteredToDate.Month == 4 && filteredToDate.Day < 6))
            {
                filteredToDate = new DateTime(filteredToDate.Year - 1, 4, 5);
            }

            // Calculate the number of years
            // 1 is added always because to increase one number of year, if both dates are in same year it will show 0, which is not fine, it should return 1, so for other cases also we need to increment 1
            int numberOfYears = (filteredToDate.Year - filteredFromDate.Year) + 1;

            // Check if the end date falls before the start date in the same fiscal year
            if (filteredToDate < new DateTime(filteredToDate.Year, 4, 6))
            {
                numberOfYears--;
            }

            int totalHolidaysInDateRange = numberOfYears * carerYearlyHolidays;

            return totalHolidaysInDateRange;
        }
        */
        // end new function
        #endregion
    }
}
