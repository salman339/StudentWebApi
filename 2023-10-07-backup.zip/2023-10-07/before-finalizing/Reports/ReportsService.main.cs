﻿using BusinessEntities;
using BusinessEntities.Reports;
using BusinessEntities.Users.Bookers;
using BusinessServices.Audit;
using BusinessServices.Tenants;
using Common;
using DataAccessLayer.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessServices.Reports
{
    public interface IReportsService:IDisposable
    {
        Task<PagedResults<TemplateListViewModel>> FindAllTemplates(QueryParameter queryParameter, TemplateSearchModel searchModel);
        Task<bool> DeleteTemplate(int templateId, Guid UserId);
        Task<TemplateListViewModel> TemplateDetails(int? templateId);
        Task<IList<ReportColumnsListModel>> GetAllReportColumns(int type);
        Task<ResponseViewModel<bool>> InsertUpdateTemplateReport(TemplateReportModel model, Guid userId);
        Task<Stream> DownloadReportResultsInExcel(ReportSearchModel searchModel);
        Task<Stream> DownloadRequirementReportResultsInExcel(ReportSearchModel searchModel);
        Task<bool> FindTempByName(string searchValue, int Id);
        Task<List<TemplateNameListViewModel>> GetTempNameByType(int typeId);
        Task<IList<RequirementReportListViewModel>> GetRequirementReportList(RequirementReportSearchModel searchModel);
        Task<List<DocumentDescriptionListView>> GetAllDocumentDescriptionByUser(int requirementId, Guid serviceUserId,string incidentSeverties, DateTime dateFrom, DateTime dateTo);
        Task<List<DocumentDescriptionListView>> GetAllDocumentDescriptionByUserRequirementReport(int requirementId, Guid UserId, DateTime? dateFrom, DateTime? dateTo,bool IsCarer);
        Task<bool> CheckActiveDeactiveUser(Guid ServiceUserId, bool IsCarer);
        Task<IList<IncidentReportListViewModel>> GetIncidentReportList(IncidentReportSearchModel searchModel);
        Task<Stream> DownloadIncidentReportResultsInExcel(IncidentReportSearchModel searchModel);

        //Finance Report
        //Task<IList<CarerFeeStructureViewModels>> GetFinanceReportList(FinanceReportSearchModel searchModel);
        Task<List<CarerFeeStructureViewModels>> GetFinanceReportList(FinanceReportSearchModel searchModel, Guid? UserId);
        Task<Stream> DownloadFinanceReportResultsInExcel(FinanceReportSearchModel searchModel, Guid? UserId);
        Task<byte[]> DownloadFinanceReportResultsInPdf(FinanceReportSearchModel searchModel, Guid? UserId);



    }
    public partial class ReportsService : IReportsService, IDisposable
    {
        #region Private variables... 
        private bool disposed = false;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ITenantService _tenantService;
        private readonly IAuditService _auditService;
        #endregion
        public ReportsService(ITenantService tenantService, IAuditService auditService)
        {
            _tenantService = tenantService;
            _auditService = auditService; 
            _unitOfWork = new UnitOfWork();
        }
        #region Implementing IDiosposable...
        /// <summary>
        /// Protected Virtual Dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _unitOfWork.Dispose();
                    _tenantService.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {

            Dispose(true);
            GC.SuppressFinalize(this);

        }




        #endregion
    }
}
