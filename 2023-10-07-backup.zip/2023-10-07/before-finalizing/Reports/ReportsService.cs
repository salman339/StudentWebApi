﻿using BusinessEntities;
using BusinessEntities.Exceptions;
using BusinessEntities.Reports;
using BusinessEntities.Security;
using BusinessEntities.Users.Bookers;
using BusinessServices.Others;
using ClosedXML.Excel;
using Common;
using DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using LinqKit;
using System.Globalization;

namespace BusinessServices.Reports
{
    public partial class ReportsService
    {

        public async Task<PagedResults<TemplateListViewModel>> FindAllTemplates(QueryParameter queryParameter, TemplateSearchModel searchModel)
        {
            int totalRecords = 0;
            DateTime endDate = DateTime.Now;
            IList<TemplateListViewModel> TemplateViewModels = new List<TemplateListViewModel>();

            var dateFilter = string.Empty;
            var filter = string.Empty;
            var tenant = await _tenantService.GetCurrentTenant();


            filter = filter + (string.IsNullOrWhiteSpace(filter) ? string.Empty : " and ") + " TenantId=" + await _tenantService.GetCurrentTenantId();


            if (searchModel != null)
            {

                if (!string.IsNullOrWhiteSpace(searchModel.WildCard))
                {
                    var wildCard = searchModel.WildCard.Replace("'", "''");
                    filter = filter + " and (Id Like \'%" + wildCard.Trim() + "%\'";
                    filter = filter + " or TemplateName Like N\'%" + wildCard.Trim() + "%\'";
                    filter = filter + " or ColumnName Like N\'%" + wildCard.Trim() + "%\')";

                }
            }
            var totalRecordResultQuery = string.Format("select count(*) as totalRecords from TemplateListView {0} {1} ", string.IsNullOrWhiteSpace(filter) ? string.Empty : "Where", filter);
            var totalRecordsResult = await _unitOfWork.ExecuteSqlCommandSqlServer(totalRecordResultQuery);
            totalRecords = int.Parse(totalRecordsResult.Rows[0]["totalRecords"].ToString());

            if (totalRecords > 0)
            {
                var listQuery = string.Format("Select * from TemplateListView {0} {1} Order by Id desc  OFFSET {2} ROWS FETCH NEXT {3} ROWS ONLY ",
                       string.IsNullOrWhiteSpace(filter) ? string.Empty : "Where", filter, ((int)queryParameter.PageNumber - 1) * ((int)queryParameter.PageSize),
                       (int)queryParameter.PageSize);

                var ReportTemplateListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                TemplateViewModels = MapTemplateListDataTableToViewModels(ReportTemplateListData, tenant);
            }

            return new PagedResults<TemplateListViewModel>(queryParameter, TemplateViewModels, totalRecords);

        }

        public async Task<bool> DeleteTemplate(int templateId, Guid UserId)
        {
            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var currentTenantId = await _tenantService.GetCurrentTenantId();
                var templateDetail = await _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == templateId);
                var template = await _unitOfWork.TemplateReportRepository.FindAllAsync(x => x.Id == templateId);
                //---------------------- Audit Trail  ------------------------// 	
                AuditTrail auditTrail = new AuditTrail()
                {
                    CreatedBy = UserId,
                    CreatedOn = DateTime.UtcNow,
                    ObjectArea = Common.Constants.AuditTrailAreas.TemplateDetail,
                    ObjectId = UserId.ToString(),
                    ObjectType = Common.Constants.Users.BetterTogetherAdministrator,
                    PropertyName = Common.Constants.AuditTrailAreas.TemplateDeleted.ToString(),
                    PropertyNewValue = "",
                    PropertyOldValue = template.FirstOrDefault().TemplateName,
                    TenantId = currentTenantId
                };
                _auditService.CreateAuditTrail(auditTrail, this._unitOfWork);
                //----------------------End Audit Trail  ------------------------// 	
                _unitOfWork.TemplateReportDetailRepository.DeleteObjects(templateDetail);

                _unitOfWork.TemplateReportRepository.Delete(templateId);
                var response = await _unitOfWork.SaveChangesAsync();

                scope.Complete();

                if (response > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

        }

        public async Task<TemplateListViewModel> TemplateDetails(int? templateId)
        {
            TemplateListViewModel templateDetailViewModel = new TemplateListViewModel();
            List<TemplateReportDetailModel> templateDetailsList = new List<TemplateReportDetailModel>();
            var template = await _unitOfWork.TemplateReportRepository.FindByIdAsync(templateId);

            if (template != null)
            {
                var templateDetail = await _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == template.Id);
                templateDetailViewModel.Id = template.Id;
                templateDetailViewModel.TemplateName = template.TemplateName;
                templateDetailViewModel.IsCarer = template.IsCarer ?? false;
                templateDetailViewModel.IsServiceUser = template.IsServiceUser ?? false;
                templateDetailViewModel.IsTeam = template.IsTeam ?? false;

                foreach (var item in templateDetail)
                {
                    int? columnId = 0;
                    int? attributeColumnId = 0;
                    if (item.ColumnId > 0)
                        columnId = (int)item.ColumnId;
                    else { columnId = null; }
                    if (item.AttributeColumnId > 0)
                        attributeColumnId = (int)item.AttributeColumnId;
                    else { attributeColumnId = null; }
                    var TemplateReportDetails = new TemplateReportDetailModel()
                    {
                        Id = item.Id,
                        TemplateId = (int)item.TemplateId,
                        ColumnId = columnId,
                        AttributeColumnId = attributeColumnId,
                        SortingOrder = item.SortingOrder == null ? 0 : item.SortingOrder
                    };
                    templateDetailsList.Add(TemplateReportDetails);

                }
                templateDetailViewModel.TemplateReportDetails = templateDetailsList;
            }

            return templateDetailViewModel;

        }

        public async Task<IList<ReportColumnsListModel>> GetAllReportColumns(int type)
        {
            var tenant = await _tenantService.GetCurrentTenant();
            bool iscarer = false;
            bool isserviceuser = false;
            bool isteam = false;
            if (type == 1)
                iscarer = true;
            else if (type == 2)
                isserviceuser = true;
            else if (type == 3)
                isteam = true;
            var columnnames = await _unitOfWork.ReportColumnRepository.FindAllAsync(x => x.IsActive == true
            && x.IsCarer == iscarer && x.IsServiceUser == isserviceuser &&
            x.IsTeam == isteam);

            Func<Attributee, bool> where = null;

            if (type == 1)
                where = p => p.IsSharedLivesCarer == iscarer;
            else if (type == 2)
                where = p => p.IsPeopleWeSupport == isserviceuser;
            else if (type == 3)
                where = p => p.IsTeam == isteam;
            var attribute = await _unitOfWork.AttributeRepository.FindAllAsync(where, true);
            attribute = attribute.OrderBy(x => x.AttributeName).ToList();
            columnnames = columnnames.OrderBy(x => x.DisplayName).ToList();

            return MapReportColumnsListModels(columnnames, attribute);
        }

        public async Task<ResponseViewModel<bool>> InsertUpdateTemplateReport(TemplateReportModel model, Guid userId)
        {

            using (var scope = new TransactionScope(TransactionScopeAsyncFlowOption.Enabled))
            {
                var tenantId = await _tenantService.GetCurrentTenantId();
                var templatedata = await _unitOfWork.TemplateReportRepository.GetFirstOrDefaultAsync(x => x.Id == model.Id);
                var templatedetail = await _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == model.Id);
                //---------------------- Audit Trail Template ------------------------// 	
                var ColumnIds = String.Join(",", model.TemplateReportDetails.Where(x => x.ColumnId > 0).Select(p => p.ColumnId));
                var AttributeColumnIds = String.Join(",", model.TemplateReportDetails.Where(x => x.AttributeColumnId > 0).Select(p => p.AttributeColumnId));
                model.Columns = await FindColumnsByIdAsync(ColumnIds);
                if (ColumnIds == "")
                    model.Columns = await FindAttributeColumnByIdAsync(AttributeColumnIds);
                else if (AttributeColumnIds == "")
                    model.Columns = await FindColumnsByIdAsync(ColumnIds);
                else
                    model.Columns = await FindColumnsByIdAsync(ColumnIds) + "," + await FindAttributeColumnByIdAsync(AttributeColumnIds);
                model.UpdatedBy = userId;
                TemplateReportModel oldTemplateobj = new TemplateReportModel();
                if (model.Id != 0)
                {
                    bool uniqeName = false;
                    uniqeName = await FindTempByName(model.TemplateName, model.Id);
                    if (uniqeName)
                        throw new BusinessException(Common.ErrorMessages.Security.AlreadyExistsTemplatename);
                    oldTemplateobj = await FindTemplateByIdAsync(model.Id);
                    //for old object 
                    if (oldTemplateobj.IsCarer)
                        oldTemplateobj.UserType = Common.Constants.Users.SharedLivesCarer;
                    if (oldTemplateobj.IsServiceUser)
                        oldTemplateobj.UserType = Common.Constants.Users.PeopleWeSupport;
                    if (oldTemplateobj.IsTeam)
                        oldTemplateobj.UserType = Common.Constants.Users.Team;

                    //for new object
                    if (model.IsCarer)
                        model.UserType = Common.Constants.Users.SharedLivesCarer;
                    if (model.IsServiceUser)
                        model.UserType = Common.Constants.Users.PeopleWeSupport;
                    if (model.IsTeam)
                        model.UserType = Common.Constants.Users.Team;

                }
                model.TenantId = tenantId;

                var template = new TemplateReport();

                if (model.Id == 0)
                {
                    model.CreatedOn = DateTime.UtcNow;
                    model.CreatedById = userId;
                    bool uniqeName = false;
                    uniqeName = await FindTempByName(model.TemplateName, 0);
                    if (uniqeName)
                        throw new BusinessException(Common.ErrorMessages.Security.AlreadyExistsTemplatename);
                    template = MapToTemplateBindingModel(null, model, tenantId);
                    _unitOfWork.TemplateReportRepository.Insert(template);
                    await _unitOfWork.SaveChangesAsync();
                    model.Id = template.Id;
                    _auditService.AuditTrailHandler<TemplateReportModel>(Common.Constants.AuditTrailObjectPropertySettings.Template, oldTemplateobj, model, nameof(Common.Constants.AuditTrailObjectPropertySettings.Template), Common.Constants.AuditTrailAreas.TemplateDetail.ToString(), null, _unitOfWork);

                    model.TemplateReportDetails.ForEach((x) => x.TemplateId = template.Id);
                }
                else
                {

                    _auditService.AuditTrailHandler<TemplateReportModel>(Common.Constants.AuditTrailObjectPropertySettings.Template, oldTemplateobj, model, nameof(Common.Constants.AuditTrailObjectPropertySettings.Template), Common.Constants.AuditTrailAreas.TemplateDetail.ToString(), null, _unitOfWork);
                    templatedata.UpdatedOn = DateTime.UtcNow;
                    templatedata.UpdatedBy = userId;
                    templatedata.TemplateName = model.TemplateName;
                    templatedata.IsCarer = model.IsCarer;
                    templatedata.IsServiceUser = model.IsServiceUser;
                    templatedata.IsTeam = model.IsTeam;
                    _unitOfWork.TemplateReportRepository.Update(templatedata);
                    await _unitOfWork.SaveChangesAsync();
                    _unitOfWork.TemplateReportDetailRepository.DeleteObjects(templatedetail);
                    await _unitOfWork.SaveChangesAsync();
                    model.TemplateReportDetails.ForEach((x) => x.TemplateId = templatedata.Id);
                }
                var templateDetails = MapToTemplateDetailBindingModels(model.TemplateReportDetails);
                _unitOfWork.TemplateReportDetailRepository.Insert(templateDetails);
                var responseDetail = await _unitOfWork.SaveChangesAsync();
                scope.Complete();
                if (responseDetail > 0)
                {
                    return new ResponseViewModel<bool>() { Data = true, Message = "Template Report Saved Succesfully", Status = 1, Id = model.Id.ToString() };
                }
                else
                {
                    return new ResponseViewModel<bool>() { Data = false, Message = "Something went wrong", Status = 0, Id = model.Id.ToString() };
                }
            }

        }
        public async Task<Stream> DownloadReportResultsInExcel(ReportSearchModel searchModel)
        {
            XLWorkbook workbook = null;
            MemoryStream memoryStream = null;

            try
            {
                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = searchModel.TemplateId == null ? "" : String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
                foreach (var i in searchModel.UserAttributes.ToList())
                {
                    foreach (var j in i.AttributeOptions.ToList())
                    {
                        if (flg == false)
                            AttributeOptionList += j.Id.ToString();
                        else
                            AttributeOptionList += "," + j.Id.ToString();
                        flg = true;
                    }
                }
                // AttributeOptionList = searchModel.TemplateId == null ? "" : String.Join(",", searchModel.UserAttributes.Select(p => p.OptionId));




                var template = await _unitOfWork.TemplateReportRepository.GetFirstOrDefaultAsync(x => x.Id == searchModel.TemplateId);
                var TemplateDetails = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.ColumnId > 0).Result;
                var TemplateDetailsO = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.ColumnId > 0).Result;
                var TemplateDetailsOp = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.ColumnId > 0).Result;
                var TemplateDetailsAttribute = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.AttributeColumnId > 0).Result;
                // TemplateDetailsAttributeO = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.AttributeColumnId > 0).Result;

                var columnnames = TemplateDetails.Select(x => x.ReportColumn).ToList();
                var columnnamesO = TemplateDetailsO.Select(x => x.ReportColumn).ToList();
                var columnnamesOp = TemplateDetailsOp.Select(x => x.ReportColumn).ToList();
                if (columnnames != null)
                    columnnames.ForEach(x => x.ColumnName = x.ColumnName + " as " + "[" + x.DisplayName + "]");
                columnnamesO.ForEach(x => x.ColumnName = "[" + x.DisplayName + "]");

                var AttributeColumnName = TemplateDetailsAttribute.Select(x => x.Attributee).ToList();

                if (AttributeColumnName.Count() > 0)
                    AttributeColumnName.ForEach(x => x.AttributeName = "" + x.AttributeName + "");
                var strSelect = searchModel.TemplateId == null ? "" : String.Join(",", columnnames.Select(p => p.ColumnName));
                var strAtrributeSelect = searchModel.TemplateId == null ? "" : String.Join(",", AttributeColumnName.Select(p => "[" + p.AttributeName + "]"));

                var strSelectO = searchModel.TemplateId == null ? "" : String.Join(",", columnnamesO.Select(p => p.ColumnName));
                var strSelectOp = searchModel.TemplateId == null ? "" : String.Join(",c.", columnnamesOp.Select(p => p.ColumnName));
                //old
                //var whereclause = " where  c.CreatedDate>='" + searchModel.FromDate.Value.Date.ToString() + "' and "
                //  + " c.CreatedDate<='" + searchModel.ToDate.Value.Date.ToString() + "'";
                // 16/8 made it only for team based the below condition, other will work for both SLC and PWS is below
                var whereclause = "";
                if (searchModel.Typeid == Common.Constants.UserTypeIds.TeamIdInt)
                {
                    whereclause += " where  c.CreatedDate>='" + searchModel.FromDate.Value.Date.ToString() + "' and "
                      + " c.CreatedDate<='" + searchModel.ToDate.Value.Date.ToString() + "'";
                }

                // salman adding a new where clause  8/11
                // 103 is the fomat style code which I used, if I dont use it, the correct result does not appear
                // Now we need to fetch those PWS as well whose arrangment End Date is also present inthe date range 
                // for now doing this only for the PWS 
                // 16/8 made it for PWs and SLC same on client requirement
                if (searchModel.Typeid != Common.Constants.UserTypeIds.TeamIdInt)
                {   /*
                    whereclause += " OR (c.[Room End Date] IS NOT NULL AND CONVERT(DATE, c.[Room End Date], 103) >= '"
               + searchModel.FromDate.Value.Date.ToString("yyyy-MM-dd") + "' AND "
               + "CONVERT(DATE, c.[Room End Date], 103) <= '" + searchModel.ToDate.Value.Date.ToString("yyyy-MM-dd") + "')";
                    */
                    // for now for PWS we are making it to check on start date only for arrangments means only fetch those PWS who have arrangement 
                    whereclause += " where ((c.ArrangementStartDate IS NOT NULL AND c.ArrangementStartDate >= '"
               + searchModel.FromDate.Value.Date.ToString(Common.Constants.sqlShortDate) + "' AND "
               + "c.ArrangementStartDate <= '" + searchModel.ToDate.Value.Date.ToString(Common.Constants.sqlShortDate) + "' )";

                    whereclause += " or (c.ArrangementEndDate is not null and c.ArrangementStartDate IS NOT NULL AND c.ArrangementStartDate <= '"
              + searchModel.FromDate.Value.Date.ToString(Common.Constants.sqlShortDate) + "' AND "
              + "  c.ArrangementEndDate>='" + searchModel.FromDate.Value.Date.ToString(Common.Constants.sqlShortDate) + "'))";


                }

                //whereclause += " OR (c.[Room End Date] IS NOT NULL AND c.[Room End Date] >= '" + searchModel.FromDate.Value.Date.ToString("dd/M/yyyy") + "' AND "
                //+ "c.[Room End Date] <= '" + searchModel.ToDate.Value.Date.ToString("dd/M/yyyy") + "')";

                // end salman 
                var whereClauseOpton = "";
                if (AttributeOptionList.Length > 0)
                    whereClauseOpton = " and  att.Id in(" + AttributeOptionList + ") ";
                var whereClauseAttributeOpton = "";



                var ViewListName = "";
                var UserType = "";

                if (searchModel.Typeid == 1)
                {
                    ViewListName = " ReportCarerListView";
                    UserType = "CarerId";

                }
                else if (searchModel.Typeid == 2)
                {
                    ViewListName = " ReportServiceUserListView";
                    UserType = "ServiceUserId";

                }
                else if (searchModel.Typeid == 3)
                {
                    ViewListName = " ReportAdminListView";
                    UserType = "AdministratorId";

                }


                var attributesSearch = "";
                var attributesOptionSearch = "";



                string onlyAtrributeOptionId = "";
                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;

                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        attributesSearch += "and c.Id in (select distinct " + UserType + " from UserAttribute where " +
                            "AttributeId = " + item.AttributeId.ToString();

                        flagOption = 0;
                        onlyAtrributeOptionId = "";
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and " + UserType + " is not null)";
                    }
                    whereClauseAttributeOpton = attributesSearch;
                }
                string[] ColumnstoRemove = { };

                workbook = new XLWorkbook();
                memoryStream = new MemoryStream();
                string AttributeVribale = "";

                if (strAtrributeSelect.Length > 2 && strSelect.Length > 0)
                {
                    AttributeVribale = strAtrributeSelect;
                    strAtrributeSelect = "," + strAtrributeSelect;
                }
                if (strAtrributeSelect.Length > 2 && strSelect.Length == 0)
                {
                    AttributeVribale = strAtrributeSelect;
                    strAtrributeSelect = strAtrributeSelect;
                }
                if (strSelectOp.Length > 2)
                    strSelectOp = "c." + strSelectOp + ",";
                if (strAtrributeSelect.Length == 0)
                {

                    var attribute = await _unitOfWork.AttributeRepository.FindAllAsync();
                    AttributeVribale = "[" + attribute.FirstOrDefault().AttributeName + "]";
                }

                var listQuery = string.Format(
                    "SELECT " + strSelect + strAtrributeSelect + " from (select distinct  c.id,  a.AttributeName," + strSelectOp +
"(select STRING_AGG(att.Options, ',')  from AttributeOption att " +
  " where att.AttributeId = a.Id and att.Id in (select us.OptionId from UserAttribute us where us." + UserType + "=c.Id and us.AttributeId=a.Id)  " + attributesOptionSearch + " ) Options from" + ViewListName + " c " +
" left join UserAttribute arr on arr." + UserType + " = c.Id left join Attributee a on a.id = arr.Attributeid" +
      whereclause + whereClauseAttributeOpton +
"   ) ps PIVOT (max(Options) FOR AttributeName IN(" + AttributeVribale + ") ) AS pvt");




                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                if (exportedResults != null)
                {
                    foreach (DataRow row in exportedResults.Rows)
                    {
                        string values = string.Empty;
                        foreach (DataColumn col in exportedResults.Columns)
                        {
                            if (col.ColumnName == "Report")
                            {

                            }
                            else
                            {
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                    values = values + "," + row[col.ColumnName].ToString();
                            }

                        }
                    }


                }
                workbook.Worksheets.Add(exportedResults, "Report Results");
                workbook.SaveAs(memoryStream);

                return memoryStream;

            }
            catch
            {
                if (memoryStream != null)
                    memoryStream.Dispose();

                memoryStream = null;


                throw;
            }

            finally
            {
                if (workbook != null)
                    workbook.Dispose();

                workbook = null;
            }
        }
        //        public async Task<Stream> DownloadReportResultsInExcel(ReportSearchModel searchModel)
        //        {
        //            XLWorkbook workbook = null;
        //            MemoryStream memoryStream = null;

        //            try
        //            {
        //                string AttributeSearchList = "";
        //                string AttributeOptionList = "";
        //                bool flg = false;
        //                AttributeSearchList = searchModel.TemplateId == null ? "" : String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
        //                foreach (var i in searchModel.UserAttributes.ToList())
        //                {
        //                    foreach (var j in i.AttributeOptions.ToList())
        //                    {
        //                        if (flg == false)
        //                            AttributeOptionList += j.Id.ToString();
        //                        else
        //                            AttributeOptionList += "," + j.Id.ToString();
        //                        flg = true;
        //                    }
        //                }
        //                // AttributeOptionList = searchModel.TemplateId == null ? "" : String.Join(",", searchModel.UserAttributes.Select(p => p.OptionId));




        //                var template = await _unitOfWork.TemplateReportRepository.GetFirstOrDefaultAsync(x => x.Id == searchModel.TemplateId);
        //                var TemplateDetails = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.ColumnId > 0).Result;
        //                var TemplateDetailsO = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.ColumnId > 0).Result;
        //                var TemplateDetailsOp = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.ColumnId > 0).Result;
        //                var TemplateDetailsAttribute = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.AttributeColumnId > 0).Result;
        //                // TemplateDetailsAttributeO = _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == searchModel.TemplateId && x.AttributeColumnId > 0).Result;

        //                var columnnames = TemplateDetails.Select(x => x.ReportColumn).ToList();
        //                var columnnamesO = TemplateDetailsO.Select(x => x.ReportColumn).ToList();
        //                var columnnamesOp = TemplateDetailsOp.Select(x => x.ReportColumn).ToList();
        //                if (columnnames != null)
        //                    columnnames.ForEach(x => x.ColumnName = x.ColumnName + " as " + "[" + x.DisplayName + "]");
        //                columnnamesO.ForEach(x => x.ColumnName = "[" + x.DisplayName + "]");
        //                //columnnamesOp.ForEach(x => x.ColumnName = "c.[" + x.DisplayName + "]");
        //                var AttributeColumnName = TemplateDetailsAttribute.Select(x => x.Attributee).ToList();
        //                //  var AttributeColumnNameOption = TemplateDetailsAttributeO.Select(x => x.Attributee).ToList();
        //                if (AttributeColumnName.Count() > 0)
        //                    AttributeColumnName.ForEach(x => x.AttributeName = "" + x.AttributeName + "");
        //                var strSelect = searchModel.TemplateId == null ? "" : String.Join(",", columnnames.Select(p => p.ColumnName));
        //                var strAtrributeSelect = searchModel.TemplateId == null ? "" : String.Join(",", AttributeColumnName.Select(p => "[" + p.AttributeName + "]"));

        //                var strSelectO = searchModel.TemplateId == null ? "" : String.Join(",", columnnamesO.Select(p => p.ColumnName));
        //                var strSelectOp = searchModel.TemplateId == null ? "" : String.Join(",c.", columnnamesOp.Select(p => p.ColumnName));
        //                var whereclause = " where  c.CreatedOn>='" + searchModel.FromDate.Value.Date.ToString() + "' and "
        //                    + " c.CreatedOn<='" + searchModel.ToDate.Value.Date.ToString() + "'";

        //                var whereClauseOpton = "";
        //                if (AttributeOptionList.Length > 0)
        //                    whereClauseOpton = " and  att.Id in(" + AttributeOptionList + ") ";
        //                var whereClauseAttributeOpton = "";
        //                //if (AttributeSearchList.Length > 0)
        //                //   // whereClauseAttributeOpton = "and a.id in (select AttributeId from AttributeOption  where AttributeOption.Id in(" + AttributeOptionList + ") and AttributeId in(" + AttributeSearchList + ") )  ";





        //                var ViewListName = "";
        //                var UserType = "";

        //                if (searchModel.Typeid == 1)
        //                {
        //                    ViewListName = " ReportCarerListView";
        //                    UserType = "CarerId";

        //                }
        //                else if (searchModel.Typeid == 2)
        //                {
        //                    ViewListName = " ReportServiceUserListView";
        //                    UserType = "ServiceUserId";

        //                }
        //                else if (searchModel.Typeid == 3)
        //                {
        //                    ViewListName = " ReportAdminListView";
        //                    UserType = "AdministratorId";

        //                }

        //                var attrFilter = "";
        //                var attributesSearch = "";
        //                var attributesOptionSearch = "";
        //                var attributesOptions = "";
        //                var onlyAtrributeId = "";
        //                var onlyAtrributeOptionId = "";
        //                int flgopertaion = 0;
        //                int flgopertaions = 0;
        //                if (AttributeSearchList.Length > 0)
        //                {

        //                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
        //                    {
        //                        int flagOption = 0;
        //                        attributesSearch += " and AttributeId = " + item.AttributeId;
        //                        if (flgopertaion == 0)
        //                            onlyAtrributeId = item.AttributeId.ToString();
        //                        else
        //                            onlyAtrributeId = onlyAtrributeId + "," + item.AttributeId.ToString();
        //                        flgopertaion = 1;
        //                        foreach (var option in item.AttributeOptions.ToList())
        //                        {
        //                            attributesOptionSearch = " and att.Id = " + option.Id;
        //                            if (flagOption == 0)
        //                            {
        //                                attributesOptions = " AttributeOption.Id = " + option.Id;

        //                            }
        //                            else
        //                            {
        //                                attributesOptions += " and AttributeOption.Id = " + option.Id;

        //                            }
        //                            if (flgopertaions == 0)
        //                            {
        //                                onlyAtrributeOptionId += option.Id.ToString();
        //                            }
        //                            else
        //                            {
        //                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
        //                            }
        //                            flgopertaions = 1;
        //                            flagOption = 1;
        //                        }
        //                    }
        //                    if (onlyAtrributeId.Length > 0 && searchModel.Typeid == 2)
        //                        whereClauseAttributeOpton = "and a.id in (select AttributeId from AttributeOption where (select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) from (select distinct AttributeId from UserAttribute where ServiceUserId= c.Id) t)= '" + onlyAtrributeId + "' and AttributeOption.Id in(" + onlyAtrributeOptionId + ") )  ";
        //                    else if (onlyAtrributeId.Length > 0 && searchModel.Typeid == 1)
        //                        whereClauseAttributeOpton = "and a.id in (select AttributeId from AttributeOption where (select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) from (select distinct AttributeId from UserAttribute where CarerId= c.Id) t)= '" + onlyAtrributeId + "' and AttributeOption.Id in(" + onlyAtrributeOptionId + ") )  ";
        //                    else if (onlyAtrributeId.Length > 0 && searchModel.Typeid == 3)
        //                        whereClauseAttributeOpton = "and a.id in (select AttributeId from AttributeOption where (select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) from (select distinct AttributeId from UserAttribute where AdministratorId= c.Id) t)= '" + onlyAtrributeId + "' and AttributeOption.Id in(" + onlyAtrributeOptionId + ") )  ";


        //                    //else
        //                    //    whereClauseAttributeOpton = "and a.id in (select AttributeId from AttributeOption  where " + attributesOptions + attributesSearch + " )  ";
        //                    //attrFilter = " inner join UserAttribute UAT on UAT " + UserType + " = s.Id " + attributesSearch + attributesOptionSearch + "";
        //                }

        //                string[] ColumnstoRemove = { };

        //                workbook = new XLWorkbook();
        //                memoryStream = new MemoryStream();
        //                string AttributeVribale = "";

        //                if (strAtrributeSelect.Length > 2 && strSelect.Length > 0)
        //                {
        //                    AttributeVribale = strAtrributeSelect;
        //                    strAtrributeSelect = "," + strAtrributeSelect;
        //                }
        //                if (strAtrributeSelect.Length > 2 && strSelect.Length == 0)
        //                {
        //                    AttributeVribale = strAtrributeSelect;
        //                    strAtrributeSelect = strAtrributeSelect;
        //                }
        //                if (strSelectOp.Length > 2)
        //                    strSelectOp = "c." + strSelectOp + ",";
        //                if (strAtrributeSelect.Length == 0)
        //                {

        //                    var attribute = await _unitOfWork.AttributeRepository.FindAllAsync();
        //                    AttributeVribale = "[" + attribute.FirstOrDefault().AttributeName + "]";
        //                }

        //                var listQuery = string.Format(
        //                    "SELECT " + strSelect + strAtrributeSelect + " from (select distinct  c.id,  a.AttributeName," + strSelectOp +
        //"(select STRING_AGG(att.Options, ',')  from AttributeOption att " +
        //  " where att.AttributeId = a.Id and att.Id in (select us.OptionId from UserAttribute us where us." + UserType + "=c.Id and us.AttributeId=a.Id)  " + attributesOptionSearch + " ) Options from" + ViewListName + " c " +
        //" left join UserAttribute arr on arr." + UserType + " = c.Id left join Attributee a on a.id = arr.Attributeid" +
        //      whereclause + whereClauseAttributeOpton +
        //"   ) ps PIVOT (max(Options) FOR AttributeName IN(" + AttributeVribale + ") ) AS pvt");

        //                //                var listQuery = string.Format(
        //                //                    "SELECT " + strSelect + strAtrributeSelect + " from (select distinct  c.id,  a.AttributeName," + strSelectOp +
        //                //"(select STRING_AGG(att.Options, ',')  from AttributeOption att " +
        //                //  " where att.AttributeId = a.Id and att.Id in (select us.OptionId from UserAttribute us where us." + UserType + "=c.Id and us.AttributeId=a.Id)  " + whereClauseOpton + " ) Options from" + ViewListName + " c " +
        //                //" left join UserAttribute arr on arr." + UserType + " = c.Id left join Attributee a on a.id = arr.Attributeid" +
        //                //      whereclause + whereClauseAttributeOpton +
        //                //"   ) ps PIVOT (max(Options) FOR AttributeName IN(" + AttributeVribale + ") ) AS pvt");

        //                //where a.id in (select AttributeId from AttributeOption 
        //                //" + whereClauseAttributeOpton + " ) "


        //                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
        //                if (exportedResults != null)
        //                {
        //                    foreach (DataRow row in exportedResults.Rows)
        //                    {
        //                        string values = string.Empty;
        //                        foreach (DataColumn col in exportedResults.Columns)
        //                        {
        //                            if (col.ColumnName == "Report")
        //                            {
        //                                //if (row[col.ColumnName] != DBNull.Value)
        //                                //{
        //                                //    var reportValues = row[col.ColumnName].ToString().Split(';');

        //                                //    row[col.ColumnName] = string.Empty;
        //                                //    foreach (var reportValue in reportValues)
        //                                //    {
        //                                //        var reportValueInnerVals = reportValue.Split(new string[] { @"\r\n" }, StringSplitOptions.None);

        //                                //        string newValue = string.Empty;
        //                                //        foreach (var reportValueInnerVal in reportValueInnerVals)
        //                                //        {
        //                                //            if (newValue == string.Empty)
        //                                //                newValue = reportValueInnerVal;
        //                                //            else
        //                                //                newValue = newValue + "\r\n" + reportValueInnerVal;
        //                                //        }


        //                                //        row[col.ColumnName] = (string.IsNullOrWhiteSpace(row[col.ColumnName].ToString()) ? newValue : row[col.ColumnName] + "\r\n\r\n" + newValue);
        //                                //    }
        //                                //}
        //                            }
        //                            else
        //                            {
        //                                if (values == string.Empty)
        //                                    values = row[col.ColumnName].ToString();
        //                                else
        //                                    values = values + "," + row[col.ColumnName].ToString();
        //                            }

        //                        }
        //                    }

        //                    //if (ColumnsforStatus.Length > 0)
        //                    //{
        //                    //    if (!strSelect.Contains(Constants.Columns.Duration))
        //                    //        ColumnsforStatus.Replace("," + Constants.Columns.Duration, "");

        //                    //    if (!strSelect.Contains(Constants.Columns.StartDate))
        //                    //        ColumnsforStatus.Replace("," + Constants.Columns.StartDate, "");
        //                    //    if (strSelect.Contains(Constants.Columns.LinguistName))
        //                    //        ColumnsforStatus.Replace("," + Constants.Columns.AgencyId + "," + Constants.Columns.LinguistId + "," + Constants.Columns.AgencyProviderName, "");
        //                    //    foreach (string column in ColumnsforStatus.Split(','))
        //                    //        columns.Add(column);
        //                    //    foreach (var item in columns)
        //                    //    {
        //                    //        if (item != "")
        //                    //            exportedResults.Columns.Remove(item);
        //                    //    }
        //                    //}
        //                }
        //                workbook.Worksheets.Add(exportedResults, "Report Results");
        //                workbook.SaveAs(memoryStream);

        //                return memoryStream;

        //            }
        //            catch
        //            {
        //                if (memoryStream != null)
        //                    memoryStream.Dispose();

        //                memoryStream = null;


        //                throw;
        //            }

        //            finally
        //            {
        //                if (workbook != null)
        //                    workbook.Dispose();

        //                workbook = null;
        //            }
        //        }
        public async Task<bool> FindTempByName(string searchValue, int Id)
        {
            var tenantId = await _tenantService.GetCurrentTenantId();
            Boolean TempExist = false;
            var result = await _unitOfWork.TemplateReportRepository.GetFirstOrDefaultAsync(x => x.TemplateName == searchValue && x.Id != Id && x.TenantId == tenantId);
            if (result != null)
            {
                TempExist = true;
            }

            return TempExist;

        }

        public async Task<List<TemplateNameListViewModel>> GetTempNameByType(int type)
        {
            try
            {
                IList<TemplateNameListViewModel> templateNameListViewModels = new List<TemplateNameListViewModel>();

                var templates = await _unitOfWork.TemplateReportRepository.FindAllAsync(x => (x.IsCarer == true && type == 1) ||
                  (x.IsServiceUser == true && type == 2) || (x.IsTeam == true && type == 3));
                foreach (var item in templates)
                {
                    var template = new TemplateNameListViewModel();
                    template.Id = item.Id;
                    template.Name = item.TemplateName;
                    templateNameListViewModels.Add(template);
                }
                return templateNameListViewModels.OrderBy(x => x.Name).ToList();

            }
            catch (Exception ex)
            {
                throw;
            }

        }



        public async Task<IList<RequirementReportListViewModel>> GetRequirementReportList(RequirementReportSearchModel searchModel)
        {
            try
            {   // salman 
                // variables
                var tblName = "";
                var tblUserId = "";
                var IdUserId = "";
                var isSuperAdmin = searchModel.IsSuperAdmin; // salman 8/8
                var searchedAdminId = searchModel.UserId; // salman 8/8
                var carerAdminId = ""; // salman 8/8
                var adminBasedSearchJoinClause = ""; //salman 8/8
                var adminBasedSearchWhereClause = ""; // in case of carer 
                //
                // var userType = 2;
                var IsCarer = searchModel.IsCarer;

                if (IsCarer == 1)
                {
                    tblName = "[User]";
                    tblUserId = "d.CarerId";
                    IdUserId = "CarerId";
                }
                else
                {
                    tblName = "ServiceUser";
                    tblUserId = "d.ServiceUserId";
                    IdUserId = "ServiceUserId";
                }

                // salman 8/8
                if ((isSuperAdmin == 1 && searchedAdminId != "0") || (isSuperAdmin == 0 && searchedAdminId != "0"))
                {
                    if (IsCarer == 1)
                    {
                        // for carer we are using such logic because carer data is present in two tables one is Carer and other is User
                        carerAdminId += "c.AdministratorId,";
                        adminBasedSearchJoinClause += " inner join Carer c ON c.Id = s.Id ";
                        adminBasedSearchWhereClause += "and c.AdministratorId = '" + searchedAdminId + "'";
                    }
                    else
                    {
                        adminBasedSearchWhereClause += " and s.AdministratorId = '" + searchedAdminId + "'";
                    }
                }
                // end salman 8/8
                // end salman
                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
                //foreach (var i in searchModel.UserAttributes.ToList())
                //{
                //    foreach (var j in i.AttributeOptions.ToList())
                //    {
                //        if (flg == false)
                //            AttributeOptionList += j.Id.ToString();
                //        else
                //            AttributeOptionList += "," + j.Id.ToString();
                //        flg = true;
                //    } 
                //}
                var attributesSearch = "";
                List<RequirementReportListViewModel> requirementListViewModel = new List<RequirementReportListViewModel>();
                string attrFilter = "";
                string onlyAtrributeOptionId = "";
                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;

                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        //attributesSearch += " and s.Id in (select distinct serviceUserId from UserAttribute where " + // old, below is salman 25/7
                        attributesSearch += " and s.Id in (select distinct " + IdUserId + " from UserAttribute where " +
                       "AttributeId = " + item.AttributeId.ToString();
                        onlyAtrributeOptionId = "";
                        flagOption = 0;
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        //attributesSearch = attributesSearch + " and OptionId in("+ onlyAtrributeOptionId + ") and serviceUserId is not null)";
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and " + IdUserId + " is not null)";
                    }
                    attrFilter = attributesSearch;
                }


                //                  attrFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = s.Id and ((select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) " +
                //"from(select distinct AttributeId from UserAttribute where ServiceUserId = s.Id) t)=  '" + onlyAtrributeId + "')" + attributesOptionSearch + ")";
                //old:  var listQuery = string.Format("select distinct s.FirstName + ' ' + s.LastName as UserName,d.RequirementId,d.ServiceUserId,d.Id as 'DocumentId' from ServiceUser s inner join Document d on d.ServiceUserId = s.Id " + attrFilter + " where d.ServiceUserId is not null and s.AppStatusValId !=3 and d.RequirementId is not null and d.IsArchive='false'" +
                //old:    " and convert(date,d.CreatedOn) >='" + searchModel.FromDate.Value.Date.ToString() + "' and  convert(date,d.CreatedOn) <='" + searchModel.ToDate.Value.Date.ToString() + "'  order by UserName asc");
                // now making the query to run for both Carer and Service User
                // before admin based search
                // var listQuery = string.Format("select distinct s.FirstName + ' ' + s.LastName as UserName,d.RequirementId,d.EndDate," + tblUserId + " as UserId,d.Id as 'DocumentId' from " + tblName + " s inner join Document d on " + tblUserId + " = s.Id " + attrFilter + " where " + tblUserId + " is not null and s.AppStatusValId !=3 and d.RequirementId is not null and d.IsArchive='false'" +
                //  " and convert(date,d.CreatedOn) >='" + searchModel.FromDate.Value.Date.ToString() + "' and  convert(date,d.CreatedOn) <='" + searchModel.ToDate.Value.Date.ToString() + "'  order by UserName asc");

                //for date filter
                //var listQuery = string.Format("select distinct s.FirstName + ' ' + s.LastName as UserName,d.RequirementId,d.EndDate, "+ carerAdminId +"" + tblUserId + " as UserId,d.Id as 'DocumentId' from " + tblName + " s inner join Document d on " + tblUserId + " = s.Id " + attrFilter + " "+ adminBasedSearchJoinClause + " where " + tblUserId + " is not null and s.AppStatusValId !=3 and d.RequirementId is not null and d.IsArchive='false'" +
                //   " and convert(date,d.CreatedOn) >='" + searchModel.FromDate.Value.Date.ToString() + "' and  convert(date,d.CreatedOn) <='" + searchModel.ToDate.Value.Date.ToString() + "' " + adminBasedSearchWhereClause + " order by UserName asc");

                //without date filter
                var listQuery = string.Format("select distinct s.FirstName + ' ' + s.LastName as UserName,d.RequirementId,d.EndDate, " + carerAdminId + "" + tblUserId + " as UserId,d.Id as 'DocumentId' from " + tblName + " s inner join Document d on " + tblUserId + " = s.Id " + attrFilter + " " + adminBasedSearchJoinClause + " where " + tblUserId + " is not null and s.AppStatusValId !=3 and d.RequirementId is not null and d.IsArchive='false'"
                    + adminBasedSearchWhereClause + " order by UserName asc");

                var ListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                requirementListViewModel = await MapRequirementListViewModels(ListData);
                List<RequirementsViewModel> Requirementlist = new List<RequirementsViewModel>();
                var mainlist = requirementListViewModel
                    // .GroupBy(x => new { x.UserName, x.ServiceUserId }) // old 
                    .GroupBy(x => new
                    {
                        x.UserName,
                        x.UserId
                    }) // salman 25/7
                   .Select(y => new RequirementReportListViewModel()
                   {
                       UserName = y.Key.UserName,
                       UserId = y.Key.UserId, // salman 25/7
                       // ServiceUserId = y.Key.ServiceUserId // old
                   });

                var mainObj = new List<RequirementReportListViewModel>();
                foreach (var subrow in mainlist)
                {
                    List<RequirementsViewModel> obj = new List<RequirementsViewModel>();
                    //foreach (var item in requirementListViewModel.Where(x => x.ServiceUserId == subrow.ServiceUserId)) // old
                    foreach (var item in requirementListViewModel.Where(x => x.UserId == subrow.UserId))
                    {
                        RequirementsViewModel objReq = new RequirementsViewModel();
                        var document = await _unitOfWork.DocumentRepository.GetFirstOrDefaultAsync(x => x.Id == item.DocumentId);
                        var expiryDate = document.EndDate;

                        if (expiryDate != null)
                        {
                            objReq.ExpiryDate = expiryDate;
                            var dateDiff = (expiryDate.Value.Date - DateTime.Now.Date).TotalDays;
                            if (dateDiff > 7 && expiryDate > DateTime.Now)
                                objReq.DocumentType = "Green";
                            else if ((dateDiff < 7 || dateDiff == 7) && expiryDate > DateTime.Now)
                                objReq.DocumentType = "Yellow";
                            else
                                objReq.DocumentType = "Red";
                        }
                        else
                        {
                            objReq.DocumentType = "Green";
                        }
                        objReq.DocumentId = item.DocumentId;
                        objReq.RequirementId = item.RequirementId;

                        obj.Add(objReq);
                    }
                    //subrow.Requirements = obj; // old
                    subrow.Requirements = obj.OrderBy(x => x.ExpiryDate).ToList(); // new salman 27/7
                    mainObj.Add(subrow);
                }
                return mainObj;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private async Task<List<RequirementReportListViewModel>> MapRequirementListViewModels(DataTable List)
        {
            List<RequirementReportListViewModel> requirementViewModels = new List<RequirementReportListViewModel>();
            foreach (DataRow row in List.Rows)
            {
                RequirementReportListView item = row.GetItem<RequirementReportListView>();
                requirementViewModels.Add(await MapRequirementListView(item));
            }
            return requirementViewModels;
        }
        private async Task<RequirementReportListViewModel> MapRequirementListView(RequirementReportListView User)
        {
            var requirementListViewModel = new RequirementReportListViewModel()
            {
                RequirementId = User.RequirementId,
                // ServiceUserId = User.ServiceUserId, // old
                DocumentId = User.DocumentId,
                UserName = User.UserName,
                ExpiryDate = User.EndDate,
                UserId = User.UserId, // salman 25/7
            };

            return requirementListViewModel;
        }
        public async Task<List<DocumentDescriptionListView>> GetAllDocumentDescriptionByUserRequirementReport(int ReqId,
           Guid UserId, DateTime? dateFrom, DateTime? dateTo, bool IsCarer)
        {

            var docuementDescription = new List<DocumentDescriptionListView>();
            //var document = await _unitOfWork.DocumentRepository.FindAllAsync(x => x.RequirementId == ReqId
            //&& x.IsArchive == false && IsCarer == true ? x.CarerId == UserId : x.ServiceUserId == UserId && x.RequirementId != null
            //&& x.CreatedOn >= dateFrom.Value.Date && x.CreatedOn <= dateTo.Value.Date);
            //IsCarer == true ? x.CarerId == UserId : x.ServiceUserId == UserId

            //with date filter
            //   var document = await _unitOfWork.DocumentRepository.FindAllAsync(x => x.RequirementId == ReqId
            //  && x.IsArchive == false && ((IsCarer && x.CarerId == UserId) ||
            //(!IsCarer && x.ServiceUserId == UserId)) && x.RequirementId != null
            //  && x.CreatedOn >= dateFrom && x.CreatedOn <= dateTo.Value.AddDays(1));

            //without date filter
            var document = await _unitOfWork.DocumentRepository.FindAllAsync(x => x.RequirementId == ReqId
              && x.IsArchive == false && ((IsCarer && x.CarerId == UserId) ||
            (!IsCarer && x.ServiceUserId == UserId)) && x.RequirementId != null);
            foreach (var i in document)
            {
                var obj = new DocumentDescriptionListView();
                obj.DocumentId = i.Id;
                obj.UserId = IsCarer == true ? i.CarerId : i.ServiceUserId;
                obj.Title = i.Title;
                obj.IsResolved = i.IsResolved;
                obj.ExpiryDate = i.EndDate;
                if (i.EndDate != null)
                {
                    var dateDiff = (i.EndDate.Value.Date - DateTime.Now.Date).TotalDays;
                    if (dateDiff > 7 && i.EndDate > DateTime.Now)
                        obj.DocumentType = "Green";
                    else if ((dateDiff < 7 || dateDiff == 7) && i.EndDate > DateTime.Now)
                        obj.DocumentType = "#f6bd60";
                    else
                        obj.DocumentType = "Red";
                }
                else
                {
                    obj.DocumentType = "Green";
                }
                docuementDescription.Add(obj);
            }
            return docuementDescription.OrderBy(x => x.ExpiryDate).ToList();
        }
        //private List<DocumentDescriptionListView> MapDocumentToDocumentDescriptionListView(List<Document> input)
        //{
        //    var docuementDate = new List<DocumentDescriptionListView>();
        //    foreach (var i in input)
        //    {
        //        var obj = new DocumentDescriptionListView();
        //        obj.DocumentId = i.Id;
        //        obj.ServiceUserId = i.ServiceUserId;
        //        obj.Title = i.Title;
        //        obj.IsResolved = i.IsResolved;
        //        docuementDate.Add(obj);
        //    }
        //    return docuementDate;
        //}
        public async Task<bool> CheckActiveDeactiveUser(Guid userId, bool IsCarer)
        {
            Boolean isActive = false;
            var type = string.Empty;
            if (!IsCarer)
            {
                var result = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == userId);
                type = result.AppStatusVal.Name;
            }
            else
            {
                var result = await _unitOfWork.UserRepository.GetFirstOrDefaultAsync(x => x.Id == userId);
                type = result.AppStatusVal.Name;
            }
            if (type == Common.Constants.Statuses.Deleted)
            {
                isActive = true;
            }
            return isActive;
        }

        public async Task<Stream> DownloadRequirementReportResultsInExcel(ReportSearchModel searchModel)
        {
            XLWorkbook workbook = null;
            MemoryStream memoryStream = null;

            try
            {
                // before this function was only working for PWS, now it will work for SLC also 25/7
                // salman 
                // variables
                var queryTblName = "";
                var queryTblUserId = "";
                var queryIdUserId = "";
                int userTypeId = 0;
                string dataRowColName = "";
                //
                // var userType = 2;
                //var IsCarer = searchModel.IsCarer;
                var IsCarer = searchModel.IsCarer;

                if (IsCarer == 1)
                {
                    queryTblName = "[User]";
                    queryIdUserId = "CarerId";
                    userTypeId = 1;
                    dataRowColName = "SLC Name";
                }
                else
                {
                    queryTblName = "ServiceUser";
                    queryIdUserId = "ServiceUserId";
                    userTypeId = 2;
                    dataRowColName = "PWS Name";
                }
                // end salman
                // 8/8 making data team based 
                var isSuperAdmin = searchModel.IsSuperAdmin;
                var searchedAdminId = searchModel.UserId;
                var carerAdminId = "";
                var adminBasedSearchJoinClause = "";
                var adminBasedSearchWhereClause = "";
                if ((isSuperAdmin == 1 && searchedAdminId != "0") || (isSuperAdmin == 0 && searchedAdminId != "0"))
                {


                    if (IsCarer == 1)
                    {
                        // for carer we are using such logic because carer data is present in two tables one is Carer and other is User
                        carerAdminId += "ca.AdministratorId,";
                        adminBasedSearchJoinClause += " inner join Carer ca ON ca.Id = c.Id ";
                        adminBasedSearchWhereClause += " and ca.AdministratorId = '" + searchedAdminId + "'";
                    }
                    else
                    {
                        carerAdminId += "c.AdministratorId,";
                        adminBasedSearchWhereClause = " and c.AdministratorId = '" + searchedAdminId + "' ";
                    }
                }
                // end 

                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));

                //var serviceUSerReqAll = _unitOfWork.RequirementRepository.FindAllAsync(x => x.UserTypeId == 2).Result;// old
                var serviceUSerReqAll = _unitOfWork.RequirementRepository.FindAllAsync(x => x.UserTypeId == userTypeId).Result;
                serviceUSerReqAll = serviceUSerReqAll.OrderBy(x => x.Name).ToList();
                string strServiceUSerReqListWithBrackets = "";
                flg = false;
                foreach (var j in serviceUSerReqAll)
                { 
                    if (flg == false)
                        strServiceUSerReqListWithBrackets += "[" + j.Name + "]";
                    else
                        strServiceUSerReqListWithBrackets += ",[" + j.Name + "]";
                    flg = true;
                }



                //var whereclause = " where  convert(date,doc.CreatedOn)>='" + searchModel.FromDate.Value.Date.ToString() + "' and "
                //    + " convert(date,doc.CreatedOn)<='" + searchModel.ToDate.Value.Date.ToString() + "'";

                //var whereClauseOpton = "";
                //if (AttributeOptionList.Length > 0)
                //    whereClauseOpton = " and  att.Id in(" + AttributeOptionList + ") ";
                var whereClauseAttributeOpton = "";
                //if (AttributeSearchList.Length > 0)
                //{ 
                //    attFilter = " inner join UserAttribute arr on arr.ServiceUserId=c.Id ";
                //    whereClauseAttributeOpton = " and arr.AttributeId  in(" + AttributeSearchList + ") and arr.OptionId in(" + AttributeOptionList + ")   ";
                //}
                var attributesSearch = "";
                //var attributesOptionSearch = "";


                //              string onlyAtrributeId = "";
                //              if (AttributeSearchList.Length > 0)
                //              {
                //                  int flagOption = 0, flgopertaion = 0;

                //                  foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                //                  {
                //                      //int flagOption = 0;
                //                      attributesSearch += " and UAT.AttributeId = " + item.AttributeId;
                //                      if (flgopertaion == 0)
                //                          onlyAtrributeId = item.AttributeId.ToString();
                //                      else
                //                          onlyAtrributeId = onlyAtrributeId + "," + item.AttributeId.ToString();
                //                      flgopertaion = 1;
                //                      foreach (var option in item.AttributeOptions.ToList())
                //                      {
                //                          if (flagOption == 0)
                //                              attributesOptionSearch = " and (UAT.OptionId = " + option.Id;
                //                          else
                //                              attributesOptionSearch += " or UAT.OptionId = " + option.Id;
                //                          flagOption = 1;
                //                      }
                //                  }
                //                  attrFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = s.Id and ((select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) " +
                //"from(select distinct AttributeId from UserAttribute where ServiceUserId = s.Id) t)=  '" + onlyAtrributeId + "')" + attributesOptionSearch + ")";
                //              }
                string attFilter = "";
                string onlyAtrributeOptionId = "";
                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;
                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        // attributesSearch += "and c.Id in (select distinct serviceUserId from UserAttribute where " + // old, below is added by salman 26/7
                        //   "AttributeId = " + item.AttributeId.ToString();
                        attributesSearch += "and c.Id in (select distinct " + queryIdUserId + " from UserAttribute where " +
                            "AttributeId = " + item.AttributeId.ToString();
                        flagOption = 0;
                        onlyAtrributeOptionId = "";
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        // attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and serviceUserId is not null)";
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and " + queryIdUserId + " is not null)";
                    }
                    attFilter = attributesSearch;
                }




                workbook = new XLWorkbook();
                memoryStream = new MemoryStream();
                /* old
                var listQuery = string.Format(
                    "SELECT [PWS Name], " + strServiceUSerReqListWithBrackets + " from (select distinct  c.id,  c.FirstName+' '+c.LastName as [PWS Name],r.Name as RequirementName," +
"(select  STRING_AGG(dbo.udf_StripHTML(att.NoteText,att.StartDate,att.EndDate),' ')  from Document att where att.RequirementId = doc.RequirementId and doc.ServiceUserId=att.ServiceUserId and att.IsArchive='false')  Attachements from ServiceUser c " +
"inner join Document  doc on doc.ServiceUserId=c.Id inner join Requirement r on doc.RequirementId = r.id and doc.IsArchive='false'  " + attFilter + whereclause + " and c.AppStatusValId !=3" +
"   )ps PIVOT (max(Attachements) FOR RequirementName IN(" + strServiceUSerReqListWithBrackets + ") ) AS pvt order by [PWS Name] asc");
                */
                // salman 26/7
                var listQuery = "";
                if (IsCarer != 1)
                {
                    //with date filter
                    //                    listQuery = string.Format(
                    //                    "SELECT [PWS Name], " + strServiceUSerReqListWithBrackets + " from (select distinct  c.id,  c.FirstName+' '+c.LastName as [PWS Name], " + carerAdminId + "  r.Name as RequirementName," +
                    //"(select  STRING_AGG(dbo.udf_StripHTML(att.NoteText,att.StartDate,att.EndDate),' ') WITHIN GROUP (ORDER BY att.EndDate) from Document att where att.RequirementId = doc.RequirementId and doc.ServiceUserId=att.ServiceUserId and att.IsArchive='false' and att.CreatedOn >='" + searchModel.FromDate.Value.Date.ToString() + "' and att.CreatedOn <= '" + searchModel.ToDate.Value.AddDays(1).Date.ToString() + "')  Attachements from ServiceUser c " +
                    //"inner join Document  doc on doc.ServiceUserId=c.Id inner join Requirement r on doc.RequirementId = r.id and doc.IsArchive='false'  " + attFilter + whereclause + " and c.AppStatusValId !=3 " + adminBasedSearchWhereClause + "" +
                    //"   )ps PIVOT (max(Attachements) FOR RequirementName IN(" + strServiceUSerReqListWithBrackets + ") ) AS pvt order by [PWS Name] asc");
                    listQuery = string.Format(
                        "SELECT [PWS Name], " + strServiceUSerReqListWithBrackets + " from (select distinct  c.id,  c.FirstName+' '+c.LastName as [PWS Name], " + carerAdminId + "  r.Name as RequirementName," +
    "(select  STRING_AGG(dbo.udf_StripHTML(att.NoteText,att.StartDate,att.EndDate),' ') WITHIN GROUP (ORDER BY att.EndDate) from Document att where att.RequirementId = doc.RequirementId and doc.ServiceUserId=att.ServiceUserId and att.IsArchive='false')  Attachements from ServiceUser c " +
    "inner join Document  doc on doc.ServiceUserId=c.Id inner join Requirement r on doc.RequirementId = r.id and doc.IsArchive='false'  " + attFilter + " where c.AppStatusValId !=3 " + adminBasedSearchWhereClause + "" +
    "   )ps PIVOT (max(Attachements) FOR RequirementName IN(" + strServiceUSerReqListWithBrackets + ") ) AS pvt order by [PWS Name] asc");
                }
                else
                {
                    // 27/7 to fix the Order in the Excel sheet with respect to expiry date, we have added only this statement "WITHIN GROUP (ORDER BY EndDate)" in the "select  STRING_AGG" query line
                    /* before applying admin filteration 
                     * listQuery = string.Format(
                     "SELECT [SLC Name], " + strServiceUSerReqListWithBrackets + " from (select distinct  c.id,  c.FirstName+' '+c.LastName as [SLC Name],r.Name as RequirementName," +
 "(select  STRING_AGG(dbo.udf_StripHTML(att.NoteText,att.StartDate,att.EndDate),' ') WITHIN GROUP (ORDER BY att.EndDate)  from Document att where att.RequirementId = doc.RequirementId and doc.CarerId=att.CarerId and att.IsArchive='false' and att.CreatedOn >='" + searchModel.FromDate.Value.Date.ToString() + "' and att.CreatedOn <= '" + searchModel.ToDate.Value.AddDays(1).Date.ToString() + "')  Attachements from [User] c " +
 "inner join Document  doc on doc.CarerId=c.Id inner join Requirement r on doc.RequirementId = r.id and doc.IsArchive='false'  " + attFilter + whereclause + " and c.AppStatusValId !=3" +
 "   )ps PIVOT (max(Attachements) FOR RequirementName IN(" + strServiceUSerReqListWithBrackets + ") ) AS pvt order by [SLC Name] asc");
                 }
                    */
                    //with date filter
                    //                    listQuery = string.Format(
                    //                    "SELECT [SLC Name], " + strServiceUSerReqListWithBrackets + " from (select distinct  c.id,  c.FirstName+' '+c.LastName as [SLC Name], " + carerAdminId + "r.Name as RequirementName," +
                    //"(select  STRING_AGG(dbo.udf_StripHTML(att.NoteText,att.StartDate,att.EndDate),' ') WITHIN GROUP (ORDER BY att.EndDate)  from Document att where att.RequirementId = doc.RequirementId and doc.CarerId=att.CarerId and att.IsArchive='false' and att.CreatedOn >='" + searchModel.FromDate.Value.Date.ToString() + "' and att.CreatedOn <= '" + searchModel.ToDate.Value.AddDays(1).Date.ToString() + "')  Attachements from [User] c " +
                    //"inner join Document  doc on doc.CarerId=c.Id inner join Requirement r on doc.RequirementId = r.id and doc.IsArchive='false'  " + attFilter + adminBasedSearchJoinClause + whereclause + " and c.AppStatusValId !=3 " + adminBasedSearchWhereClause + "" +
                    //"   )ps PIVOT (max(Attachements) FOR RequirementName IN(" + strServiceUSerReqListWithBrackets + ") ) AS pvt order by [SLC Name] asc");
                    listQuery = string.Format(
                                        "SELECT [SLC Name], " + strServiceUSerReqListWithBrackets + " from (select distinct  c.id,  c.FirstName+' '+c.LastName as [SLC Name], " + carerAdminId + "r.Name as RequirementName," +
                    "(select  STRING_AGG(dbo.udf_StripHTML(att.NoteText,att.StartDate,att.EndDate),' ') WITHIN GROUP (ORDER BY att.EndDate)  from Document att where att.RequirementId = doc.RequirementId and doc.CarerId=att.CarerId and att.IsArchive='false')  Attachements from [User] c " +
                    "inner join Document  doc on doc.CarerId=c.Id inner join Requirement r on doc.RequirementId = r.id and doc.IsArchive='false'  " + attFilter + adminBasedSearchJoinClause + " where c.AppStatusValId !=3 " + adminBasedSearchWhereClause + "" +
                    "   )ps PIVOT (max(Attachements) FOR RequirementName IN(" + strServiceUSerReqListWithBrackets + ") ) AS pvt order by [SLC Name] asc");
                }
                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                if (exportedResults != null)
                {
                    foreach (DataRow row in exportedResults.Rows)
                    {
                        string values = string.Empty;
                        foreach (DataColumn col in exportedResults.Columns)
                        {

                            if (col.ColumnName != dataRowColName) // salman added a variable dataRowColName, before it was static [PWS Name]
                            {
                                values = row[col.ColumnName].ToString();
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                {
                                    values = values.Replace("<br/>", Environment.NewLine);
                                    row[col.ColumnName] = values;
                                }

                            }

                            else
                            {
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                    values = values + "," + row[col.ColumnName].ToString();
                            }

                        }
                    }

                }
                workbook.Worksheets.Add(exportedResults, "Report Results");
                workbook.SaveAs(memoryStream);

                return memoryStream;

            }
            catch
            {
                if (memoryStream != null)
                    memoryStream.Dispose();

                memoryStream = null;


                throw;
            }

            finally
            {
                if (workbook != null)
                    workbook.Dispose();

                workbook = null;
            }
        }

        public async Task<List<DocumentDescriptionListView>> GetAllDocumentDescriptionByUser(int CatId,
            Guid serviceUserId, string incidentSeverties, DateTime dateFrom, DateTime dateTo)
        {

            var docuementDate = new List<DocumentDescriptionListView>();


            var arrangenet = await _unitOfWork.ArrangementRepository.GetFilteredResult(x => x.ServiceUserId == serviceUserId);
            foreach (var item in arrangenet)
            {
                var document = await _unitOfWork.DocumentRepository.FindAllAsync(x => x.IncidentCategoryId == CatId
               && x.ArrangementId == item.Id && x.ParentId == null && x.NoteTypeId == 2 && x.IsArchive == false
               && (x.UpdatedOn == null ? x.CreatedOn : x.UpdatedOn) >= dateFrom
               && (x.UpdatedOn == null ? x.CreatedOn : x.UpdatedOn) < dateTo.AddDays(1));
                foreach (var i in document)
                {
                    if (incidentSeverties != "null" && incidentSeverties != "")
                    {
                        var commaSeperatedList = incidentSeverties.Split(',');
                        var resultServerity = commaSeperatedList.Where(x => x == i.IncidentSeverityId.ToString());
                        if (resultServerity.Count() == 0)
                        {
                            continue;
                        }
                    }
                    var obj = new DocumentDescriptionListView();
                    obj.DocumentId = i.Id;
                    obj.ServiceUserId = item.ServiceUserId;
                    obj.Title = i.Title;
                    obj.IsResolved = i.IsResolved;
                    docuementDate.Add(obj);
                }
            }
            return docuementDate.OrderBy(x => x.Title).ToList();
        }
        //private List<DocumentDescriptionListView> MapDocumentToDocumentDescriptionListView(List<Document> input)
        //{
        //    var docuementDate = new List<DocumentDescriptionListView>();
        //    foreach (var i in input)
        //    {
        //        var obj = new DocumentDescriptionListView();
        //        obj.DocumentId = i.Id;
        //        obj.ServiceUserId = i.ServiceUserId;
        //        obj.Title = i.Title;
        //        obj.IsResolved = i.IsResolved;
        //        docuementDate.Add(obj);
        //    }
        //    return docuementDate;
        //}
        public async Task<bool> CheckActiveDeactiveUser(Guid userId)
        {
            Boolean isActive = false;

            var result = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == userId);
            var type = result.AppStatusVal.Name;
            if (type == Common.Constants.Statuses.Deleted)
            {
                isActive = true;
            }
            return isActive;

        }

        public async Task<IList<IncidentReportListViewModel>> GetIncidentReportList(IncidentReportSearchModel searchModel)
        {
            try
            {
                //Attributes filter
                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));


                List<IncidentReportListViewModel> incidentListViewModel = new List<IncidentReportListViewModel>();

                //attribute filter
                string attrFilter = "";
                //if (AttributeSearchList.Length > 0)
                //{
                //    attrFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = s.Id and UAT.AttributeId in(" + AttributeSearchList + ") and UAT.OptionId in(" + AttributeOptionList + ")";
                //}
                var attributesSearch = "";
                //var attributesOptionSearch = "";

                // string onlyAtrributeId = "";
                //              if (AttributeSearchList.Length > 0)
                //              {
                //                  int flagOption = 0, flgopertaion = 0;

                //                  foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                //                  {
                //                      //int flagOption = 0;
                //                      attributesSearch += " and UAT.AttributeId = " + item.AttributeId;
                //                      if (flgopertaion == 0)
                //                          onlyAtrributeId = item.AttributeId.ToString();
                //                      else
                //                          onlyAtrributeId = onlyAtrributeId + "," + item.AttributeId.ToString();
                //                      flgopertaion = 1;
                //                      foreach (var option in item.AttributeOptions.ToList())
                //                      {
                //                          if (flagOption == 0)
                //                              attributesOptionSearch = " and (UAT.OptionId = " + option.Id;
                //                          else
                //                              attributesOptionSearch += " or UAT.OptionId = " + option.Id;
                //                          flagOption = 1;
                //                      }
                //                  }
                //                  attrFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = s.Id and ((select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) " +
                //"from(select distinct AttributeId from UserAttribute where ServiceUserId = s.Id) t)=  '" + onlyAtrributeId + "')" + attributesOptionSearch + ")";
                //              }

                string onlyAtrributeOptionId = "";
                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;

                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        attributesSearch += "and s.Id in (select distinct serviceUserId from UserAttribute where " +
                            "AttributeId = " + item.AttributeId.ToString();
                        onlyAtrributeOptionId = "";
                        flagOption = 0;
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and serviceUserId is not null)";
                    }
                    attrFilter = attributesSearch;
                }


                //incident category filter

                string incidentCategoryFilter = "";
                if (searchModel.IncidentCateogries != null && searchModel.IncidentCateogries != "")
                {
                    incidentCategoryFilter = "  and d.IncidentCategoryId in(" + searchModel.IncidentCateogries + ") ";
                }
                //incident severity filter
                string incidentSeverityFilter = "";
                if (searchModel.IncidentServerties != null && searchModel.IncidentServerties != "")
                {
                    incidentSeverityFilter = "  and d.IncidentSeverityId in(" + searchModel.IncidentServerties + ") ";
                }
                var listQuery = string.Format("select  s.FirstName + ' ' + s.LastName as UserName,d.IncidentCategoryId as 'CategoryId',arrange.ServiceUserId,d.IsResolved,d.Id as 'DocumentId' from ServiceUser s inner join Arrangement arrange on arrange.ServiceUserId = s.Id inner join Document d on d.ArrangementId = arrange.Id " + attrFilter + incidentCategoryFilter + incidentSeverityFilter + " where d.IncidentCategoryId is not null and s.AppStatusValId !=3 and d.IsArchive='false' and d.NoteTypeId=2" +
                    " and isnull(d.UpdatedOn, d.CreatedOn) >='" + searchModel.FromDate.Value.Date.ToString(Common.Constants.sqlFullDateTime) + "' and  isnull(d.UpdatedOn, d.CreatedOn) <'" + searchModel.ToDate.Value.Date.AddDays(1).ToString(Common.Constants.sqlFullDateTime) + "' and d.ParentId is null order by UserName asc");


                var ListData = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                incidentListViewModel = await MapIncidentListViewModels(ListData);
                var mainlist = incidentListViewModel
                   .GroupBy(x => new { x.UserName, x.ServiceUserId })
                   .Select(y => new IncidentReportListViewModel()
                   {
                       UserName = y.Key.UserName,
                       ServiceUserId = y.Key.ServiceUserId
                   });

                var mainObj = new List<IncidentReportListViewModel>();
                foreach (var subrow in mainlist)
                {
                    List<IncidentViewModel> obj = new List<IncidentViewModel>();
                    foreach (var item in incidentListViewModel.Where(x => x.ServiceUserId == subrow.ServiceUserId))
                    {
                        IncidentViewModel objIncident = new IncidentViewModel();
                        Expression<Func<Document, bool>> filter = x => x.ServiceUserId == item.ServiceUserId
                          && x.IncidentCategoryId == item.CategoryId && x.NoteTypeId == 2;

                        if (!string.IsNullOrWhiteSpace(searchModel.IncidentServerties))
                        {
                            var incidentSeverityIds = searchModel.IncidentServerties.Trim().Split(',').Select(int.Parse).ToList();

                            filter = filter.And(p => p.IncidentSeverityId != null && incidentSeverityIds.Contains(p.IncidentSeverityId.Value));
                        }

                        var document = await _unitOfWork.DocumentRepository.GetFilteredResult(filter);




                        var isResolved = true;

                        isResolved = document.FirstOrDefault(x => x.IsResolved == false && x.ParentId == null && x.IsArchive == false
                         && (x.UpdatedOn == null ? x.CreatedOn : x.UpdatedOn) >= searchModel.FromDate.Value.Date
                         && (x.UpdatedOn == null ? x.CreatedOn : x.UpdatedOn) < searchModel.ToDate.Value.Date.AddDays(1)) == null;

                        if (isResolved)
                        {
                            objIncident.DocumentType = "Green";
                        }
                        else
                        {
                            objIncident.DocumentType = "Red";
                        }
                        objIncident.DocumentId = item.DocumentId;
                        objIncident.CategoryId = item.CategoryId;
                        objIncident.IsResolved = item.IsResolved;
                        obj.Add(objIncident);
                    }
                    subrow.Incidents = obj;
                    mainObj.Add(subrow);
                }
                return mainObj;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private async Task<List<IncidentReportListViewModel>> MapIncidentListViewModels(DataTable List)
        {
            List<IncidentReportListViewModel> incidentViewModels = new List<IncidentReportListViewModel>();
            foreach (DataRow row in List.Rows)
            {
                IncidentReportListView item = row.GetItem<IncidentReportListView>();
                incidentViewModels.Add(await MapIncidentListView(item));
            }
            return incidentViewModels;
        }
        private async Task<IncidentReportListViewModel> MapIncidentListView(IncidentReportListView User)
        {
            var incidentListViewModel = new IncidentReportListViewModel()
            {
                CategoryId = User.CategoryId,
                ServiceUserId = User.ServiceUserId,
                DocumentId = User.DocumentId,
                UserName = User.UserName,
                IsResolved = User.IsResolved
            };

            return incidentListViewModel;
        }

        public async Task<Stream> DownloadIncidentReportResultsInExcel(IncidentReportSearchModel searchModel)
        {
            XLWorkbook workbook = null;
            MemoryStream memoryStream = null;

            try
            {
                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
                //foreach (var i in searchModel.UserAttributes.ToList())
                //{
                //    foreach (var j in i.AttributeOptions.ToList())
                //    {
                //        if (flg == false)
                //            AttributeOptionList += j.Id.ToString();
                //        else
                //            AttributeOptionList += "," + j.Id.ToString();
                //        flg = true;
                //    }
                //}
                var serviceUSerReqAll = _unitOfWork.IncidentCategoryRepository.FindAllAsync(x => x.IsIncident == true).Result;
                serviceUSerReqAll = serviceUSerReqAll.OrderBy(x => x.CategoryName).ToList();
                string strServiceUSerIncidentListWithBrackets = "";
                flg = false;
                foreach (var j in serviceUSerReqAll)
                {
                    if (flg == false)
                        strServiceUSerIncidentListWithBrackets += "[" + j.CategoryName + "]";
                    else
                        strServiceUSerIncidentListWithBrackets += ",[" + j.CategoryName + "]";
                    flg = true;
                }
                string attFilter = "";
                string incidentCategoryFilter = "";
                string incidentSeverityFilter = "";


                var whereclause = " where isnull(arr.UpdatedOn, arr.CreatedOn) >='" + searchModel.FromDate.Value.Date.ToString(Common.Constants.sqlFullDateTime) + "' and  isnull(arr.UpdatedOn, arr.CreatedOn) <'" + searchModel.ToDate.Value.Date.AddDays(1).ToString(Common.Constants.sqlFullDateTime) + "'";

                var whereClauseOpton = "";
                if (AttributeOptionList.Length > 0)
                    whereClauseOpton = " and  att.Id in(" + AttributeOptionList + ") ";


                var attributesSearch = "";
                // var attributesOptionSearch = "";
                //string onlyAtrributeId = "";
                //              if (AttributeSearchList.Length > 0)
                //              {
                //                  int flagOption = 0, flgopertaion = 0;

                //                  foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                //                  {
                //                      //int flagOption = 0;
                //                      attributesSearch += " and UAT.AttributeId = " + item.AttributeId;
                //                      if (flgopertaion == 0)
                //                          onlyAtrributeId = item.AttributeId.ToString();
                //                      else
                //                          onlyAtrributeId = onlyAtrributeId + "," + item.AttributeId.ToString();
                //                      flgopertaion = 1;
                //                      foreach (var option in item.AttributeOptions.ToList())
                //                      {
                //                          if (flagOption == 0)
                //                              attributesOptionSearch = " and (UAT.OptionId = " + option.Id;
                //                          else
                //                              attributesOptionSearch += " or UAT.OptionId = " + option.Id;
                //                          flagOption = 1;
                //                      }
                //                  }
                //                  attFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = c.Id and ((select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) " +
                //"from(select distinct AttributeId from UserAttribute where ServiceUserId = c.Id) t)=  '" + onlyAtrributeId + "')" + attributesOptionSearch + ")";
                //              }

                string onlyAtrributeOptionId = "";
                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;

                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        attributesSearch += "and c.Id in (select distinct serviceUserId from UserAttribute where " +
                            "AttributeId = " + item.AttributeId.ToString();

                        flagOption = 0;
                        onlyAtrributeOptionId = "";
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and serviceUserId is not null)";
                    }
                    attFilter = attributesSearch;
                }

                //incident category filter
                string whereClauseCategory = "";
                if (searchModel.IncidentCateogries != null && searchModel.IncidentCateogries != "")
                {
                    //incidentCategoryFilter = " inner join IncidentCategory cat on cat.Id=att.IncidentCategoryId ";
                    whereClauseCategory = "  and arr.IncidentCategoryId in(" + searchModel.IncidentCateogries + ") ";
                }
                //incident severity filter
                string whereClauseSeverity = "";
                if (searchModel.IncidentServerties != null && searchModel.IncidentServerties != "")
                {
                    incidentCategoryFilter = " inner join IncidentSeverity cat on cat.Id=att.IncidentSeverityId ";
                    whereClauseSeverity = "  and arr.IncidentSeverityId in(" + searchModel.IncidentServerties + ") ";
                }
                workbook = new XLWorkbook();
                memoryStream = new MemoryStream();

                var listQuery = string.Format(
                    "SELECT [PWS Name], " + strServiceUSerIncidentListWithBrackets + " from (select distinct    c.Id,c.FirstName+' '+c.LastName as [PWS Name],cat.CategoryName," +
"(select STRING_AGG(att.Title,',') WITHIN GROUP (ORDER BY att.Title)  " +
"from Document att where att.ArrangementId=arr.ArrangementId and att.IncidentCategoryId = arr.IncidentCategoryId   " +
"   and isnull(att.UpdatedOn, att.CreatedOn) >='" + searchModel.FromDate.Value.Date.ToString(Common.Constants.sqlFullDateTime) + "' and  isnull(att.UpdatedOn, att.CreatedOn) <'" + searchModel.ToDate.Value.Date.AddDays(1).ToString(Common.Constants.sqlFullDateTime) + "'" +
                (!string.IsNullOrWhiteSpace(searchModel.IncidentServerties) ? " and att.IncidentSeverityId in (" + searchModel.IncidentServerties + ")" : string.Empty) + " and att.IsArchive = 'false' " +
"  )  Incidents  from Arrangement arrangement inner join  Document arr on arr.ArrangementId = arrangement.Id inner join ServiceUser c on arrangement.ServiceUserId = c.Id and arr.IncidentCategoryId > 0 and arr.NoteTypeId = 2 and arr.ParentId is null and arr.IsArchive='false' inner join IncidentCategory cat on cat.Id = arr.IncidentCategoryId  " + attFilter + incidentSeverityFilter + whereclause + whereClauseCategory + whereClauseSeverity + " and c.AppStatusValId !=3" +
"   )ps PIVOT (max(Incidents) FOR CategoryName IN(" + strServiceUSerIncidentListWithBrackets + ") ) AS pvt order by [PWS Name] asc");


                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                if (exportedResults != null)
                {
                    foreach (DataRow row in exportedResults.Rows)
                    {
                        string values = string.Empty;
                        foreach (DataColumn col in exportedResults.Columns)
                        {

                            if (col.ColumnName != "PWS Name")
                            {
                                values = row[col.ColumnName].ToString();
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                {
                                    values = values.Replace("<br/>", Environment.NewLine);
                                    row[col.ColumnName] = values;
                                }
                            }

                            else
                            {
                                if (values == string.Empty)
                                    values = row[col.ColumnName].ToString();
                                else
                                    values = values + "," + row[col.ColumnName].ToString();
                            }

                        }
                    }

                }
                workbook.Worksheets.Add(exportedResults, "Report Results");
                workbook.SaveAs(memoryStream);

                return memoryStream;

            }
            catch
            {
                if (memoryStream != null)
                    memoryStream.Dispose();

                memoryStream = null;


                throw;
            }

            finally
            {
                if (workbook != null)
                    workbook.Dispose();

                workbook = null;
            }
        }


        #region Finance Report
        //Made it Ilist to list
        public async Task<List<CarerFeeStructureViewModels>> GetFinanceReportList(FinanceReportSearchModel searchModel, Guid? UserId)
        {
            try
            {
                //Attributes filter
                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
                //foreach (var i in searchModel.UserAttributes.ToList())
                //{
                //    foreach (var j in i.AttributeOptions.ToList())
                //    {
                //        if (flg == false)
                //            AttributeOptionList += j.Id.ToString();
                //        else
                //            AttributeOptionList += "," + j.Id.ToString();
                //        flg = true;
                //    }
                //}

                List<CarerFeeStructureViewModels> financeListViewModel = new List<CarerFeeStructureViewModels>();
                string[] financePeriodIds = searchModel.FinancePeriodIds.Split(',');
                //attribute filter
                string attrFilter = "";
                string attrFutureFilter = ""; // salman 20/9
                //if (AttributeSearchList.Length > 0)
                //{
                //    attrFilter = " inner join UserAttribute UAT on UAT.CarerId = s.CarerId and UAT.AttributeId in(" + AttributeSearchList + ") and UAT.OptionId in(" + AttributeOptionList + ")";
                //}
                var attributesSearch = "";
                var attributesFutureSearch = ""; // salman 20/9
                var attributesOptionSearch = "";
                //if (AttributeSearchList.Length > 0)
                //{
                //    foreach (var item in searchModel.UserAttributes.ToList())
                //    {
                //        int flagOption = 0;
                //        attributesSearch += " and UAT.AttributeId = " + item.AttributeId;
                //        foreach (var option in item.AttributeOptions.ToList())
                //        {
                //            if (flagOption == 0)
                //                attributesOptionSearch = " and UAT.OptionId = " + option.Id;
                //            else
                //                attributesOptionSearch += " and UAT.OptionId = " + option.Id;
                //            flagOption = 1;
                //        }
                //    }
                //    if (searchModel.IsCarerAttribute)
                //        attrFilter = " inner join UserAttribute UAT on UAT.CarerId = s.CarerId " + attributesSearch + attributesOptionSearch + "";
                //    else
                //        attrFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = s.ServiceUserId " + attributesSearch + attributesOptionSearch + "";
                //}

                string onlyAtrributeId = "";
                //                if (AttributeSearchList.Length > 0)
                //                {
                //                    int flagOption = 0, flgopertaion = 0;

                //                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                //                    {
                //                        //int flagOption = 0;
                //                        attributesSearch += " and UAT.AttributeId = " + item.AttributeId;
                //                        if (flgopertaion == 0)
                //                            onlyAtrributeId = item.AttributeId.ToString();
                //                        else
                //                            onlyAtrributeId = onlyAtrributeId + "," + item.AttributeId.ToString();
                //                        flgopertaion = 1;
                //                        foreach (var option in item.AttributeOptions.ToList())
                //                        {
                //                            if (flagOption == 0)
                //                                attributesOptionSearch = " and (UAT.OptionId = " + option.Id;
                //                            else
                //                                attributesOptionSearch += " or UAT.OptionId = " + option.Id;
                //                            flagOption = 1;
                //                        }
                //                    }
                //                    if (searchModel.IsCarerAttribute)
                //                        attrFilter = " inner join UserAttribute UAT on UAT.CarerId = s.CarerId and ((select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) " +
                // "from(select distinct AttributeId from UserAttribute where CarerId = s.CarerId) t)=  '" + onlyAtrributeId + "')" + attributesOptionSearch + ")";
                //                    else
                //                    attrFilter = " inner join UserAttribute UAT on UAT.ServiceUserId = s.ServiceUserId  and ((select STRING_AGG(AttributeId,',') WITHIN GROUP (ORDER BY AttributeId) " +
                //"from(select distinct AttributeId from UserAttribute where ServiceUserId = s.ServiceUserId) t)=  '" + onlyAtrributeId + "')" + attributesOptionSearch + ")";                                     
                //                }
                string onlyAtrributeOptionId = "";
                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;
                    string type = "";
                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        if (searchModel.IsCarerAttribute)
                        {
                            type = "CarerId";
                        }
                        else
                        {
                            type = "serviceUserId";
                        }
                        attributesSearch += "and s." + type + " in (select distinct " + type + " from UserAttribute where " +
                        "AttributeId = " + item.AttributeId.ToString();
                        attributesFutureSearch += " and " + type + " in (select distinct " + type + " from UserAttribute where " +
                        "AttributeId = " + item.AttributeId.ToString(); // salman 20/9
                        onlyAtrributeOptionId = "";
                        flagOption = 0;
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and " + type + " is not null)";
                        attributesFutureSearch = attributesFutureSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and " + type + " is not null)";
                    }
                    attrFilter = attributesSearch;
                    attrFutureFilter = attributesFutureSearch;
                }

                string whereClause = " where ";
                string PeriodDuration = "(";
                string condition = "";
                string futurePeriodDuration = ""; // salman 17/9
                string futureWhereClasue = " where"; // salman 17/9
                string futureCondition = ""; // salman 17/9
                List<FinancePeriod> financePeriodsData = new List<FinancePeriod>(); // salman 13/9
                foreach (var item in financePeriodIds)
                {
                    int feePeriodId = Convert.ToInt32(item);
                    var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == feePeriodId);
                    PeriodDuration += condition + "(convert(date,s.Tdate)>='" + financePeriod.StartDate + "' and convert(date,s.Tdate)<='" + financePeriod.EndDate + "')";
                    condition = " or ";
                    financePeriodsData.Add(financePeriod); // salman 13/9

                    // salman
                    if (financePeriod.StartDate.Month > DateTime.Now.Month || financePeriod.StartDate.Year >= DateTime.Now.Year)
                    {  /* old before 2031
                        futurePeriodDuration += futurePeriodDuration + "(convert(date,startdate) >='" + financePeriod.StartDate + "' and convert (date, enddate) <= '" + financePeriod.EndDate + "')"
                        + " or (convert(date,startdate) >='" + financePeriod.StartDate + "' and enddate is Null)"
                        + " or (convert(date,startdate) <'" + financePeriod.StartDate + "' and (convert (date, enddate) <= '" + financePeriod.EndDate + "' or enddate is null))";
                    `*/
                        futurePeriodDuration += futureCondition + "(convert(date,startdate) >='" + financePeriod.StartDate + "' and convert (date, enddate) <= '" + financePeriod.EndDate + "')"
                        + " or ((convert(date,startdate) >='" + financePeriod.StartDate + "' and convert(date,startdate) <= '" + financePeriod.EndDate +"' ) and enddate is Null)"
                        + " or (convert(date,startdate) <'" + financePeriod.StartDate + "' and (convert (date, enddate) >= '" + financePeriod.EndDate + "' or enddate is null)"
                        + " or (convert(date,startdate) <='" + financePeriod.EndDate + "' and ((convert (date, enddate) >= '" + financePeriod.EndDate + "' or convert (date,enddate) = '" + financePeriod.StartDate +"' ) and enddate is not null)))";
                        futureCondition = " or ";
                    }

                    // end salman
                }
                PeriodDuration += ")";
                string whereForWeeklyLocalAuthorityCharge = "";
                string whereForWeeklyLocalAuthorityChargeFuture = ""; // salman 18/9
                if (searchModel.IsCarer == false)
                {
                    whereForWeeklyLocalAuthorityCharge = " and (s.Weekly='1' or s.Daily='1')  and s.IsAdditionFee is null ";
                    whereForWeeklyLocalAuthorityChargeFuture = " and (Weekly='1' or Daily='1')";
                }
                if (PeriodDuration.Length > 0)
                    whereClause += PeriodDuration;
                else
                    whereClause = "";
                // added by salman 
                // salman 17/9
                if (futurePeriodDuration.Length > 0)
                    futureWhereClasue += futurePeriodDuration;
                else
                    futureWhereClasue = "";
                // end salman
                // there are some records in which serviceUserid is missing so we need to exclude that from the listquery
                string excludeRecordsWithoutServiceUserId = "";
                if(whereClause != "")
                {
                    excludeRecordsWithoutServiceUserId += " and s.ServiceUserId is not null ";
                }
                //without serviceuserid
                //var listQuery = string.Format("select distinct s.CarerId,s.IsMonthClose,c.FirstName + ' ' + c.LastName as CarerName,s.Description,s.IsDeduction,s.Amount,s.LocalAuthorityCharges,s.Weekly,s.Daily,s.IsShortDays,s.NA,s.CreatedOn,CreatedByUser.FirstName + case when CreatedByUser.LastName is null  then '' else ' ' + CreatedByUser.LastName  end as 'CreatedByUser' from SLcFeeStracture s left join dbo.[user] as CreatedByUser  on CreatedByUser.Id = s.CreatedBy left join dbo.[user] as c on c.Id = s.CarerId " + attrFilter + whereClause + whereForWeeklyLocalAuthorityCharge + " order by CarerId asc,Amount asc");
                // including serviceuserid as well 25/9
                var listQuery = string.Format("select distinct s.CarerId,s.ServiceUserId,s.IsMonthClose,c.FirstName + ' ' + c.LastName as CarerName,s.Description,s.IsDeduction,s.Amount,s.LocalAuthorityCharges,s.Weekly,s.Daily,s.IsShortDays,s.NA,s.CreatedOn,CreatedByUser.FirstName + case when CreatedByUser.LastName is null  then '' else ' ' + CreatedByUser.LastName  end as 'CreatedByUser' from SLcFeeStracture s left join dbo.[user] as CreatedByUser  on CreatedByUser.Id = s.CreatedBy left join dbo.[user] as c on c.Id = s.CarerId " + attrFilter + whereClause + whereForWeeklyLocalAuthorityCharge + excludeRecordsWithoutServiceUserId + " order by CarerId asc,Amount asc");

                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                //financeListViewModel = MapSLCFFinanceListViewModels(exportedResults, searchModel.IsCarer); // old 
                // salman added on 15 september
                // below query is for future results, for current month future dates and for future months, years etc
                var financeReportListingViewQuery = string.Format("SELECT * FROM FinanceReportListingView" + futureWhereClasue + whereForWeeklyLocalAuthorityChargeFuture + attributesFutureSearch);
                var financeReportListingViewResult = await _unitOfWork.ExecuteSqlCommandSqlServer(financeReportListingViewQuery);
                //EndOfStreamException 15 september
                Guid currentUserId = UserId ?? Guid.Empty;
                var currentUser = await _unitOfWork.UserRepository.FindByIdAsync(currentUserId);

                financeListViewModel = await MapSLCFFinanceListViewModels(exportedResults, searchModel.IsCarer, financePeriodsData, financeReportListingViewResult, currentUser); // salman 13/9
                //financeListViewModel = financeListViewModel.OrderBy(x => x.IsShortDays == true && x.Amount == 0).ToList();
                return financeListViewModel;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        //private List<CarerFeeStructureViewModels> MapSLCFFinanceListViewModels(DataTable List, bool isCarer) // old
        private async Task<List<CarerFeeStructureViewModels>> MapSLCFFinanceListViewModels(DataTable List, bool isCarer, List<FinancePeriod> financePeriodsData, DataTable FinanceReportListingViewList, User currentUser) // salman 13/9
        {
            List<CarerFeeStructureViewModels> CarerFeeStructureModel = new List<CarerFeeStructureViewModels>();
            var userLoggedIn = currentUser;
            string userName = userLoggedIn.FirstName + " " + userLoggedIn.LastName;
            foreach (DataRow row in List.Rows)
            {
                CarerFeeStructureViewModels item = row.GetItem<CarerFeeStructureViewModels>();
                if (item.ServiceUserId == null)
                {
                    var a = "Test";
                }
                /* 
                       var checkCarer = CarerFeeStructureModel.Where(x => x.CarerId == item.CarerId).FirstOrDefault();
                           if (checkCarer == null)
                           {
                               CarerFeeStructureViewModels itemCarerFeeStructureModel = row.GetItem<CarerFeeStructureViewModels>();
                               itemCarerFeeStructureModel.Amount = 0;
                               itemCarerFeeStructureModel.LocalAuthorityCharges = 0;
                               CarerFeeStructureModel.Add(MapCarerFeeStructureViewModel(itemCarerFeeStructureModel, isCarer));
                           }
                          */
                // the above commented code is now being processed in the function below
                CarerFeeStructureModel = await ProcessCarerFeeStructureList(item, CarerFeeStructureModel, isCarer);
                item.CarerName = null;
                CarerFeeStructureModel.Add(await MapCarerFeeStructureViewModel(item, isCarer));
            }
            // new alpha
            foreach (DataRow row in FinanceReportListingViewList.Rows)
            {   // this loop is for future dates data, we need to create a new list in which if carer does not exists in that list, its first record will contain CarerName, and other records/rows related to the carer will contain CarerName = null
                CarerFeeStructureViewModels item = row.GetItem<CarerFeeStructureViewModels>();
                /*
                var checkCarer = CarerFeeStructureModel.Where(x => x.CarerId == item.CarerId).FirstOrDefault();
                if (checkCarer == null)
                {
                    CarerFeeStructureViewModels itemCarerFeeStructureModel = row.GetItem<CarerFeeStructureViewModels>();
                    itemCarerFeeStructureModel.Amount = 0;
                    itemCarerFeeStructureModel.LocalAuthorityCharges = 0;
                    CarerFeeStructureModel.Add(MapCarerFeeStructureViewModel(itemCarerFeeStructureModel, isCarer));
                }
                */
                // The above code is now being processed in the function
                CarerFeeStructureModel = await ProcessCarerFeeStructureList(item, CarerFeeStructureModel, isCarer);
                /* we dont need this part because we are doing this by ourself in the loop
                else
                {
                    item.CarerName = null;
                    CarerFeeStructureModel.Add(MapCarerFeeStructureViewModel(item, isCarer));
                }
                */
            }
            // end new alpha
            // if the month is same as the current date then the records till day before today are getting from db, other days we need to create
            //salman test inner
            // salman test 13/9
            List<CarerFeeStructureViewModels> additionalVirtualFinances = new List<CarerFeeStructureViewModels>();
            List<CarerFeeStructureViewModels> carerVirtualFinances = new List<CarerFeeStructureViewModels>();
            List<FinanceReportListingView> financeReportListingViewData = new List<FinanceReportListingView>();
            foreach (DataRow row in FinanceReportListingViewList.Rows)
            {
                FinanceReportListingView item = row.GetItem<FinanceReportListingView>();
                financeReportListingViewData.Add(item);
            }
            //var uniqueCarerIds = CarerFeeStructureModel.Select(x => x.CarerId).Distinct().ToList(); // salman commented for test
            var uniqueCarerIds = CarerFeeStructureModel.Select(x => x.CarerId).Distinct().ToList(); // Real for project
           // var uniqueCarerIds = new List<Guid>();
            //uniqueCarerIds.Add(new Guid("5aa9778b-87e1-4184-963a-e7c538c9f9cc"));
            foreach (var carerId in uniqueCarerIds)
            {
                 if(carerId == new Guid("197738fd-15e0-45aa-9e8d-1eb07522f4d5"))
                {
                    // tex dd
                    // 11 may : 5aa9778b-87e1-4184-963a-e7c538c9f9cc
                    // ded4715d - 2871 - 4c3d - 9e81 - 8b5359a04364
                    //sufi  cbe56503-49b2 - 4f2e-b45d - 9b9bb083d87c
                    var test = "abc";
                }
                var holidayLeaveSetupData = _unitOfWork.HolidayLeaveSetupRepository.FindAll(x => x.CarerId == carerId);
                //var holidayLeaveSetupDetailData = _unitOfWork.HolidayLeaveSetupDetailRepository.FindAll(x => x.CarerId == carerId);
                var carerRelatedServiceUser = financeReportListingViewData.Where(x => x.CarerId == carerId);
                //var singleCarerRecord = CarerFeeStructureModel.Find(x=>x.CarerId == carerId); // commented for each loop
                var singleCarerRecord = CarerFeeStructureModel.FindLast(x => x.CarerId == carerId); // we are fetching the last record because if we find simply, it will fetch the first record and it does not have the amount means amount is 0 in the first record, so we are fetching second or last
                bool isFirstIterationDaily = true; // these are very important for daily and weekly records for temp carer 
                bool isFirstIterationWeekly = true; // these are very important for daily and weekly records for temp carer 
                foreach (var singleServiceUser in carerRelatedServiceUser)
                {
                    var test = isFirstIterationWeekly;
                    var test2 = isFirstIterationDaily;
                    //if(singleServiceUser.ServiceUserId == new Guid("4fa91e25-7855-45d1-84a1-c0c39d7f447d"))
                    if (singleServiceUser.ServiceUserId == new Guid("b3c5dbac-32a3-4557-a7be-415c20991b7e"))
                    { // nimra
                        //3dad2f21 - acd5 - 4738 - a0aa - a669e94adef2 // zaman
                        var a = "test";
                    }
                    var holidayLeaveSetupDetailData = _unitOfWork.HolidayLeaveSetupDetailRepository.FindAll(x => (x.CarerId == carerId || x.ArrangementId == singleServiceUser.Id) && x.CarerId != null); // && x.CarerId !=null this is applied to avoid fetching records for natural support
                    foreach (var financePeriodInner in financePeriodsData) // finance periods are basically periods which are selected at front like september, october etc
                    {
                        // for daily fee code 
                        //if (singleCarerRecord.Daily == true)
                        if (singleServiceUser.Daily == true) // nwe on 10/2
                        {
                            if (financePeriodInner.EndDate >= DateTime.Now) // crone job has worked one less day than today, so we need to add for the next days data
                            {
                                var monthOfEndDate = financePeriodInner.EndDate.Month;
                                //if (DateTime.Now.Month == monthOfEndDate) // for example today is 13 september and finance period end date is 30 september
                                //{
                                DateTime currentDate = DateTime.Now;
                                currentDate = new DateTime(currentDate.Year, currentDate.Month, currentDate.Day, 0, 0, 0);
                                if (financePeriodInner.StartDate > currentDate)
                                {
                                    currentDate = financePeriodInner.StartDate; // for example if today is 14 september, and finance start date is 20 september, so it should take 20 september as the startdate
                                }
                                for (DateTime i = currentDate; i <= financePeriodInner.EndDate; i = i.AddDays(1))
                                {
                                    // if arrangement date ends then we need to break the loop, basically this is for, if we have finance period from 1 sep to 30 sep but arrangement ends at 29 sep, so we need to generate the records only till 29 september
                                    
                                    if (singleServiceUser.EndDate != null)
                                    {
                                        DateTime? arrangementEndDate = singleServiceUser.EndDate;
                                        if (arrangementEndDate.HasValue)
                                        {
                                            arrangementEndDate = new DateTime(arrangementEndDate.Value.Year, arrangementEndDate.Value.Month, arrangementEndDate.Value.Day, 0, 0, 0);
                                            
                                        }
                                        if (arrangementEndDate.HasValue && i >arrangementEndDate )
                                        {
                                            // Break the loop, if arrangement end date is less than current date
                                            break;
                                        }
                                    }

                                    // end arrangement check
                                    string loopDateString = i.ToString("dd/MM/yyyy");
                                    DateTime dateTime = DateTime.Now; // Replace this with your desired DateTime value
                                    string formattedDateString = dateTime.ToString("M/d/yyyy h:mm:ss tt");
                                    DateTime formattedDateTime = DateTime.ParseExact(formattedDateString, "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                                    //string loopDescriptionString = $"{partBeforeColon}: {loopDateString} - {loopDateString}";
                                    string Description = "PWS " + singleServiceUser.ServiceUserFirstName + " " + singleServiceUser.ServiceUserLastName + "-" + singleServiceUser.CarerFirstName + " " + singleServiceUser.CarerLastName + " -" + singleServiceUser.FeeTitle + ": " + loopDateString + " - " + loopDateString;
                                    var fee = isCarer == true ? singleServiceUser.Fee : singleServiceUser.LocalAuthorityCharge ?? 0;
                                    var localAuthorityFee = singleServiceUser.LocalAuthorityCharge ?? 0;
                                    Guid carerIdTemp = singleCarerRecord.CarerId ?? Guid.Empty;
                                    // checking if current date is holiday then donot insert
                                    var ifCurrentDateIsHoliday = holidayLeaveSetupData.Any(record => i >= record.StartDate && i <= record.EndDate);
                                    var TempAssignedHolidays = holidayLeaveSetupDetailData.Where(x => i >= x.StartDate && i <= x.EndDate).ToList();
                                    if (TempAssignedHolidays.Count > 0)
                                    {
                                        var arrangementId = TempAssignedHolidays[0].ArrangementId;
                                        var feeId = TempAssignedHolidays[0].FeeStructureId;
                                        var feeStructure = _unitOfWork.FeeStructureRepository.FindById(feeId);
                                        var arrangementRelatedData = financeReportListingViewData.Find(x => x.Id == arrangementId);
                                        if (arrangementRelatedData != null)
                                        {
                                            Description = "Holiday Fee of Pws " + arrangementRelatedData.ServiceUserFirstName + " " + arrangementRelatedData.ServiceUserLastName + "-" + arrangementRelatedData.ServiceUserFirstName + " " + arrangementRelatedData.ServiceUserLastName + "-" + feeStructure.FeeTitle + ":" + loopDateString + " - " + loopDateString;
                                            fee = isCarer == true ? arrangementRelatedData.Fee : arrangementRelatedData.LocalAuthorityCharge ?? 0;
                                            localAuthorityFee = arrangementRelatedData.LocalAuthorityCharge ?? 0;
                                            carerIdTemp = TempAssignedHolidays[0].CarerId ?? Guid.Empty; // important needs to understand
                                        }
                                        var carerData = _unitOfWork.UserRepository.FindById(carerIdTemp);
                                        CarerFeeStructureViewModels singleFinanceAdditionals = new CarerFeeStructureViewModels()
                                        {
                                            //CarerId = singleCarerRecord.CarerId,
                                            CarerId = carerIdTemp, // important needs to understand, it will pickup carer from HolidayDetail table instead of Arrangement table carer
                                            CarerName = null,
                                            //Description = loopDescriptionString, // only this thing is changed
                                            Description = Description,
                                            Weekly = singleCarerRecord.Weekly,
                                            CreatedByUser = userName,
                                            Daily = singleCarerRecord.Daily,
                                            NA = singleCarerRecord.NA,
                                            Amount = isCarer == true ? feeStructure.Fee : feeStructure.LocalAuthorityCharge ?? 0,
                                            LocalAuthorityCharges = feeStructure.LocalAuthorityCharge ?? 0,
                                            IsDeduction = singleCarerRecord.IsDeduction,
                                            IsShortDays = singleCarerRecord.IsShortDays,
                                            IsMonthClose = singleCarerRecord.IsMonthClose,
                                            CreatedOn = singleCarerRecord.CreatedOn,
                                            ServiceUserId = singleCarerRecord.ServiceUserId,
                                            ServiceUserName = singleCarerRecord.ServiceUserName

                                            //CreatedOn = DateTime.Parse(loopDateString),
                                        };
                                        singleFinanceAdditionals.CarerName = carerData.FirstName + " " + carerData.LastName;
                                        //if (isFirstIterationDaily) // old
                                        if (isFirstIterationDaily) //new 2 oct
                                        {
                                            //if i dont put this iteration check, it adds multiple records, working fine after adding this check
                                            await ProcessCarerFeeStructureList(singleFinanceAdditionals, CarerFeeStructureModel, true);
                                            singleFinanceAdditionals.Amount = isCarer == true ? feeStructure.Fee : feeStructure.LocalAuthorityCharge ?? 0;
                                            singleFinanceAdditionals.LocalAuthorityCharges = feeStructure.LocalAuthorityCharge ?? 0;
                                            singleFinanceAdditionals.CarerName = null;
                                            additionalVirtualFinances.Add(singleFinanceAdditionals);
                                        }
                                    }
                                    CarerFeeStructureViewModels singleFinanceAdditional = new CarerFeeStructureViewModels()
                                    {
                                        CarerId = singleCarerRecord.CarerId,
                                        CarerName = null,
                                        //Description = loopDescriptionString, // only this thing is changed
                                        Description = "PWS " + singleServiceUser.ServiceUserFirstName + " " + singleServiceUser.ServiceUserLastName + "-" + singleServiceUser.CarerFirstName + " " + singleServiceUser.CarerLastName + " -" + singleServiceUser.FeeTitle + ": " + loopDateString + " - " + loopDateString,
                                        Weekly = singleCarerRecord.Weekly,
                                        CreatedByUser = userName,
                                        Daily = singleCarerRecord.Daily,
                                        NA = singleCarerRecord.NA,
                                        Amount = isCarer == true ? singleServiceUser.Fee : singleServiceUser.LocalAuthorityCharge ?? 0,
                                        LocalAuthorityCharges = singleServiceUser.LocalAuthorityCharge ?? 0,
                                        IsDeduction = singleCarerRecord.IsDeduction,
                                        IsShortDays = singleCarerRecord.IsShortDays,
                                        IsMonthClose = singleCarerRecord.IsMonthClose,
                                        CreatedOn = formattedDateTime,
                                        ServiceUserId = singleServiceUser.ServiceUserId,
                                        ServiceUserName = singleServiceUser.ServiceUserName
                                        //CreatedOn = DateTime.Parse(loopDateString),
                                    };
                                    if (!ifCurrentDateIsHoliday)
                                    {
                                        additionalVirtualFinances.Add(singleFinanceAdditional);
                                    }
                                }
                                //}
                            }
                        }
                        // for daily ends
                        // for weekly starts
                        // for weekly starts
                       // if (singleCarerRecord.Weekly == true)
                            if (singleServiceUser.Weekly == true)
                            {
                            DateTime currentDate = DateTime.Now;
                            var Today = DateTime.Now.DayOfWeek;
                            DateTime dateTime = DateTime.Now; // Replace this with your desired DateTime value
                            string formattedDateString = dateTime.ToString("M/d/yyyy h:mm:ss tt");
                            DateTime formattedDateTime = DateTime.ParseExact(formattedDateString, "M/d/yyyy h:mm:ss tt", CultureInfo.InvariantCulture);
                            if (financePeriodInner.EndDate >= DateTime.Now) // crone job has worked one less day than today, so we need to add for the next days data
                            {
                                DateTime loopStartDate = currentDate; // considering today is sunday, if today is not sunday the check is implemented below
                                                                      // we need to calculate TDate by ourself
                                if (currentDate.Month == financePeriodInner.StartDate.Month)
                                { // consider today as 19 september, records are inserted in the db for last saturday so we need to calculate from the last sunday
                                    if (currentDate.DayOfWeek != DayOfWeek.Sunday)
                                    {
                                        int daysUntilPreviousSunday = (int)currentDate.DayOfWeek;
                                        // Calculate the date of the previous Sunday
                                        DateTime previousSundayDate = currentDate.AddDays(-daysUntilPreviousSunday);
                                        loopStartDate = previousSundayDate; // then loop will start from the last sundy
                                                                            // string resultString = $"PWS Ali test - Sufi Slc - Weekly Test : {previousSunday:dd MMMM yyyy} - {currentDate:dd MMMM yyyy}";
                                        if(singleServiceUser.StartDate > financePeriodInner.StartDate)
                                        {   // if room start date is 27 september and finance period start date is 1 september, so we need to start from the 27 september not from first
                                            loopStartDate = singleServiceUser.StartDate?? previousSundayDate;
                                        }
                                    }
                                }
                                else
                                {
                                    
                                    // if month is not same, then it will check if today is not sunday then calculate the fee till next sunday and show it
                                    loopStartDate = financePeriodInner.StartDate; // considering today is sunday, if today is not sunday the check is implemented below
                                    
                                    DateTime financePeriodStartDate = financePeriodInner.StartDate;
                                    DateTime? arrangementEndDateWeekly = singleServiceUser.EndDate;

                                    if (singleServiceUser.StartDate > financePeriodInner.StartDate)
                                    {   // for example if our finance period is from 1 oct to 31 oct, and arrangement start date is 5 oct and end date is 10oct, in this case loop should start from 5 oct
                                        loopStartDate = singleServiceUser.StartDate ?? loopStartDate;
                                        financePeriodStartDate = singleServiceUser.StartDate ?? financePeriodStartDate; // if arrangement start date is greater than finance start date then make the finance start date as arrangement start date, because below loop is working 
                                    }
                                    if (financePeriodStartDate.DayOfWeek != DayOfWeek.Sunday)
                                    {
                                       // int daysUntilNextSunday = ((int)DayOfWeek.Sunday - (int)financePeriodStartDate.DayOfWeek + 7) % 7; // commented on 28/9
                                        int daysUntilNextSunday = ((int)DayOfWeek.Sunday - (int)financePeriodStartDate.DayOfWeek + 7) % 7;
                                        DateTime nextSundayDate = financePeriodStartDate.AddDays(daysUntilNextSunday);
                                        string saturdayDateString = nextSundayDate.AddDays(-1).ToString("dd/MM/yyyy");
                                        if (arrangementEndDateWeekly.HasValue && arrangementEndDateWeekly.Value < nextSundayDate)
                                        {  // singleServiceUser.EndDate: it is the arrangement end date, if arrangement end date is less than the finance period or sunday date then we need to calculate days till that date
                                            daysUntilNextSunday = ((int)arrangementEndDateWeekly.Value.DayOfWeek - (int)financePeriodStartDate.DayOfWeek + 7) % 7;
                                            nextSundayDate = financePeriodStartDate.AddDays(daysUntilNextSunday);
                                            saturdayDateString = nextSundayDate.ToString("dd/MM/yyyy");
                                        }
                                        // Calculate the date of the previous Sunday
                                        
                                        decimal feeForRemainingDays = Math.Round(singleServiceUser.Fee / 7, 2);
                                        feeForRemainingDays = feeForRemainingDays * daysUntilNextSunday;
                                        decimal localAuthorityCharges = singleServiceUser.LocalAuthorityCharge ?? 0;
                                        decimal localAuthorityFeeforRemainingDays = Math.Round(localAuthorityCharges / 7, 2);
                                        localAuthorityFeeforRemainingDays = localAuthorityFeeforRemainingDays * daysUntilNextSunday;
                                        // insert record separately for remianing days and then once sunday is reached all other records will be inserted in loop 
                                       // string startDateString = financePeriodInner.StartDate.ToString("dd/MM/yyyy"); // old commented on 28/9
                                        string startDateString = financePeriodStartDate.ToString("dd/MM/yyyy");
                                    
                                        CarerFeeStructureViewModels singleFinanceAdditional = new CarerFeeStructureViewModels()
                                        {
                                            CarerId = singleCarerRecord.CarerId,
                                            CarerName = null,
                                            //Description = loopDescriptionString, // only this thing is changed
                                            Description = "PWS " + singleServiceUser.ServiceUserFirstName + " " + singleServiceUser.ServiceUserLastName + "-" + singleServiceUser.CarerFirstName + " " + singleServiceUser.CarerLastName + " -" + singleServiceUser.FeeTitle + ": " + startDateString + " - " + saturdayDateString,
                                            Weekly = singleServiceUser.Weekly??false,
                                            CreatedByUser = userName,
                                            Daily = singleServiceUser.Daily??false,
                                            NA = singleCarerRecord.NA,
                                            Amount = isCarer == true ? feeForRemainingDays : localAuthorityFeeforRemainingDays,
                                            LocalAuthorityCharges = localAuthorityFeeforRemainingDays,
                                            IsDeduction = false,
                                            IsShortDays = false,
                                            IsMonthClose = false,
                                            CreatedOn = formattedDateTime,
                                            ServiceUserId = singleServiceUser.ServiceUserId,
                                            ServiceUserName = singleServiceUser.ServiceUserName
                                            //CreatedOn = DateTime.Parse(loopDateString),
                                        };
                                        additionalVirtualFinances.Add(singleFinanceAdditional);
                                        // end inserting
                                        loopStartDate = nextSundayDate; // then loop will start from the last sundy
                                                                        // string resultString = $"PWS Ali test - Sufi Slc - Weekly Test : {previousSunday:dd MMMM yyyy} - {currentDate:dd MMMM yyyy}";
                                        loopStartDate = new DateTime(loopStartDate.Year, loopStartDate.Month, loopStartDate.Day, 0, 0, 0); // making its hours, mins, seconds to 00:00:00
                                    }
                                }

                                // if arrangement date ends then we need to break the loop, basically this is for, if we have finance period from 1 sep to 30 sep but arrangement ends at 29 sep, so we need to generate the records only till 29 september
                                DateTime? arrangementEndDate = null;
                                if (singleServiceUser.EndDate != null)
                                {
                                    arrangementEndDate = singleServiceUser.EndDate;
                                    if (arrangementEndDate.HasValue)
                                    {
                                        arrangementEndDate = new DateTime(arrangementEndDate.Value.Year, arrangementEndDate.Value.Month, arrangementEndDate.Value.Day, 0, 0, 0);

                                    }

                                }

                                loopStartDate = new DateTime(loopStartDate.Year, loopStartDate.Month, loopStartDate.Day, 0, 0, 0); // making its hours, mins, seconds to 00:00:00

                                // loop through the last sunday to the end date of the finance period
                                for (DateTime i = loopStartDate; i <= financePeriodInner.EndDate; i = i.AddDays(7))
                                {   
                                    //if(arrangementEndDate.HasValue && i >= arrangementEndDate) // old
                                        if (arrangementEndDate.HasValue && i > arrangementEndDate)  // new on 2 oct
                                        {   // this will bheck if arrangement end date is < than the loop start date then end the loopss
                                        break;
                                    }
                                    string loopDateString = i.ToString("dd/MM/yyyy");
                                    string weeklyEndDateString = i.AddDays(6).ToString("dd/MM/yyyy"); // weekly end day will be saturday because we are doing it sunda to saturday each 
                                                                                                      // now i will be always sunday
                                    var currentWeekStartDate = i;
                                    DateTime next7DaysDate = i.AddDays(6);
                                    // salman new 
                                    DateTime financePeriodEndDate = financePeriodInner.EndDate;
                                    var daysDifference = 0; // this will hold the difference between the finance period end date and next7DaysDate
                                    if (financePeriodEndDate < next7DaysDate)
                                    {   
                                        TimeSpan differenceInDays;
                                        if (arrangementEndDate.HasValue && (arrangementEndDate < financePeriodEndDate)){
                                            differenceInDays = next7DaysDate - arrangementEndDate.Value;
                                            daysDifference = differenceInDays.Days;
                                            next7DaysDate = arrangementEndDate.Value; // now the next7DaysDate will be the finance period end date, you can understand it by considering the month of october 2023, its last week starts from 29 october and ends at 31 october, but the next7DaysDate was 04 novermber before, but now corrected and made 31 october which is finance end date 
                                            weeklyEndDateString = arrangementEndDate.Value.ToString("dd/MM/yyyy");
                                        }
                                        else {
                                            differenceInDays = next7DaysDate - financePeriodEndDate;
                                            daysDifference = differenceInDays.Days;
                                            next7DaysDate = financePeriodEndDate; // now the next7DaysDate will be the finance period end date, you can understand it by considering the month of october 2023, its last week starts from 29 october and ends at 31 october, but the next7DaysDate was 04 novermber before, but now corrected and made 31 october which is finance end date 
                                            weeklyEndDateString = financePeriodEndDate.ToString("dd/MM/yyyy"); // this is for description  
                                            }

                                        /*
                                        TimeSpan differenceInDays = next7DaysDate - financePeriodEndDate;
                                        daysDifference = differenceInDays.Days;
                                        next7DaysDate = financePeriodEndDate; // now the next7DaysDate will be the finance period end date, you can understand it by considering the month of october 2023, its last week starts from 29 october and ends at 31 october, but the next7DaysDate was 04 novermber before, but now corrected and made 31 october which is finance end date 
                                        weeklyEndDateString = financePeriodEndDate.ToString("dd/MM/yyyy"); // this is for description  
                                    */
                                    }
                                    else
                                    {   // in case if finance period end date is greater than next 7 days but arrangement date is less than next 7 days
                                        TimeSpan differenceInDays;
                                        if (arrangementEndDate.HasValue && (arrangementEndDate < next7DaysDate))
                                        {
                                            differenceInDays = next7DaysDate - arrangementEndDate.Value;
                                            daysDifference = differenceInDays.Days;
                                            next7DaysDate = arrangementEndDate.Value; // now the next7DaysDate will be the finance period end date, you can understand it by considering the month of october 2023, its last week starts from 29 october and ends at 31 october, but the next7DaysDate was 04 novermber before, but now corrected and made 31 october which is finance end date 
                                            weeklyEndDateString = arrangementEndDate.Value.ToString("dd/MM/yyyy");
                                        }
                                        /*
                                        else
                                        {
                                            differenceInDays = next7DaysDate - financePeriodEndDate;
                                            daysDifference = differenceInDays.Days;
                                            next7DaysDate = financePeriodEndDate; // now the next7DaysDate will be the finance period end date, you can understand it by considering the month of october 2023, its last week starts from 29 october and ends at 31 october, but the next7DaysDate was 04 novermber before, but now corrected and made 31 october which is finance end date 
                                            weeklyEndDateString = financePeriodEndDate.ToString("dd/MM/yyyy"); // this is for description  
                                        }
                                        */
                                    }
                                    // salman end new
                                    // checking the overlapping days
                                    int totalOverlappingDays = 0;
                                    // checking the holidays and cutting the fee 
                                    foreach (var holiday in holidayLeaveSetupData)
                                    {
                                        // Check if the holiday's date range overlaps with the loop interval
                                        DateTime startDate = holiday.StartDate > currentWeekStartDate ? holiday.StartDate : currentWeekStartDate;
                                        DateTime endDate = holiday.EndDate < next7DaysDate ? holiday.EndDate : next7DaysDate;
                                        if (startDate <= endDate)
                                        {
                                            // Calculate the number of overlapping days
                                            TimeSpan overlap = endDate - startDate;
                                            totalOverlappingDays += overlap.Days + 1; // Add 1 to include both start and end days
                                        }
                                    }
                                    // end checking 
                                    decimal currentWeekFee = singleServiceUser.Fee - daysDifference * (singleServiceUser.Fee / 7); // if there is date difference it will be deducted
                                    currentWeekFee = Math.Round(currentWeekFee, 2);
                                    decimal currentWeekLocalAuthorityFee = singleServiceUser.LocalAuthorityCharge - daysDifference * (singleServiceUser.LocalAuthorityCharge / 7) ?? 0;
                                    currentWeekLocalAuthorityFee = Math.Round(currentWeekLocalAuthorityFee, 2);
                                    // first we have calculated the fee of the carer with respect to week and week days
                                    // then we are applying or deducting the holiday fee
                                    decimal amountAfterCuttingHolidays = currentWeekFee - totalOverlappingDays * (currentWeekFee / 7); // deduct the fee of overlapping days from the total fee of week
                                    decimal localAuthorityFeeAfterCuttingHolidays = currentWeekLocalAuthorityFee - totalOverlappingDays * (currentWeekLocalAuthorityFee / 7);
                                    amountAfterCuttingHolidays = Math.Round(amountAfterCuttingHolidays, 2);
                                    localAuthorityFeeAfterCuttingHolidays = Math.Round(localAuthorityFeeAfterCuttingHolidays, 2);
                                    CarerFeeStructureViewModels singleFinanceAdditional = new CarerFeeStructureViewModels()
                                    {
                                        CarerId = singleCarerRecord.CarerId,
                                        CarerName = null,
                                        //Description = loopDescriptionString, // only this thing is changed
                                        Description = "PWS " + singleServiceUser.ServiceUserFirstName + " " + singleServiceUser.ServiceUserLastName + "-" + singleServiceUser.CarerFirstName + " " + singleServiceUser.CarerLastName + " -" + singleServiceUser.FeeTitle + ": " + loopDateString + " - " + weeklyEndDateString,
                                        Weekly = singleServiceUser.Weekly??false,
                                        CreatedByUser = userName,
                                        Daily = singleServiceUser.Daily??false,
                                        NA = singleCarerRecord.NA,
                                        Amount = isCarer == true ? amountAfterCuttingHolidays : localAuthorityFeeAfterCuttingHolidays,
                                        //Amount = isCarer == true ? singleServiceUser.Fee : singleServiceUser.LocalAuthorityCharge ?? 0,
                                        LocalAuthorityCharges = localAuthorityFeeAfterCuttingHolidays,
                                        IsDeduction = singleCarerRecord.IsDeduction,
                                        IsShortDays = singleCarerRecord.IsShortDays,
                                        IsMonthClose = singleCarerRecord.IsMonthClose,
                                        CreatedOn = formattedDateTime,
                                        ServiceUserId = singleServiceUser.ServiceUserId,
                                        ServiceUserName = singleServiceUser.ServiceUserName
                                        //CreatedOn = DateTime.Parse(loopDateString),
                                    };
                                    additionalVirtualFinances.Add(singleFinanceAdditional);
                                    // now checking is the carer has some temporary rooms alot
                                    foreach (var holidayDetail in holidayLeaveSetupDetailData)
                                    {

                                        // I want to check if the arrangement is Archive now, then we don;t need to add fee to the Carer
                                        var arrangementArchive = _unitOfWork.ArrangementRepository.FindById(holidayDetail.ArrangementId);
                                        if(arrangementArchive.IsArchive)
                                        {   // if arrangement is archive now, then we need to break the loop
                                            continue;
                                        }
                                        var arrangementRelatedData = financeReportListingViewData.Find(x => x.Id == holidayDetail.ArrangementId);
                                        var Description = "";
                                        decimal fee = 0;
                                        decimal localAuthorityFee = 0;
                                        Guid carerTempId = singleCarerRecord.CarerId ?? Guid.Empty;
                                        var feeId = holidayDetail.FeeStructureId;
                                        var feeStructure = _unitOfWork.FeeStructureRepository.FindById(feeId);
                                        if (arrangementRelatedData != null)
                                        {
                                            Description = "Holiday Fee of Pws " + arrangementRelatedData.ServiceUserFirstName + " " + arrangementRelatedData.ServiceUserLastName + "-" + arrangementRelatedData.ServiceUserFirstName + " " + arrangementRelatedData.ServiceUserLastName + "-" + feeStructure.FeeTitle + ":" + loopDateString + " - " + loopDateString;
                                            fee = isCarer == true ? feeStructure.Fee : feeStructure.LocalAuthorityCharge ?? 0;
                                            localAuthorityFee = feeStructure.LocalAuthorityCharge ?? 0;
                                            carerTempId = holidayDetail.CarerId ?? Guid.Empty;
                                        }
                                        var carerData = _unitOfWork.UserRepository.FindById(carerTempId);
                                        DateTime startDate = holidayDetail.StartDate > currentWeekStartDate ? holidayDetail.StartDate : currentWeekStartDate;
                                        DateTime endDate = holidayDetail.EndDate < next7DaysDate ? holidayDetail.EndDate : next7DaysDate;
                                        if (startDate <= endDate)
                                        {
                                            // Calculate the overlapping dates
                                            for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
                                            {
                                                string innerLoopStartDate = date.ToString("dd/MM/yyyy");
                                                if (arrangementRelatedData != null)
                                                {
                                                    Description = "Holiday Fee of Pws " + arrangementRelatedData.ServiceUserFirstName + " " + arrangementRelatedData.ServiceUserLastName + "-" + arrangementRelatedData.ServiceUserFirstName + " " + arrangementRelatedData.ServiceUserLastName + "-" + feeStructure.FeeTitle + ":" + innerLoopStartDate + " - " + innerLoopStartDate;
                                                }
                                                CarerFeeStructureViewModels singleFinanceAdditionalInner = new CarerFeeStructureViewModels()
                                                {
                                                    CarerId = carerTempId,
                                                    CarerName = null,
                                                    //Description = loopDescriptionString, // only this thing is changed
                                                    Description = Description,
                                                    Weekly = singleServiceUser.Weekly??false,
                                                    CreatedByUser = userName,
                                                    Daily = singleServiceUser.Daily??false,
                                                    NA = singleCarerRecord.NA,
                                                    Amount = isCarer == true ? fee : localAuthorityFee,
                                                    //Amount = isCarer == true ? singleServiceUser.Fee : singleServiceUser.LocalAuthorityCharge ?? 0,
                                                    LocalAuthorityCharges = localAuthorityFee,
                                                    IsDeduction = singleCarerRecord.IsDeduction,
                                                    IsShortDays = singleCarerRecord.IsShortDays,
                                                    IsMonthClose = singleCarerRecord.IsMonthClose,
                                                    CreatedOn = formattedDateTime,
                                                    ServiceUserId = singleServiceUser.ServiceUserId,
                                                    ServiceUserName = singleServiceUser.ServiceUserName
                                                    //CreatedOn = DateTime.Parse(loopDateString),
                                                };
                                                if (arrangementRelatedData != null && arrangementRelatedData.CarerId == holidayDetail.CarerId)
                                                { // the above check is applied because we are fetching the carers based on arrangementid or carerid so we will need to insert only those records in which holidayleavedetail carerId matches with the arrrangement carer
                                                    additionalVirtualFinances.Add(singleFinanceAdditionalInner);
                                                }
                                                else
                                                {
                                                    // if carer is not present before in the list 
                                                    singleFinanceAdditionalInner.CarerName = carerData.FirstName + " " + carerData.LastName;
                                                    //if (isFirstIterationWeekly) // old
                                                    if (isFirstIterationWeekly) // new on 02 oct
                                                    { // if i dont put this iteration check, it adds multiple records, working fine after adding this check
                                                        await ProcessCarerFeeStructureList(singleFinanceAdditionalInner, CarerFeeStructureModel, true);
                                                        singleFinanceAdditionalInner.Amount = isCarer == true ? feeStructure.Fee : feeStructure.LocalAuthorityCharge ?? 0;
                                                        singleFinanceAdditionalInner.LocalAuthorityCharges = feeStructure.LocalAuthorityCharge ?? 0;
                                                        singleFinanceAdditionalInner.CarerName = null;
                                                        additionalVirtualFinances.Add(singleFinanceAdditionalInner);
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                }
                            }
                        }
                       

                    }
                    isFirstIterationDaily = false; // this is used for avoiding the duplicate records for temporary carer data
                    isFirstIterationWeekly = false; // these are very important for daily and weekly records for temp carer 
                }
                //carerVirtualFinances.AddRange(additionalVirtualFinances); // merge two lists
            } // foreach brakcet
            CarerFeeStructureModel.AddRange(additionalVirtualFinances);

            foreach (var item in CarerFeeStructureModel.Where(x => x.CarerName != null))
            {
                if (item.CarerName != null)
                {
                    var sumAmount = CarerFeeStructureModel.Where(x => x.CarerId == item.CarerId).Sum(x => (decimal?)x.Amount) ?? 0;
                    var sumAmountLocalAuthority = CarerFeeStructureModel.Where(x => x.CarerId == item.CarerId).Sum(x => (decimal?)x.LocalAuthorityCharges) ?? 0;
                    item.Amount = sumAmount;
                    item.LocalAuthorityCharges = sumAmountLocalAuthority;
                }
            }
            //return CarerFeeStructureModel; // old
            // salman
            // to group the data going to frontend by CarerId, otherwise it is not showing fine
            //CarerFeeStructureModel = CarerFeeStructureModel.GroupBy(item => item.CarerId).SelectMany(group => group).ToList(); old 

            // Here I was facing issue in grouping and order by, because the resultant list was holding carer name only in 
            // first record of the carer, so what we did, we first grouped the records by carerid then we order the groups 
            // by carer name
            // Group records by CarerId
            var groupedByCarerId = CarerFeeStructureModel
                .GroupBy(item => item.CarerId)
                .Select(group => new
                {
                    CarerId = group.Key,
                    CarerName = group.First().CarerName,
                    TotalAmount = group.First().Amount,
                    CarerRecords = group.ToList()
                });

            // Order by CarerName within each group
            CarerFeeStructureModel = groupedByCarerId
               .OrderBy(group => group.CarerName)
               .SelectMany(group => group.CarerRecords)
               .ToList();

            return CarerFeeStructureModel;
            // end salman
        }
        private async Task<List<CarerFeeStructureViewModels>> ProcessCarerFeeStructureList(CarerFeeStructureViewModels item, List<CarerFeeStructureViewModels> CarerFeeStructureModel, bool isCarer)
        {

            var serviceUserData = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == item.ServiceUserId);
            var checkCarer = CarerFeeStructureModel.Where(x => x.CarerId == item.CarerId).FirstOrDefault();

            if (checkCarer == null)
            {   /*
                CarerFeeStructureViewModels itemCarerFeeStructureModel = item;
                itemCarerFeeStructureModel.Amount = 0;
                itemCarerFeeStructureModel.LocalAuthorityCharges = 0;
                */
                CarerFeeStructureViewModels itemCarerFeeStructureModel = new CarerFeeStructureViewModels
                {
                    // Here we need to map the whole object unlike the previous where we were only updating 2 things, which was causing issue as the first record was showing 0
                    CarerId = item.CarerId,
                    Amount = 0,
                    LocalAuthorityCharges = 0,
                    CarerName = item.CarerName,
                    Description = item.Description,
                    Weekly = item.Weekly,
                    Daily = item.Daily,
                    NA = item.NA,
                    IsMonthClose = item.IsMonthClose,
                    IsDeduction = item.IsDeduction,
                    IsShortDays = item.IsShortDays,
                    CreatedByUser = item.CreatedByUser,
                    CreatedOn = item.CreatedOn,
                    ServiceUserId = item.ServiceUserId, // salman
                    ServiceUserName = serviceUserData.FirstName + " " + serviceUserData.LastName// salman

                };
                CarerFeeStructureModel.Add(await MapCarerFeeStructureViewModel(itemCarerFeeStructureModel, isCarer));
            }
            return CarerFeeStructureModel;
        }
        private async Task<CarerFeeStructureViewModels> MapCarerFeeStructureViewModel(CarerFeeStructureViewModels model, bool isCarer)
        {
            var serviceUserData = await _unitOfWork.ServiceUserRepository.GetFirstOrDefaultAsync(x => x.Id == model.ServiceUserId);
            var carerListViewModel = new CarerFeeStructureViewModels()
            {
                CarerId = model.CarerId,
                CarerName = model.CarerName,
                Description = model.Description,
                Weekly = model.Weekly,
                CreatedByUser = model.CreatedByUser,
                Daily = model.Daily,
                NA = model.NA,
                Amount = isCarer == true ? model.Amount : model.LocalAuthorityCharges,
                LocalAuthorityCharges = model.LocalAuthorityCharges,
                IsDeduction = model.IsDeduction,
                IsShortDays = model.IsShortDays,
                IsMonthClose = model.IsMonthClose,
                CreatedOn = model.CreatedOn,
                ServiceUserId = model.ServiceUserId,
                ServiceUserName = serviceUserData.FirstName + " " + serviceUserData.LastName
            };
            return carerListViewModel;
        }

        #endregion

        #region  Finance Report Excel report
        public async Task<Stream> DownloadFinanceReportResultsInExcel(FinanceReportSearchModel searchModel, Guid? UserId)
        {
            XLWorkbook workbook = null;
            MemoryStream memoryStream = null;

            try
            {/*
                var data = await GetFinanceReportList(searchModel, UserId);
                var result = data.GroupBy(sd => new { sd.CarerId, sd.ServiceUserId })
                .Select(group => new
                {
                    CarerId = group.Key.CarerId,
                    ServiceUserId = group.Key.ServiceUserId,
                    TotalAmount = group.Sum(sd => sd.Amount)
                })
                .ToList();
                */
                var data = await GetFinanceReportList(searchModel, UserId);
                // need to remove 
                //return null;
                // end need to remove 
                workbook = new XLWorkbook();
                memoryStream = new MemoryStream();
                decimal totalAmount = 0;

                //if (data != null)
                if (data != null && searchModel.IsSummary == false)
                {
                    var worksheet = workbook.Worksheets.Add("Report Results");

                    var headerStyle = worksheet.FirstRow();
                    headerStyle.Style.Font.Bold = true;
                    headerStyle.Style.Font.FontColor = XLColor.White;
                    headerStyle.Style.Fill.BackgroundColor = XLColor.FromHtml("#4F81BD");

                    // Enable AutoFilter for the header row to show filter arrows
                    // worksheet.Tables.Add(worksheet.RangeUsed(), "MyTable"); // Add a table to the worksheet
                    // worksheet.Tables.Table(0).ShowAutoFilter = true; // Enable AutoFilter for the table


                    // Add headers for the columns you want to export
                    worksheet.Cell(1, 1).Value = "Description";
                    worksheet.Cell(1, 2).Value = "Amount (£)";
                    worksheet.Cell(1, 3).Value = "Weekly";
                    worksheet.Cell(1, 4).Value = "Daily";
                    worksheet.Cell(1, 5).Value = "N/A";
                    worksheet.Cell(1, 6).Value = "Created ON";

                    // Set column widths explicitly for header cells
                    worksheet.Column(1).Width = 40;
                    worksheet.Column(2).Width = 15;
                    worksheet.Column(3).Width = 10;
                    worksheet.Column(4).Width = 10;
                    worksheet.Column(5).Width = 10;
                    worksheet.Column(6).Width = 15;
                    // Add more headers as needed
                    // Enable AutoFilter for the header row to show filter arrows
                    worksheet.RangeUsed().SetAutoFilter();


                    int row = 2;

                    foreach (var item in data)
                    {
                        // Skip records where CarerName is not null
                        if (string.IsNullOrEmpty(item.CarerName))  // do not include those rows which contains CarerName and TotalAmount related to that carer
                        {
                            var currentRow = worksheet.Row(row);
                            if (row % 2 == 0)
                            {
                                // Apply light blue background to even rows
                                currentRow.Style.Fill.BackgroundColor = XLColor.FromHtml("#DCE6F1");
                            }
                            else
                            {
                                // No background for odd rows
                                currentRow.Style.Fill.BackgroundColor = XLColor.NoColor;
                            }

                            // Populate data
                            worksheet.Cell(row, 1).Value = item.Description;
                            worksheet.Cell(row, 2).Value = item.Amount.ToString(); // Assuming Amount is decimal
                            worksheet.Cell(row, 3).Value = item.Weekly ? "Selected" : "UnSelected";
                            worksheet.Cell(row, 4).Value = item.Daily ? "Selected" : "UnSelected";
                            worksheet.Cell(row, 5).Value = item.NA ? "Selected" : "UnSelected";
                            worksheet.Cell(row, 6).Value = item.CreatedOn.ToString("dd/MM/yyyy hh:mm:ss") + " by " + item.CreatedByUser;

                            // Add more data columns as needed

                            totalAmount += item.Amount;
                            row++;
                        }
                    }

                    // Add Total Amount
                    worksheet.Cell(row, 1).Value = "Total Amount (£)";
                    worksheet.Cell(row, 2).Value = totalAmount;
                }
                else
                {
                    // if IsSummary is equal true
                    List<FinanceReportSummaryModel> summaryData = new List<FinanceReportSummaryModel>();
                    summaryData = await GetFinanceReportSummaryAsync(data, searchModel.FinancePeriodIds);
                    if (summaryData != null)
                    {
                        var worksheet = workbook.Worksheets.Add("Report Results");

                        var headerStyle = worksheet.FirstRow();
                        headerStyle.Style.Font.Bold = true;
                        headerStyle.Style.Font.FontColor = XLColor.White;
                        headerStyle.Style.Fill.BackgroundColor = XLColor.FromHtml("#4F81BD");

                        // find the maximum service users of any carer in the list, means if a user has 4 carers at maximum and all others have less than this so we will make heading of 4
                        int maxServiceUsers = summaryData.Max(report => report.ServiceUsers.Count);

                        // Add headers for the columns you want to export, these columns are now added dynamically
                        // Set the column headings

                        worksheet.Cell(1, 1).Value = "Description";
                        worksheet.Column(1).Width = 30;
                        worksheet.Cell(1, 2).Value = "SLC";
                        worksheet.Column(2).Width = 30;
                        int startHeadDynamicColumn = 3; // Starting from the 3rd column
                        for (int i = 1; i <= maxServiceUsers; i++)
                        {
                            worksheet.Cell(1, startHeadDynamicColumn).Value = "PWS " + i + " Name";
                            worksheet.Cell(1, startHeadDynamicColumn + 1).Value = "PWS " + i + " Amount";
                            worksheet.Column(startHeadDynamicColumn).Width = 20;
                            worksheet.Column(startHeadDynamicColumn + 1).Width = 20;

                            startHeadDynamicColumn += 2; // Move to the next set of columns
                        }

                        //worksheet.Cell(1, maxServiceUsers * 2 + 3).Value = "TOTAL";
                        worksheet.Cell(1, startHeadDynamicColumn).Value = "TOTAL";
                        worksheet.Column(startHeadDynamicColumn).Width = 15;

                        // Set column widths explicitly for header cells
                        /*
                        worksheet.Column(1).Width = 40;
                        worksheet.Column(2).Width = 15;
                        worksheet.Column(3).Width = 10;
                        worksheet.Column(4).Width = 10;
                        worksheet.Column(5).Width = 10;
                        worksheet.Column(6).Width = 15;
                        */
                        // Add more headers as needed
                        // Enable AutoFilter for the header row to show filter arrows
                        worksheet.RangeUsed().SetAutoFilter();
                        int row = 2;

                        // Define the starting row (after the column headers)
                        int currentRow = 2;

                        foreach (var item in summaryData)
                        {
                            // Populate data for each carer
                            worksheet.Cell(currentRow, 1).Value = "Period(s) : " + item.Description;
                            worksheet.Cell(currentRow, 2).Value = "'" + item.CarerName.ToString(); // we have used  ' and ToString because some data in the list is like 04 May, 10 July so excel creates date of that, and print date instead of real data so to avoid that we have used this

                            // Populate data for each service user
                            int currentColumn = 3;
                            int serviceUserCounter = 1;
                            foreach (var serviceUser in item.ServiceUsers)
                            {
                                string serviceUserNameInner = "";
                                if(!string.IsNullOrWhiteSpace(serviceUser.ServiceUserName))
                                {
                                    serviceUserNameInner = serviceUser.ServiceUserName;

                                }
                                else
                                {
                                    serviceUserNameInner = "PWS " + serviceUserCounter +" Unnamed";
                                }
                                // worksheet.Cell(currentRow, currentColumn).Value = "'" + serviceUser.ServiceUserName.ToString();
                                worksheet.Cell(currentRow, currentColumn).Value = "'" + serviceUserNameInner.ToString();
                                worksheet.Cell(currentRow, currentColumn + 1).Value = "£ " + serviceUser.Amount;
                                currentColumn += 2; // Move to the next pair of columns for the next service user
                                serviceUserCounter += 1;
                            }
                            if (currentColumn < ((maxServiceUsers * 2) + 3))
                            {  // total amount should be at last column which will be obtained by the above formula
                                currentColumn = (maxServiceUsers * 2) + 3;
                            }
                            // Populate data for TOTAL
                            worksheet.Cell(currentRow, currentColumn).Value = "£ " + item.TotalSumAmount;
                            totalAmount += item.TotalSumAmount; // sum the total amount
                            // Move to the next row
                            currentRow++;

                        }

                        // Add Total Amount
                        worksheet.Cell(currentRow, 1).Value = "Total Amount (£)";
                        worksheet.Cell(currentRow, 2).Value = totalAmount;
                    }


                }

                workbook.SaveAs(memoryStream);
                return memoryStream;
            }
            catch (Exception ex)
            {
                if (memoryStream != null)
                    memoryStream.Dispose();
                memoryStream = null;
                throw ex;
            }
            finally
            {
                if (workbook != null)
                    workbook.Dispose();

                workbook = null;
            }
        }

        #endregion


        public async Task<byte[]> DownloadFinanceReportResultsInPdf(FinanceReportSearchModel searchModel, Guid? UserId)
        {

            return await GenerateFinanceReportPdf(searchModel, UserId); // old 20/9
        }
        private async Task<byte[]> GenerateFinanceReportPdf(FinanceReportSearchModel searchModel, Guid? UserId)
        {
            try
            {
                //IList<CarerFeeStructureViewModel> SLCFinanceListView = new List<CarerFeeStructureViewModel>(); // old

                // calling the main function in which all the processing is done
                var SLCFinanceListView = await GetFinanceReportList(searchModel, UserId);

                /*  // commenting this code because now we will receive the list from the function processed 
                //Attributes filter
                string AttributeSearchList = "";
                string AttributeOptionList = "";
                bool flg = false;
                AttributeSearchList = String.Join(",", searchModel.UserAttributes.Select(p => p.AttributeId));
                foreach (var i in searchModel.UserAttributes.ToList())
                {
                    foreach (var j in i.AttributeOptions.ToList())
                    {
                        if (flg == false)
                            AttributeOptionList += j.Id.ToString();
                        else
                            AttributeOptionList += "," + j.Id.ToString();
                        flg = true;
                    }
                }
                string[] financePeriodIds = searchModel.FinancePeriodIds.Split(',');
                //attribute filter
                string attrFilter = "";
                var attributesSearch = "";
                var attributesOptionSearch = "";




                if (AttributeSearchList.Length > 0)
                {
                    int flagOption = 0;
                    string type = "";
                    string onlyAtrributeOptionId = "";
                    foreach (var item in searchModel.UserAttributes.OrderBy(x => x.AttributeId).ToList())
                    {

                        if (searchModel.IsCarerAttribute)
                        {
                            type = "CarerId";
                        }
                        else
                        {
                            type = "serviceUserId";
                        }
                        attributesSearch += "and s." + type + " in (select distinct " + type + " from UserAttribute where " +
                        "AttributeId = " + item.AttributeId.ToString();
                        onlyAtrributeOptionId = "";
                        flagOption = 0;
                        foreach (var option in item.AttributeOptions.ToList())
                        {
                            if (flagOption == 0)
                                onlyAtrributeOptionId = option.Id.ToString();
                            else
                                onlyAtrributeOptionId = onlyAtrributeOptionId + "," + option.Id.ToString();
                            flagOption = 1;
                        }
                        attributesSearch = attributesSearch + " and OptionId in(" + onlyAtrributeOptionId + ") and " + type + " is not null)";
                    }
                    attrFilter = attributesSearch;
                }
                string whereClause = " where ";
                string PeriodDuration = "(";
                string condition = "";
                foreach (var item in financePeriodIds)
                {
                    int feePeriodId = Convert.ToInt32(item);
                    var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == feePeriodId);
                    PeriodDuration += condition + "((convert(date,s.Tdate)>='" + financePeriod.StartDate + "' and convert(date,s.Tdate)<='" + financePeriod.EndDate + "'))";
                    condition = " or ";
                }
                PeriodDuration += ")";
                if (PeriodDuration.Length > 0)
                    whereClause += PeriodDuration;
                else
                    whereClause = "";
                var AmountCondition = " ,s.Amount as 'TotalAmount', ";
                if (searchModel.IsCarer == false)
                {
                    AmountCondition = " ,isNull(s.LocalAuthorityCharges,0) as 'TotalAmount', ";
                }
                string whereForWeeklyLocalAuthorityCharge = "";
                if (searchModel.IsCarer == false)
                    whereForWeeklyLocalAuthorityCharge = " and (s.Weekly='1' or s.Daily='1')  and s.IsAdditionFee is null ";
                var listQuery = string.Format("select  s.Description" + AmountCondition + "case when s.Weekly='false' then 'UnSelected' else 'Selected' end as Weekly,case when s.Daily='false' then 'UnSelected' else 'Selected' end as Daily,case when s.NA='false' then 'UnSelected' else 'Selected' end as 'NA',CONVERT(varchar,FORMAT(SWITCHOFFSET(CONVERT(datetime, s.CreatedOn),DATENAME(TzOffset, SYSDATETIMEOFFSET())),'dd/MM/yyyy HH:mm')) +' by '+ CreatedByUser.FirstName + case when CreatedByUser.LastName is null  then '' else ' ' + CreatedByUser.LastName  end as 'CreatedByUser' from SLcFeeStracture s left join dbo.[user] as CreatedByUser  on CreatedByUser.Id = s.CreatedBy  " + whereClause + attrFilter + whereForWeeklyLocalAuthorityCharge + " order by CarerId asc, Amount asc");
                var exportedResults = await _unitOfWork.ExecuteSqlCommandSqlServer(listQuery);
                SLCFinanceListView = MapSLCFFinanceListViewModels(exportedResults);

                */ // commented by salman 20/9
                string filePath = null;

                filePath = "~/FinanceTemplates/" + "Gi7452v1yo" + "-CarerFinanceReport.html";
                filePath = System.Web.Hosting.HostingEnvironment.MapPath(filePath);

                string content = File.ReadAllText(filePath);
                byte[] parsedHtml = null;

                if (searchModel.IsSummary == false)
                {

                    string ReportTitle = "Carer Finance Report";
                    string bodyDetail = "";
                    string FinanceHeader = "";
                    decimal totalAmount = 0;
                    if (searchModel.IsCarer == true)
                    {
                        FinanceHeader = "<tr><th>Description</th>" +
                            "<th>Amount(£)</th>" +
                            "<th>Weekly</th>" +
                            "<th>Daily</th>" +
                            "<th>N/A</th>" +
                            "<th>Created ON</th>" +
                            "</tr>";
                        foreach (var item in SLCFinanceListView)
                        {
                            if (string.IsNullOrEmpty(item.CarerName))  // do not include those rows which contains CarerName and TotalAmount related to that carer
                            {
                                bodyDetail += "<tr><td>" + item.Description + "</td><td>"
                               // + item.TotalAmount + "</td><td>"
                               + item.Amount + "</td><td>"
                               + (item.Weekly ? "Selected" : "UnSelected") + "</td><td>"
                                + (item.Daily ? "Selected" : "UnSelected") + "</td><td>"
                                + (item.NA ? "Selected" : "UnSelected") + "</td><td>"
                                + item.CreatedOn.ToString("dd/MM/yyyy HH:mm") + " by " + item.CreatedByUser + "</td></tr>";
                                // totalAmount += item.TotalAmount;
                                totalAmount += item.Amount;
                            }
                        }
                    }
                    else
                    {
                        ReportTitle = "Local Authority Report";
                        FinanceHeader = "<tr><th>Description</th>" +
                           "<th>Amount(£)</th>" +
                           "<th>Weekly</th>" +
                            "<th>Daily</th>" +
                           "<th>Created ON</th>" +
                           "</tr>";
                        foreach (var item in SLCFinanceListView)
                        {
                            if (string.IsNullOrEmpty(item.CarerName))
                            {// do not include those rows which contains CarerName and TotalAmount related to that carer
                                bodyDetail += "<tr><td>" + item.Description + "</td><td>"
                                //+ item.TotalAmount + "</td><td>"
                                + item.Amount + "</td><td>"
                                + (item.Weekly ? "Selected" : "UnSelected") + "</td><td>"
                                + (item.Daily ? "Selected" : "UnSelected") + "</td><td>"
                                + item.CreatedOn.ToString("dd/MM/yyyy HH:mm") + " by " + item.CreatedByUser + "</td></tr>";
                                //totalAmount += item.TotalAmount;
                                totalAmount += item.Amount;
                            }
                        }
                    }
                    content = content.Replace("[ReportTitle]", ReportTitle);
                    content = content.Replace("[FinanceHeader]", FinanceHeader);
                    content = content.Replace("[BodyDetail]", bodyDetail);
                    content = content.Replace("[PoundSymbol]", "(£)");
                    content = content.Replace("[TotalAmount]", Convert.ToString(totalAmount));
                    parsedHtml = ParseHtml(content); // here we are calling without landscape function
                }
                else
                {

                    // this will work if issummary is true
                    string ReportTitle = "Carer Finance Report Summary";
                    string bodyDetail = "";
                    string FinanceHeader = "";
                    decimal totalAmount = 0;

                    // Summary content 
                    List<FinanceReportSummaryModel> summaryPDFData = new List<FinanceReportSummaryModel>();
                    summaryPDFData = await GetFinanceReportSummaryAsync(SLCFinanceListView, searchModel.FinancePeriodIds);

                    int maxServiceUsersPDF = summaryPDFData.Max(report => report.ServiceUsers.Count);
                    FinanceHeader += "<tr><th>Description</th>";
                    FinanceHeader += "<th>SLC</th>";
                    for (int i = 1; i <= maxServiceUsersPDF; i++)
                    {
                        FinanceHeader += $"<th>PWS {i} Name</th>";
                        FinanceHeader += $"<th>PWS {i} Amount</th>";
                    }
                    FinanceHeader += "<th>Total(£)</th></tr>";

                    foreach (var item in summaryPDFData)
                    {
                        // Add CarerName data for the current item
                        bodyDetail += "<tr><td>" + "Period(s) " + item.Description + "</td>";
                        bodyDetail += "<td>" + item.CarerName + "</td>";

                        // Loop through the ServiceUsers for the current item
                        // Loop through the ServiceUsers for the current item
                        int serviceUserCounter = 1;
                        foreach (var singleServiceUser in item.ServiceUsers)
                        {
                            string serviceUserNameInner = ""; // in rare case if first name or last name of the serviceuser is not present than we need to put string counter wise 
                            if (!string.IsNullOrWhiteSpace(singleServiceUser.ServiceUserName))
                            {
                                serviceUserNameInner = singleServiceUser.ServiceUserName;

                            }
                            else
                            {
                                serviceUserNameInner = "PWS " + serviceUserCounter + " Unnamed";
                            }
                            // Add the Name and Amount for each ServiceUser
                            // bodyDetail += "<td>" + singleServiceUser.ServiceUserName + "</td>";
                            bodyDetail += "<td>" + serviceUserNameInner + "</td>";
                            bodyDetail += "<td>" + singleServiceUser.Amount + "</td>";
                            serviceUserCounter += 1;
                        }

                        // Fill remaining columns with empty cells if needed
                        for (int i = item.ServiceUsers.Count; i < maxServiceUsersPDF; i++)
                        {
                            bodyDetail += "<td></td>";
                            bodyDetail += "<td></td>";
                        }

                        // Add Total data for the current item
                        bodyDetail += "<td>" + item.TotalSumAmount + "</td></tr>";
                        totalAmount += item.TotalSumAmount;
                    }
                    content = content.Replace("[ReportTitle]", ReportTitle);
                    content = content.Replace("[FinanceHeader]", FinanceHeader);
                    content = content.Replace("[BodyDetail]", bodyDetail);
                    content = content.Replace("[PoundSymbol]", "(£)");
                    content = content.Replace("[TotalAmount]", Convert.ToString(totalAmount));
                    parsedHtml = ParseHtmlLandScape(content); // here we are calling landscape function

                }

                return parsedHtml;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        // new function for creating finance report summary
        private async Task<List<FinanceReportSummaryModel>> GetFinanceReportSummaryAsync(List<CarerFeeStructureViewModels> financeReportListData, string financePeriodIdsCombined)
        {
            // finance related code 
            string[] financePeriodIds = financePeriodIdsCombined.Split(',');
            StringBuilder allFinancePeriodsBuilder = new StringBuilder();
            //foreach (var singleFinanceId in financePeriodIds)
            for (int i = 0; i < financePeriodIds.Length; i++)
            {
                int feePeriodId = Convert.ToInt32(financePeriodIds[i]);
                var financePeriod = await _unitOfWork.FinancePeriodRepository.GetFirstOrDefaultAsync(x => x.Id == feePeriodId);
                DateTime financePeriodStartDate = financePeriod.StartDate;
                DateTime financePeriodEndDate = financePeriod.EndDate;
                string singleFinancePeriodDates = $"{financePeriodStartDate:dd/MM/yyyy} - {financePeriodEndDate:dd/MM/yyyy}";

                // Append the current date range to the StringBuilder
                allFinancePeriodsBuilder.Append(singleFinancePeriodDates);

                // Add a comma and space if there are more finance periods
                if (i < financePeriodIds.Length - 1)
                {
                    allFinancePeriodsBuilder.Append(", ");
                }

            }
            string allFinancePeriodsInStringAsDescription = allFinancePeriodsBuilder.ToString();

            // end finance related code
            // for testing
            var filteredList1 = financeReportListData.Where(record => record.CarerId == Guid.Parse("197738fd-15e0-45aa-9e8d-1eb07522f4d5")).ToList();
            // end testing

            List<CarerFeeStructureViewModels> listWithoutCarerSumRecords = new List<CarerFeeStructureViewModels>();
            listWithoutCarerSumRecords = financeReportListData
                .Where(sd => sd.CarerName == null)
                .ToList();
            // the above list will hold all the records which are normal fees not total fee of the carer
            var users = await _unitOfWork.UserRepository.FindAllAsync();
            var carerServiceUserLIst = listWithoutCarerSumRecords
            .Select(sd => new
            {
                sd.CarerId,
                sd.CarerName,
                sd.ServiceUserId,
                sd.ServiceUserName,
                sd.Amount
            })
            .GroupBy(sd => new { sd.CarerId, sd.ServiceUserId })
            .Select(group => new
            {
                CarerId = group.Key.CarerId,
                CarerName = group.First().CarerName, // Use First() to get CarerName
                ServiceUserId = group.Key.ServiceUserId,
                ServiceUserName = group.First().ServiceUserName, // Use First() to get ServiceUserName
                TotalAmount = group.Sum(sd => sd.Amount)
            })
            .ToList();

            // for testing
           var filteredList = carerServiceUserLIst.Where(record => record.CarerId == Guid.Parse("197738fd-15e0-45aa-9e8d-1eb07522f4d5")).ToList();
            // end testing


            var carerServiceUserListWithCarerNames = carerServiceUserLIst
             .Join(
                 users,
                 r => r.CarerId,
                 u => u.Id,
                 (r, u) => new
                 {
                     r.CarerId,
                     CarerName = $"{u.FirstName} {u.LastName}",
                     r.ServiceUserId,
                     r.ServiceUserName,
                     r.TotalAmount
                 })
             .GroupBy(sd => new { sd.CarerId, sd.CarerName })
             .Select(group => new FinanceReportSummaryModel
             {
                 Description = allFinancePeriodsInStringAsDescription,
                 CarerId = group.Key.CarerId ?? Guid.Empty,
                 CarerName = group.Key.CarerName,
                 ServiceUsers = group.Select(g => new FinanceReportSummaryServiceUserModel
                 {
                     ServiceUserName = g.ServiceUserName,
                     Amount = g.TotalAmount
                 }).ToList(),
                 TotalSumAmount = group.Sum(g => g.TotalAmount)
             })
             .ToList();

            return carerServiceUserListWithCarerNames;
        }
        private List<CarerFeeStructureViewModel> MapSLCFFinanceListViewModels(DataTable List)
        {
            List<CarerFeeStructureViewModel> CarerFeeStructureModel = new List<CarerFeeStructureViewModel>();
            foreach (DataRow row in List.Rows)
            {
                CarerFeeStructureViewModel item = row.GetItem<CarerFeeStructureViewModel>();
                CarerFeeStructureModel.Add(MapQualificationAttachmentViewModel(item));
            }
            return CarerFeeStructureModel;
        }


        private CarerFeeStructureViewModel MapQualificationAttachmentViewModel(CarerFeeStructureViewModel model)
        {
            var carerListViewModel = new CarerFeeStructureViewModel()
            {
                Description = model.Description,
                Weekly = model.Weekly,
                CreatedByUser = model.CreatedByUser,
                Daily = model.Daily,
                NA = model.NA,
                TotalAmount = model.TotalAmount,
                LocalAuthorityCharges = model.LocalAuthorityCharges
            };
            return carerListViewModel;
        }
        /*
        private byte[] ParseHtml(String html)
        {
            using (MemoryStream baos = new MemoryStream())
            {
                var parser = new CustomHTMLToPdfParser();

                parser.Parse(baos, html);

                return baos.ToArray();
            }

        }
        */   //old

        private byte[] ParseHtml(String html)
        {
            using (MemoryStream baos = new MemoryStream())
            {
                var parser = new CustomHTMLToPdfParser();

                parser.Parse(baos, html);

                return baos.ToArray();
            }

        }
        // new method salman
        private byte[] ParseHtmlLandScape(String html)
        {
            using (MemoryStream baos = new MemoryStream())
            {
                var parser = new CustomHTMLToPdfParser();

                parser.ParseLandScape(baos, html);

                return baos.ToArray();
            }

        }



        private IList<TemplateListViewModel> MapTemplateListDataTableToViewModels(DataTable TemplatesListData, TenantModel tenant)
        {
            IList<TemplateListViewModel> TemplateViewModels = new List<TemplateListViewModel>();
            foreach (DataRow row in TemplatesListData.Rows)
            {
                TemplateListView item = row.GetItem<TemplateListView>();
                TemplateViewModels.Add(MapTemplateListViewModel(item));
            }
            return TemplateViewModels;
        }
        private TemplateListViewModel MapTemplateListViewModel(TemplateListView Template)
        {
            var templateListViewModel = new TemplateListViewModel()
            {
                Id = Template.Id,
                TemplateName = Template.TemplateName,
                ColumnNames = Template.ColumnName,
                IsCarer = Template.IsCarer ?? false,
                IsServiceUser = Template.IsServiceUser ?? false,
                IsTeam = Template.IsTeam ?? false,
                UpdatedByName = Template.UpdatedByName,
                CreatedByName = Template.CreatedByName,
                CreatedOn = Template.CreatedOn,
                UpdatedOn = Template.UpdatedOn,
            };

            return templateListViewModel;
        }
        public static IList<ReportColumnsListModel> MapReportColumnsListModels(IList<ReportColumn> columns
            , IList<Attributee> attributes)
        {
            IList<ReportColumnsListModel> columnsModels = new List<ReportColumnsListModel>();
            foreach (var column in columns)
            {
                columnsModels.Add(MapReportColumnsListModel(column));
            }
            foreach (var colun in attributes.ToList())
            {
                ReportColumn colm = new ReportColumn();
                colm.IsTeam = colun.IsTeam;
                colm.IsServiceUser = colun.IsSharedLivesCarer;
                colm.IsCarer = colun.IsPeopleWeSupport;
                colm.IsActive = true;
                colm.ColumnName = colun.AttributeName;
                colm.DisplayName = colun.AttributeName;
                var col = MapReportColumnsListModel(colm);
                col.AttributeColumnId = colun.Id;
                columnsModels.Add(col);
            }

            return columnsModels;
        }
        public static ReportColumnsListModel MapReportColumnsListModel(ReportColumn column)
        {
            return new ReportColumnsListModel()
            {
                Id = column.Id,
                ColumnName = column.ColumnName,
                DisplayName = column.DisplayName,
                IsTeam = column.IsTeam ?? false,
                IsServiceUser = column.IsServiceUser ?? false,
                IsCarer = column.IsCarer ?? false
            };
        }
        public async Task<string> FindColumnsByIdAsync(string ColumnIds)
        {
            List<int> columns = new List<int>();

            if (ColumnIds != "")
            {
                foreach (string number in ColumnIds.Split(','))
                    columns.Add(Int32.Parse(number));
            }
            List<ReportColumn> columnslist = new List<ReportColumn>();

            if (columns.Count > 0)
            {
                for (int i = 0; i < columns.Count; i++)
                {
                    var columnNames = await _unitOfWork.ReportColumnRepository.FindAllAsync(x => x.Id == columns[i]);

                    foreach (var item in columnNames)
                    {
                        var model = new ReportColumn()
                        {
                            ColumnName = item.ColumnName,
                            DisplayName = item.DisplayName,
                            Id = item.Id
                        };
                        columnslist.Add(model);
                    }
                }
            }

            var ColumnNames = String.Join(", ", columnslist.Select(p => p.DisplayName));
            return ColumnNames;
        }

        public async Task<string> FindAttributeColumnByIdAsync(string ColumnIds)
        {
            List<int> columns = new List<int>();

            if (ColumnIds != "")
            {
                foreach (string number in ColumnIds.Split(','))
                    columns.Add(Int32.Parse(number));
            }
            List<ReportColumn> columnslist = new List<ReportColumn>();

            if (columns.Count > 0)
            {
                for (int i = 0; i < columns.Count; i++)
                {
                    var columnNames = await _unitOfWork.AttributeRepository.FindAllAsync(x => x.Id == columns[i]);

                    foreach (var item in columnNames)
                    {
                        var model = new ReportColumn()
                        {
                            ColumnName = item.AttributeName,
                            DisplayName = item.AttributeName,
                            Id = item.Id
                        };
                        columnslist.Add(model);
                    }
                }
            }

            var ColumnNames = String.Join(", ", columnslist.Select(p => p.DisplayName));
            return ColumnNames;
        }
        public async Task<TemplateReportModel> FindTemplateByIdAsync(int Id)
        {
            var template = await _unitOfWork.TemplateReportRepository.GetFirstOrDefaultAsync(x => x.Id == Id);
            var templatedetail = await _unitOfWork.TemplateReportDetailRepository.FindAllAsync(x => x.TemplateId == Id);
            TemplateReportModel oldTempobj = new TemplateReportModel();
            var ColumnIds = String.Join(",", templatedetail.Where(x => x.ColumnId > 0).Select(p => p.ColumnId));
            var AttributeColumnIds = String.Join(",", templatedetail.Where(x => x.AttributeColumnId > 0).Select(p => p.AttributeColumnId));
            oldTempobj.Id = Id;
            oldTempobj.TemplateName = template.TemplateName;
            oldTempobj.IsCarer = template.IsCarer ?? false;
            oldTempobj.IsServiceUser = template.IsServiceUser ?? false;
            oldTempobj.IsTeam = template.IsTeam ?? false;
            if (ColumnIds == "")
                oldTempobj.Columns = await FindAttributeColumnByIdAsync(AttributeColumnIds);
            else if (AttributeColumnIds == "")
                oldTempobj.Columns = await FindColumnsByIdAsync(ColumnIds);
            else
                oldTempobj.Columns = await FindColumnsByIdAsync(ColumnIds) + "," + await FindAttributeColumnByIdAsync(AttributeColumnIds);

            return oldTempobj;
        }
        public static TemplateReport MapToTemplateBindingModel(TemplateReport templateReportModel, TemplateReportModel templateBindingModel, int tenantId)
        {

            if (templateReportModel == null)
            {
                templateReportModel = new TemplateReport();

                templateReportModel.CreatedBy = templateBindingModel.CreatedById;
                templateReportModel.CreatedOn = DateTime.UtcNow;
            }
            else
            {
                templateReportModel.UpdatedBy = templateBindingModel.UpdatedById;
                templateReportModel.UpdatedOn = DateTime.UtcNow;

            }
            templateReportModel.TemplateName = templateBindingModel.TemplateName;
            templateReportModel.IsCarer = templateBindingModel.IsCarer;
            templateReportModel.IsServiceUser = templateBindingModel.IsServiceUser;
            templateReportModel.IsTeam = templateBindingModel.IsTeam;
            templateReportModel.TenantId = templateBindingModel.TenantId.Value;
            return templateReportModel;
        }
        public static IList<TemplateReportDetail> MapToTemplateDetailBindingModels(List<TemplateReportDetailModel> templateReportDetailModel)
        {
            IList<TemplateReportDetail> templatedetail = new List<TemplateReportDetail>();

            foreach (var item in templateReportDetailModel)
            {
                int? attributeId = 0;
                int? columnId = 0;

                //check attribut null or value
                if (item.AttributeColumnId > 0)
                    attributeId = item.AttributeColumnId;
                else { attributeId = null; }

                //check column null or value
                if (item.ColumnId > 0)
                    columnId = item.ColumnId;
                else { columnId = null; }
                templatedetail.Add(new TemplateReportDetail()
                {
                    TemplateId = item.TemplateId,
                    ColumnId = columnId,
                    AttributeColumnId = attributeId,
                    SortingOrder = item.SortingOrder
                });

            }
            return templatedetail;
        }

    }





}
