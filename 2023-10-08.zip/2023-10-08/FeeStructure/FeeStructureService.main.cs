﻿using BusinessEntities.ArrangementType;
using BusinessEntities.FeeStructure;
using BusinessEntities.LeaveSetup;
using BusinessEntities.Others;
using BusinessEntities.Users.Bookers;
using BusinessServices.Audit;
using BusinessServices.Others;
using BusinessServices.Tenants;
using Common;
using DataAccessLayer.Services;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
 
namespace BusinessServices.FeeStructures
{
   public interface IFeeStructureService:IDisposable
    {
        Task<FeeStructureModel> SaveFeeStructure(FeeStructureModel entity);
        Task<FeeStructureModel> UpdateFeeStructure(FeeStructureModel entity);
        Task<FeeStructureModel> GetFeeStructure(int Id); 
        Task<PagedResults<FeeStructureModel>> GetAllFeeStructures(QueryParameter queryParameter, FeeStructureSearchModel searchModel);
        Task<Boolean> DeleteFeeStructure(int Id,Guid UserId);
        Task<Boolean> ValidateFeeStructureName(int id, string val);
        Task<List<FeeStructureLookupModel>> GetAllFeeStructureLookup(string type);

        //Service user Finance
        Task<ServiceUserFinanceViewModel> UpdateServiceUserFinance(ServiceUserFinanceViewModel entity);
        Task<Boolean> UpdateServiceUserFinanceUtility();
        Task<List<ServiceUserFinanceViewModel>> GetServiceUserFinance(string Id);
        Task<List<FeeStructureModel>> GetFeeStructureById(string id);

        //Carer Finance
        Task<SLCFeeStructureModel> SaveCarerAdditionalFee(SLCFeeStructureModel entity);
        Task<SLCFeeStructureModel> UpdateCarerFinanceAmount(SLCFeeStructureModel entity);
        Task<List<YearViewModel>> GetYearList();
        Task<List<MonthViewModel>> GetMonthList();
        Task<Boolean> DeleteCarerFeeStructure(SLCFeeStructureModel entity);
        Task<SLCCloseMonthModel> CarerCloseMonth(SLCCloseMonthModel entity);
        Task<bool> RoomExistOrNot(string UserId);
        Task<string> CheckPwsFeeStructureByCarer(string UserId);
        Task<Stream> DownloadCarerFinanceReportResultsInExcel(CarerFinanceSearchModel searchModel);
        Task<byte[]> DownloadCarerFinanceReportResultsInPdf(string CarerId,int FinancePeriodId);

        Task<PagedResults<CarerFeeStructureModel>> GetAllCarerFinanceList(QueryParameter queryParameter, CarerFinanceSearchModel searchModel);

        //Carer Holidays
        Task<CarerHolidaysViewModel> UpdateCarerHolidays(CarerHolidaysViewModel entity);
        Task<CarerHolidaysViewModel> GetCarerHolidaysById(string Id); 
        Task<List<LeaveSetupViewModel>> GetLeaveSetupListUpdated(LeaveSetupSearchModel obj);

        //Leave setup holiday scheduler data
        Task<HolidayLeaveSetupModel> SaveHolidayLeaveSetup(HolidayLeaveSetupModel entity, Guid guid);
        Task<HolidayLeaveSetupModel> UpdateHolidayLeaveSetup(HolidayLeaveSetupModel entity, Guid guid);
        Task<HolidayLeaveSetupModel> GetHolidayLeaveSetupById(int Id);
        Task<Boolean> DeleteHolidayLeaveSetupEventById(int Id, Guid UserId);
        Task<List<ArrangementTypeViewModel>> GetAllArrangementTypes(); // salman
        Task FeeStractureHangFireService(); //salman temp, will remove it after testing


    }
    public partial class FeeStructureService : IFeeStructureService, IDisposable
    {
        #region Private variables... 
        private bool disposed = false;
        private readonly IUnitOfWork _unitOfWork;
        private readonly ITenantService _tenantService;
        private readonly IAuditService _auditService;
        private readonly string _financeappStartup;
        private IEmailService _emailService = null;
        #endregion
        public FeeStructureService(IEmailService emailService, ITenantService tenantService, IAuditService auditService)
        {
            _tenantService = tenantService;
            _unitOfWork = new UnitOfWork();
            _auditService = auditService;
            _emailService = emailService;

        }
        #region Implementing IDiosposable...
        /// <summary>
        /// Protected Virtual Dispose method
        /// </summary>
        /// <param name="disposing"></param>
        protected virtual void Dispose(bool disposing)
        {
            if (!this.disposed)
            {
                if (disposing)
                {
                    _unitOfWork.Dispose();
                    _tenantService.Dispose();
                }
            }
            this.disposed = true;
        }

        /// <summary>
        /// Dispose method
        /// </summary>
        public void Dispose()
        {

            Dispose(true);
            GC.SuppressFinalize(this);

        }




        #endregion
    }
}
